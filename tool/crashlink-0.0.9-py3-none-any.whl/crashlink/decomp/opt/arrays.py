"""
Array and bytes-buffer pattern optimizers.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, cast

if TYPE_CHECKING:
    pass

from ...core import (
    Fun,
    Function,
    Native,
    Type,
)
from ... import disasm
from ..ir import (
    IRStatement,
    IRExpression,
    IRBlock,
    IRLocal,
    IRArithmetic,
    IRAssign,
    IRCall,
    IRBoolExpr,
    IRConst,
    IRConditional,
    IRPrimitiveLoop,
    IRReturn,
    IRTrace,
    IRTryCatch,
    IRSwitch,
    IRWhileLoop,
    IRField,
    IRNew,
    IRNativeArrayNew,
    IRNativeMapNew,
    IRBytesNew,
    IRCast,
    IRArrayLiteral,
    IRArrayAccess,
    IRRef,
    IRRefNew,
    IREnumConstruct,
    IREnumIndex,
    IREnumField,
    _get_type_in_code,
)
from . import (
    TraversingIROptimizer,
    _int_const_value,
    _structurally_equal,
    _has_observable_effects,
)


class IRNativeArrayAllocOptimizer(TraversingIROptimizer):
    """
    Folds `Native.alloc_array(ty, size)` into `new hl.NativeArray<T>(size)`.

    HL's raw "Array" kind is element-type-erased at the bytecode level — the
    only place the element type shows up is as the first argument to the
    `alloc_array` native at the allocation site (a `Type` opcode result, lifted
    to an IRConst(GLOBAL_OBJ) carrying the actual `Type`). Recovering it here
    lets the declared local be typed `hl.NativeArray<T>` instead of the much
    too generic (and, on recompile, semantically different — a boxed Haxe
    `Array<Dynamic>`) `Array<Dynamic>`.
    """

    TARGET_OPCODES = {"Type"}

    def _is_alloc_array_call(self, expr: IRExpression) -> bool:
        if not isinstance(expr, IRCall) or len(expr.args) != 2:
            return False
        if not isinstance(expr.target, IRConst) or not isinstance(expr.target.value, Native):
            return False
        return expr.target.value.name.resolve(self.func.code) == "alloc_array"

    def visit_block(self, block: IRBlock) -> None:
        local_defs: Dict[IRLocal, IRExpression] = {}
        for stmt in block.statements:
            if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
                local_defs[stmt.target] = stmt.expr
            if not (isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal)):
                continue
            if not self._is_alloc_array_call(stmt.expr):
                continue
            assert isinstance(stmt.expr, IRCall)
            ty_arg, size_arg = stmt.expr.args
            elem_type: Optional[Type] = None
            if isinstance(ty_arg, IRConst) and ty_arg.const_type == IRConst.ConstType.GLOBAL_OBJ:
                if isinstance(ty_arg.value, Type):
                    elem_type = ty_arg.value
            elif isinstance(ty_arg, IRLocal):
                defn = local_defs.get(ty_arg)
                if (
                    isinstance(defn, IRConst)
                    and defn.const_type == IRConst.ConstType.GLOBAL_OBJ
                    and isinstance(defn.value, Type)
                ):
                    elem_type = defn.value
            if elem_type is None:
                continue
            stmt.target.native_elem_type = elem_type
            stmt.expr = IRNativeArrayNew(self.func.code, stmt.target.type, elem_type, size_arg)
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)


class IRArrayObjWrapperOptimizer(TraversingIROptimizer):
    """
    Folds stdlib ArrayObj/ArrayDyn wrapper calls into Haxe array literals.

    Haxe's `new Array<Dynamic>()` and `[]` lower to calls like
    `__std_234_anon(Native.alloc_array(...))` or `__std_253_anon(new ArrayObj())`.
    These anonymous wrapper functions live in `hl/types/Array*.hx` and simply
    initialize an array object.  Rendering them as `[]` recovers the original
    source idiom.
    """

    _ARRAY_WRAPPER_RE = re.compile(r"__std_\d+_anon$")

    def _is_array_wrapper_call(self, expr: IRExpression) -> bool:
        if not isinstance(expr, IRCall) or len(expr.args) != 1:
            return False
        target = expr.target
        if not isinstance(target, IRConst) or not isinstance(target.value, Function):
            return False
        func = target.value
        try:
            path = func.resolve_file(self.func.code).replace("\\", "/")
        except Exception:
            return False
        if "hl/types/Array" not in path:
            return False
        partial = self.func.code.partial_func_name(func)
        return partial in (None, "", "<none>")

    def _is_empty_array_alloc(
        self,
        expr: Optional[IRExpression],
        local_defs: Dict["IRLocal", IRExpression],
        seen: Optional[Set[int]] = None,
    ) -> bool:
        """True when `expr` resolves to a zero-length array allocation."""
        if expr is None or not isinstance(expr, IRStatement):
            return False
        if seen is None:
            seen = set()
        if id(expr) in seen:
            return False
        seen.add(id(expr))

        if isinstance(expr, IRArrayLiteral):
            return not expr.elements
        if isinstance(expr, IRCall) and len(expr.args) == 2:
            target = expr.target
            if (
                isinstance(target, IRConst)
                and isinstance(target.value, Native)
                and target.value.name.resolve(self.func.code) == "alloc_array"
            ):
                size = expr.args[1]
                if isinstance(size, IRLocal):
                    size = local_defs.get(size, size)
                if isinstance(size, IRConst):
                    size_val = getattr(size.value, "value", size.value)
                    if size.const_type == IRConst.ConstType.INT and size_val == 0:
                        return True
        if isinstance(expr, IRNativeArrayNew):
            size = expr.size
            if isinstance(size, IRLocal):
                size = local_defs.get(size, size)
            if not isinstance(size, IRConst):
                return False
            size_val = getattr(size.value, "value", size.value)
            return size.const_type == IRConst.ConstType.INT and size_val == 0
        if isinstance(expr, IRLocal):
            return self._is_empty_array_alloc(local_defs.get(expr), local_defs, seen)
        return False

    def _empty_array_elem_type(
        self,
        expr: Optional[IRExpression],
        local_defs: Dict["IRLocal", IRExpression],
        seen: Optional[Set[int]] = None,
    ) -> Optional[Type]:
        """Element type recovered from an empty-array alloc chain, if any.

        Mirrors `_is_empty_array_alloc`'s traversal but also surfaces the `Type`
        argument HL's `alloc_array(ty, 0)` native carries — the only place the
        element type survives erasure — so the caller can stamp it onto the
        folded literal instead of discarding it.
        """
        if expr is None or not isinstance(expr, IRStatement):
            return None
        if seen is None:
            seen = set()
        if id(expr) in seen:
            return None
        seen.add(id(expr))

        if isinstance(expr, IRNativeArrayNew):
            return expr.elem_type
        if isinstance(expr, IRCall) and len(expr.args) == 2:
            target = expr.target
            if (
                isinstance(target, IRConst)
                and isinstance(target.value, Native)
                and target.value.name.resolve(self.func.code) == "alloc_array"
            ):
                ty_arg = expr.args[0]
                if isinstance(ty_arg, IRLocal):
                    ty_arg = local_defs.get(ty_arg, ty_arg)
                if isinstance(ty_arg, IRConst) and ty_arg.const_type == IRConst.ConstType.GLOBAL_OBJ:
                    if isinstance(ty_arg.value, Type):
                        return ty_arg.value
        if isinstance(expr, IRLocal):
            return self._empty_array_elem_type(local_defs.get(expr), local_defs, seen)
        return None

    def _reads_or_writes(self, stmt: IRStatement, local: IRLocal) -> bool:
        """Include nested control flow and assignment targets in the escape check."""
        return stmt == local or any(self._reads_or_writes(child, local) for child in stmt.get_children())

    def _expr_reads(self, expr: Optional[IRStatement], local: IRLocal) -> bool:
        if expr is None:
            return False
        if expr == local:
            return True
        return any(self._expr_reads(child, local) for child in expr.get_children())

    def _invalidates(self, stmt: IRStatement, locals: Set[IRLocal]) -> bool:
        if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal) and stmt.target in locals:
            return True
        if isinstance(stmt, (IRRef, IRRefNew)) and any(
            self._expr_reads(stmt.target, local) for local in locals
        ):
            return True
        return any(self._invalidates(child, locals) for child in stmt.get_children())

    def _takes_reference(self, stmt: IRStatement, locals: Set[IRLocal]) -> bool:
        if isinstance(stmt, (IRRef, IRRefNew)) and any(
            self._expr_reads(stmt.target, local) for local in locals
        ):
            return True
        return any(self._takes_reference(child, locals) for child in stmt.get_children())

    def _try_fold_array_literal(
        self, stmts: List[IRStatement], call_idx: int, arr_local: IRLocal
    ) -> Optional[Tuple[List[IRExpression], List[int]]]:
        """Find the `hl.NativeArray<T>(n)` alloc that sized `arr_local` and the n
        index-stores populating it, anywhere before `call_idx` (other, unrelated
        statements — e.g. constructing the values being stored — may sit between
        them). Returns (values in index order, indices of every statement to drop)
        so the caller can remove just those and splice in a single array literal.
        """
        alloc_idx: Optional[int] = None
        size: Optional[int] = None
        for j in range(call_idx - 1, -1, -1):
            s = stmts[j]
            if isinstance(s, IRAssign) and s.target == arr_local:
                if not isinstance(s.expr, IRNativeArrayNew):
                    return None
                size_expr = s.expr.size
                if not isinstance(size_expr, IRConst) or size_expr.const_type != IRConst.ConstType.INT:
                    return None
                size = int(getattr(size_expr.value, "value", size_expr.value))
                alloc_idx = j
                break
        if alloc_idx is None or size is None or size < 0:
            return None

        values: Dict[int, IRExpression] = {}
        store_indices: List[int] = []
        for j in range(alloc_idx + 1, call_idx):
            s = stmts[j]
            if (
                isinstance(s, IRAssign)
                and isinstance(s.target, IRArrayAccess)
                and s.target.array == arr_local
                and isinstance(s.target.index, IRConst)
                and s.target.index.const_type == IRConst.ConstType.INT
            ):
                idx = int(getattr(s.target.index.value, "value", s.target.index.value))
                if idx in values:
                    return None
                values[idx] = s.expr
                store_indices.append(j)
                continue
            if self._reads_or_writes(s, arr_local):
                # Something else touches the array between alloc and use (a blit,
                # a partial store we don't recognize, ...) — bail, too risky to fold.
                return None

        if set(values) != set(range(size)):
            return None
        for stmt in stmts[call_idx + 1 :]:
            if isinstance(stmt, IRAssign) and stmt.target == arr_local:
                if self._expr_reads(stmt.expr, arr_local):
                    return None
                break
            if self._reads_or_writes(stmt, arr_local):
                return None
        # A store captures its value now; a literal would evaluate it at the
        # wrapper call. Never defer effects, memory reads, or locals written by
        # intervening control flow (including reused bytecode registers).
        for store_idx in store_indices:
            store = stmts[store_idx]
            assert isinstance(store, IRAssign)
            if _has_observable_effects(store.expr):
                return None
            dependencies: Set[IRLocal] = set()
            self._collect_locals(store.expr, dependencies)
            if any(self._invalidates(stmt, dependencies) for stmt in stmts[store_idx + 1 : call_idx]):
                return None
            if any(self._takes_reference(stmt, dependencies) for stmt in stmts):
                return None
        consumed = [alloc_idx, *store_indices]
        result_values = [values[i] for i in range(size)]
        # Only move total, effect-free definitions. Moving a constructor or
        # field read across unrelated statements changes observable order.
        for k, val in enumerate(result_values):
            inlined = self._try_inline_element_temp(stmts, val, alloc_idx, call_idx, consumed)
            if inlined is not None:
                inlined_expr, def_idx = inlined
                result_values[k] = inlined_expr
                consumed.append(def_idx)
        # The array allocation also moves to the wrapper call. Do not move it
        # past an unconsumed allocation, call, memory access, or control flow.
        for index in range(alloc_idx + 1, call_idx):
            if index in consumed:
                continue
            stmt = stmts[index]
            if not isinstance(stmt, IRAssign) or not isinstance(stmt.target, IRLocal):
                return None
            if _has_observable_effects(stmt.expr):
                return None
        return result_values, consumed

    def _try_inline_element_temp(
        self,
        stmts: List[IRStatement],
        val: IRExpression,
        alloc_idx: int,
        call_idx: int,
        already_consumed: List[int],
    ) -> Optional[Tuple[IRExpression, int]]:
        """If `val` is a single-use synthetic local whose sole definition sits
        between the array alloc and the wrapper call, return its defining
        expression and the index of that definition so the caller can splice it
        into the array literal (a move, not a copy) and drop the definition."""
        if not isinstance(val, IRLocal):
            return None
        temp = val
        def_idx: Optional[int] = None
        for j in range(alloc_idx + 1, call_idx):
            s = stmts[j]
            if isinstance(s, IRAssign) and isinstance(s.target, IRLocal) and s.target == temp:
                if def_idx is not None:
                    return None  # redefined — not a single def
                def_idx = j
        if def_idx is None:
            return None
        def_stmt = stmts[def_idx]
        assert isinstance(def_stmt, IRAssign)
        def_expr = def_stmt.expr
        if _has_observable_effects(def_expr):
            return None
        # The temp must be read exactly once in the whole block, and that read
        # must be the store we're folding (one of the already-consumed stores).
        # The definition itself is a write, not a read.
        read_count = 0
        for j, s in enumerate(stmts):
            if j == def_idx:
                continue
            if self._stmt_reads(s, temp):
                read_count += 1
        if read_count != 1:
            return None
        # Nothing between the def and the wrapper call may reassign any free
        # local of the moved expression — otherwise moving the def to the
        # literal's position would change which value those locals hold.
        free_locals: Set[IRLocal] = set()
        self._collect_locals(def_expr, free_locals)
        for j in range(def_idx + 1, call_idx):
            if j in already_consumed:
                continue
            if self._invalidates(stmts[j], free_locals):
                return None
        return def_expr, def_idx

    def _reads_in_assign(self, stmt: IRAssign, local: IRLocal) -> bool:
        """True if `stmt` reads `local` (in its target's array/index or in expr),
        ignoring a write to `local` itself."""
        if isinstance(stmt.target, IRArrayAccess):
            if self._expr_reads(stmt.target.index, local) or self._expr_reads(stmt.target.array, local):
                return True
        elif isinstance(stmt.target, IRField):
            # `obj.field = ...` reads `obj` (the base) to know what to mutate.
            if self._expr_reads(stmt.target.target, local):
                return True
        elif stmt.target == local:
            # A write to `local` itself; the RHS may still read the old value,
            # but for a single-def temp that can't happen — treat as no read.
            return self._expr_reads(stmt.expr, local)
        return self._expr_reads(stmt.expr, local)

    def _stmt_reads(self, stmt: IRStatement, local: IRLocal) -> bool:
        """True if `stmt` reads `local` anywhere, treating a bare write to
        `local` itself as a read only via its RHS."""
        if isinstance(stmt, IRAssign):
            return self._reads_in_assign(stmt, local)
        return any(self._expr_reads(c, local) for c in stmt.get_children() if isinstance(c, IRExpression))

    def _collect_locals(self, expr: Optional[IRExpression], out: Set[IRLocal]) -> None:
        if expr is None:
            return
        if isinstance(expr, IRLocal):
            out.add(expr)
            return
        for c in expr.get_children():
            if isinstance(c, IRExpression):
                self._collect_locals(c, out)

    def visit_block(self, block: IRBlock) -> None:
        local_defs: Dict[IRLocal, IRExpression] = {}
        stmts = block.statements
        drop: Set[int] = set()
        for i, stmt in enumerate(stmts):
            if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
                local_defs[stmt.target] = stmt.expr
            if (
                isinstance(stmt, IRAssign)
                and isinstance(stmt.expr, IRCall)
                and self._is_array_wrapper_call(stmt.expr)
            ):
                arg = stmt.expr.args[0]
                if isinstance(arg, IRLocal):
                    folded = self._try_fold_array_literal(stmts, i, arg)
                    if folded is not None:
                        values, consumed = folded
                        literal = IRArrayLiteral(self.func.code, values, stmt.target.get_type())
                        elem_type = self._empty_array_elem_type(arg, local_defs)
                        if not values or (
                            elem_type is not None and elem_type.kind.value != Type.Kind.DYN.value
                        ):
                            literal.recovered_elem_type = elem_type
                        drop.update(consumed)
                        stmt.expr = literal
                elif self._is_empty_array_alloc(arg, local_defs):
                    literal = IRArrayLiteral(self.func.code, [], stmt.target.get_type())
                    literal.recovered_elem_type = self._empty_array_elem_type(arg, local_defs)
                    stmt.expr = literal
                # Any other non-empty wrapper (e.g. after a blit into an
                # already-populated array) must stay so pseudo can render
                # `alloc(anew)`.

        new_statements: List[IRStatement] = []
        for i, stmt in enumerate(stmts):
            if i in drop:
                continue
            if isinstance(stmt, IRCall) and self._is_array_wrapper_call(stmt):
                # Bare wrapper call (typically a constructor wrapper on a fresh
                # `new ArrayObj()`).  It has no observable effect beyond
                # initializing the array, so drop it.
                continue
            new_statements.append(stmt)
        block.statements = new_statements
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)


class IRNativeMapAllocOptimizer(TraversingIROptimizer):
    """
    Folds the no-arg native allocators backing HL's raw map abstracts into
    their Haxe constructor calls, e.g. `Native.hballoc()` -> `new
    hl.types.BytesMap()`.

    hl/types/{Bytes,Int,Int64,Object}Map.hx each wrap a single Abstract in a
    `new()` that's just `extern public inline function new() this = alloc();`,
    with `alloc` a `@:hlNative("std", ...)` call taking no arguments (see
    src/std/maps.c's `hballoc`/`hialloc`/`hi64alloc`/`hoalloc` in the
    hashlink runtime). The Abstract type itself carries no name we can
    recover (see IRNativeMapNew), so the native's own name is the only way
    to tell which map class an allocation belongs to.
    """

    TARGET_OPCODES = {"Call0"}

    NATIVE_TO_CLASS = {
        "hballoc": "hl.types.BytesMap",
        "hialloc": "hl.types.IntMap",
        "hi64alloc": "hl.types.Int64Map",
        "hoalloc": "hl.types.ObjectMap",
    }

    def _map_alloc(self, expr: IRExpression) -> Optional[Tuple[str, Native]]:
        if not isinstance(expr, IRCall) or expr.args:
            return None
        if not (isinstance(expr.target, IRConst) and isinstance(expr.target.value, Native)):
            return None
        native = expr.target.value
        if native.lib.resolve(self.func.code) != "std":
            return None
        class_name = self.NATIVE_TO_CLASS.get(native.name.resolve(self.func.code))
        return (class_name, native) if class_name is not None else None

    def visit_block(self, block: IRBlock) -> None:
        for stmt in block.statements:
            if not isinstance(stmt, IRAssign):
                continue
            alloc = self._map_alloc(stmt.expr)
            if alloc is None:
                continue
            class_name, native = alloc
            # The allocation site itself is the only place that carries the
            # Abstract return type by way of the native's own signature; a
            # local target's declared (register) type is the same value, but
            # by the time this optimizer runs the assignment may already be
            # copy-propagated onto a non-local target (e.g. SetGlobal).
            fun_def = native.type.resolve(self.func.code).definition
            assert isinstance(fun_def, Fun)
            abstract_type = fun_def.ret
            if isinstance(stmt.target, IRLocal):
                stmt.target.native_map_class = class_name
            stmt.expr = IRNativeMapNew(self.func.code, abstract_type, class_name)
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)


class IRBytesAllocOptimizer(TraversingIROptimizer):
    """
    Folds `Native.alloc_bytes(n)` into `new hl.Bytes(n)` (hl.Bytes's inline
    constructor is exactly that native call). Must run after
    IRArrayPatternOptimizer, which consumes the alloc_bytes calls backing
    fixed-size array literals.
    """

    def visit_block(self, block: IRBlock) -> None:
        for stmt in block.statements:
            if not isinstance(stmt, IRAssign):
                continue
            expr = stmt.expr
            if not (isinstance(expr, IRCall) and len(expr.args) == 1):
                continue
            if not (isinstance(expr.target, IRConst) and isinstance(expr.target.value, Native)):
                continue
            native = expr.target.value
            if native.lib.resolve(self.func.code) != "std":
                continue
            if native.name.resolve(self.func.code) != "alloc_bytes":
                continue
            fun_def = native.type.resolve(self.func.code).definition
            assert isinstance(fun_def, Fun)
            new_expr = IRBytesNew(self.func.code, fun_def.ret, expr.args[0])
            new_expr.adopt(expr)
            stmt.expr = new_expr
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)


class IRArrayPatternOptimizer(TraversingIROptimizer):
    """
    Recognise low-level HashLink array implementation patterns and rewrite them
    into high-level Haxe array operations.

    Currently handles:
      - Fixed-size integer array literals built with alloc_bytes + stores + allocI32.
      - Conditional arr.bytes[idx << 2] loads with length guard -> arr[idx].
      - ArrayObj allocation with <none>(alloc_array(...)) -> [].
      - temp = arr.bytes; ...; x = temp[idx << 2] -> x = arr[idx].

    Too many distinct opcode triggers to gate safely by TARGET_OPCODES — runs
    unconditionally.
    """

    def visit_block(self, block: IRBlock) -> None:
        made_change = True
        while made_change:
            made_change = False
            new_statements: List[IRStatement] = []
            i = 0
            while i < len(block.statements):
                stmt = block.statements[i]
                access_match = self._try_array_access(block.statements, i)
                if access_match:
                    arr_assign, consumed, preceding_to_pop = access_match
                    for _ in range(preceding_to_pop):
                        new_statements.pop()
                    new_statements.append(arr_assign)
                    i += consumed
                    made_change = True
                    continue

                empty_typed_match = self._try_empty_typed_array_alloc(block.statements, i)
                if empty_typed_match:
                    arr_assign, consumed = empty_typed_match
                    new_statements.append(arr_assign)
                    i += consumed
                    made_change = True
                    continue

                literal_match = self._try_array_literal(block.statements, i)
                if literal_match:
                    arr_assign, consumed = literal_match
                    new_statements.append(arr_assign)
                    i += consumed
                    made_change = True
                    continue

                obj_literal_match = self._try_array_obj_literal(block.statements, i)
                if obj_literal_match:
                    use_stmt, consumed = obj_literal_match
                    new_statements.append(use_stmt)
                    i += consumed
                    made_change = True
                    continue

                empty_dyn_match = self._try_empty_array_dyn(block.statements, i)
                if empty_dyn_match:
                    use_stmt, consumed, preceding_to_pop = empty_dyn_match
                    for _ in range(preceding_to_pop):
                        new_statements.pop()
                    new_statements.append(use_stmt)
                    i += consumed
                    made_change = True
                    continue

                dyn_literal_match = self._try_array_dyn_literal(block.statements, i)
                if dyn_literal_match:
                    use_stmt, consumed = dyn_literal_match
                    new_statements.append(use_stmt)
                    i += consumed
                    made_change = True
                    continue

                guard_match = self._try_write_bounds_guard(block.statements, i)
                if guard_match:
                    i += guard_match
                    made_change = True
                    continue

                temp_match = self._try_eliminate_bytes_temp(block.statements, i)
                if temp_match:
                    # Unlike the other _try_* helpers above, this one returns
                    # a full replacement for the whole statement list (the
                    # match can reach arbitrarily far ahead of `i`), not just
                    # a local edit at the current position — apply it
                    # immediately and restart the scan, instead of appending
                    # more onto `new_statements` from `i` in the *original*
                    # list, which would duplicate everything already folded
                    # into the returned list.
                    new_full_statements, _consumed = temp_match
                    block.statements = new_full_statements
                    made_change = True
                    break

                new_statements.append(stmt)
                i += 1
            else:
                block.statements = new_statements

    def _try_eliminate_bytes_temp(
        self, stmts: List[IRStatement], start: int
    ) -> Optional[Tuple[List[IRStatement], int]]:
        # Pattern: temp = expr.bytes
        # followed by zero or more statements, then a use of temp[idx << 2] that
        # can be rewritten to expr[idx].
        if start >= len(stmts):
            return None
        stmt = stmts[start]
        if not isinstance(stmt, IRAssign) or not isinstance(stmt.target, IRLocal):
            return None
        if not isinstance(stmt.expr, IRField) or stmt.expr.field_name != "bytes":
            return None
        temp = stmt.target
        arr_expr: IRExpression = stmt.expr.target
        # When the bytes field is loaded off `this`, the receiver is the array
        # impl class itself: collapse to `this.bytes[i]`, not `this[i]` (which
        # has no array accessor and won't recompile).
        if isinstance(arr_expr, IRLocal) and arr_expr.name == "this":
            arr_expr = stmt.expr

        # Scan forward and rewrite every use of temp in an array access (there
        # can be more than one, e.g. a read followed by a write to the same
        # index in a closure body: `total[0] = total[0] + 10`). The shift
        # offset may have been hoisted into its own temp (`idxTmp = idx << n`)
        # rather than appearing inline in the access; track those as we go.
        idx_temp_map: Dict[str, IRExpression] = {}
        rewritten = list(stmts)
        found_any = False
        for j in range(start + 1, len(stmts)):
            use = rewritten[j]
            if (
                isinstance(use, IRAssign)
                and isinstance(use.target, IRLocal)
                and isinstance(use.expr, IRArithmetic)
                and use.expr.op.value == "<<"
                and isinstance(use.expr.right, IRConst)
            ):
                idx_temp_map[use.target.name] = use.expr.left
            accesses = self._find_temp_accesses(use, temp, arr_expr, idx_temp_map)
            if accesses:
                new_use = self._replace_temp_accesses(use, accesses)
                new_use.adopt(stmt)  # `stmt` (the bytes-temp definition) is dropped below
                rewritten[j] = new_use
                found_any = True
        if not found_any:
            return None
        # Only safe to drop the def if every reference to temp got rewritten
        # above — a leftover raw use (e.g. as a call receiver) would otherwise
        # be left dangling once the definition is removed.
        for j in range(start + 1, len(rewritten)):
            if self._contains_local(rewritten[j], temp.name):
                return None
        return rewritten[:start] + rewritten[start + 1 :], 1

    def _contains_local(self, node: IRStatement, name: str, _seen: Optional[Set[int]] = None) -> bool:
        """True if `node` (recursively) still references a local named `name`."""
        if _seen is None:
            _seen = set()
        if id(node) in _seen:
            return False
        _seen.add(id(node))
        if isinstance(node, IRLocal):
            return node.name == name
        for child in node.get_children():
            if self._contains_local(child, name, _seen):
                return True
        return False

    def _find_temp_accesses(
        self,
        stmt: IRStatement,
        temp: IRLocal,
        arr_expr: IRExpression,
        idx_temp_map: Optional[Dict[str, IRExpression]] = None,
    ) -> List[Tuple[IRArrayAccess, IRExpression]]:
        """Find array accesses in stmt that read temp[idx << n].

        The shift amount is ignored; any left-shift on a raw `.bytes` temporary
        is treated as an element index, so Float (shift 3), Single/Int (shift 2)
        and UI16 (shift 1) arrays all recover correctly.
        """
        result: List[Tuple[IRArrayAccess, IRExpression]] = []
        seen: Set[int] = set()
        idx_temp_map = idx_temp_map or {}

        def visit(node: IRStatement) -> None:
            if id(node) in seen:
                return
            seen.add(id(node))
            if isinstance(node, IRArrayAccess):
                if isinstance(node.array, IRLocal) and node.array.name == temp.name:
                    if (
                        isinstance(node.index, IRArithmetic)
                        and node.index.op.value == "<<"
                        and isinstance(node.index.right, IRConst)
                    ):
                        result.append((node, IRArrayAccess(node.code, arr_expr, node.index.left)))
                    elif isinstance(node.index, IRLocal) and node.index.name in idx_temp_map:
                        result.append(
                            (
                                node,
                                IRArrayAccess(node.code, arr_expr, idx_temp_map[node.index.name]),
                            )
                        )
            for child in node.get_children():
                visit(child)

        visit(stmt)
        return result

    def _replace_temp_accesses(
        self,
        stmt: IRStatement,
        replacements: List[Tuple[IRArrayAccess, IRExpression]],
        _seen: Optional[Set[int]] = None,
    ) -> IRStatement:
        if not replacements:
            return stmt
        if _seen is None:
            _seen = set()
        if id(stmt) in _seen:
            return stmt
        _seen.add(id(stmt))
        old, new = replacements[0]
        if stmt is old:
            return new
        for child in stmt.get_children():
            if child is old:
                # Replace child reference directly if possible.
                self._replace_child(stmt, child, new)
                return stmt
            else:
                replaced = self._replace_temp_accesses(child, replacements, _seen)
                if replaced is not child:
                    self._replace_child(stmt, child, replaced)
                    return stmt
        return stmt

    def _replace_child(self, parent: IRStatement, old: IRStatement, new: Any) -> None:
        if isinstance(parent, IRAssign):
            if parent.target is old:
                parent.target = new
            elif parent.expr is old:
                parent.expr = new
        elif isinstance(parent, IRReturn):
            parent.value = new
        elif isinstance(parent, IRArithmetic):
            if parent.left is old:
                parent.left = new
            elif parent.right is old:
                parent.right = new
        elif isinstance(parent, IRBoolExpr):
            if parent.left is old:
                parent.left = new
            elif parent.right is old:
                parent.right = new
        elif isinstance(parent, IRCall):
            if parent.target is old:
                parent.target = new
            parent.args = [new if a is old else a for a in parent.args]
        elif isinstance(parent, IRArrayAccess):
            if parent.array is old:
                parent.array = new
            elif parent.index is old:
                parent.index = new
        elif isinstance(parent, IRField):
            if parent.target is old:
                parent.target = new
        elif isinstance(parent, IRCast):
            if parent.expr is old:
                parent.expr = new
        elif isinstance(parent, IRNew):
            parent.constructor_args = [new if a is old else a for a in parent.constructor_args]
        elif isinstance(parent, IREnumConstruct):
            parent.args = [new if a is old else a for a in parent.args]
        elif isinstance(parent, IREnumField):
            if parent.value is old:
                parent.value = new
        elif isinstance(parent, IRArrayLiteral):
            parent.elements = [new if e is old else e for e in parent.elements]
        elif isinstance(parent, IRConditional):
            if parent.condition is old:
                parent.condition = new
        elif isinstance(parent, IRPrimitiveLoop):
            if parent.condition is old:
                parent.condition = new
            elif parent.body is old:
                parent.body = new
        elif isinstance(parent, IRWhileLoop):
            if parent.condition is old:
                parent.condition = new
            elif parent.body is old:
                parent.body = new
        elif isinstance(parent, IRSwitch):
            if parent.value is old:
                parent.value = new
        elif isinstance(parent, IRTryCatch):
            if parent.try_block is old:
                parent.try_block = new
            elif parent.catch_block is old:
                parent.catch_block = new
            else:
                for i, (extra_local, extra_block) in enumerate(parent.extra_catches):
                    if extra_block is old:
                        parent.extra_catches[i] = (extra_local, new)
                        break
        elif isinstance(parent, IRTrace):
            if parent.msg is old:
                parent.msg = new

    def _is_alloc_bytes(self, expr: IRStatement) -> bool:
        if not isinstance(expr, IRCall):
            return False
        if not isinstance(expr.target, IRConst) or not isinstance(expr.target.value, Native):
            return False
        return expr.target.value.name.resolve(self.func.code) == "alloc_bytes"

    def _is_alloc_typed_array(self, expr: IRStatement) -> Optional[str]:
        """Return the alloc helper name (allocI32/allocF32/allocF64/allocUI16) if
        expr is a call to one of HashLink's typed ArrayBase alloc functions."""
        if not isinstance(expr, IRCall):
            return None
        if not isinstance(expr.target, IRConst) or not isinstance(expr.target.value, Function):
            return None
        name = self.func.code.partial_func_name(expr.target.value)
        if name in ("allocI32", "allocF32", "allocF64", "allocUI16"):
            return name
        return None

    _ALLOC_SHIFTS: Dict[str, int] = {
        "allocI32": 2,
        "allocF32": 2,
        "allocF64": 3,
        "allocUI16": 1,
    }

    def _is_shifted_index(self, idx: IRStatement, local: IRLocal, shift: int) -> bool:
        if not isinstance(idx, IRArithmetic):
            return False
        if idx.op.value != "<<":
            return False
        if not isinstance(idx.left, IRLocal) or idx.left.name != local.name:
            return False
        if not isinstance(idx.right, IRConst) or idx.right.const_type != IRConst.ConstType.INT:
            return False
        val = idx.right.value.value if hasattr(idx.right.value, "value") else idx.right.value
        return int(val) == shift

    def _is_alloc_array(self, expr: IRStatement) -> bool:
        if not isinstance(expr, IRCall):
            return False
        if not isinstance(expr.target, IRConst) or not isinstance(expr.target.value, Native):
            return False
        return expr.target.value.name.resolve(self.func.code) == "alloc_array"

    def _is_arrayobj_anon(self, expr: IRStatement) -> bool:
        if not isinstance(expr, IRCall):
            return False
        if not isinstance(expr.target, IRConst) or not isinstance(expr.target.value, Function):
            return False
        if len(expr.args) != 1:
            return False
        fun = expr.target.value
        try:
            path = fun.resolve_file(self.func.code)
        except Exception:
            path = ""
        if "ArrayObj.hx" not in path.replace("\\", "/"):
            return False
        try:
            sig = fun.resolve_fun(self.func.code)
            ret_name = disasm.type_name(self.func.code, sig.ret.resolve(self.func.code))
        except Exception:
            ret_name = ""
        return "ArrayObj" in ret_name or "Array" in ret_name

    def _find_anon_call(self, node: Optional[IRStatement], arr_local: IRLocal) -> Optional[IRCall]:
        if node is None:
            return None
        if isinstance(node, IRCall) and self._is_arrayobj_anon(node):
            if node.args and isinstance(node.args[0], IRLocal) and node.args[0].name == arr_local.name:
                return node
        # Many expression classes have incomplete get_children(); recurse into the
        # known attributes we care about here.
        if isinstance(node, IRAssign):
            return self._find_anon_call(node.expr, arr_local)
        if isinstance(node, IRReturn) and node.value:
            return self._find_anon_call(node.value, arr_local)
        if isinstance(node, IRCall):
            for arg in node.args:
                found = self._find_anon_call(arg, arr_local)
                if found:
                    return found
        if isinstance(node, IRCast):
            return self._find_anon_call(node.expr, arr_local)
        if isinstance(node, IRField):
            return self._find_anon_call(node.target, arr_local)
        if isinstance(node, IRArrayAccess):
            found = self._find_anon_call(node.array, arr_local)
            if found:
                return found
            return self._find_anon_call(node.index, arr_local)
        if isinstance(node, IRArithmetic):
            found = self._find_anon_call(node.left, arr_local)
            if found:
                return found
            return self._find_anon_call(node.right, arr_local)
        if isinstance(node, IRBoolExpr):
            found = self._find_anon_call(node.left, arr_local)
            if found:
                return found
            return self._find_anon_call(node.right, arr_local)
        if isinstance(node, IREnumField):
            return self._find_anon_call(node.value, arr_local)
        if isinstance(node, IREnumIndex):
            return self._find_anon_call(node.value, arr_local)
        if isinstance(node, IREnumConstruct):
            for arg in node.args:
                found = self._find_anon_call(arg, arr_local)
                if found:
                    return found
        if isinstance(node, IRArrayLiteral):
            for e in node.elements:
                found = self._find_anon_call(e, arr_local)
                if found:
                    return found
        if isinstance(node, IRNew):
            for arg in node.constructor_args:
                found = self._find_anon_call(arg, arr_local)
                if found:
                    return found
        return None

    def _try_array_obj_literal(
        self, stmts: List[IRStatement], start: int
    ) -> Optional[Tuple[IRStatement, int]]:
        # Pattern:
        #   arr = alloc_array(type, size)
        #   [elem = expr;] arr[i] = elem
        #   ...
        #   use(ArrayObj.anon(arr))
        # Rewrite the ArrayObj.anon(arr) expression to [expr0, expr1, ...].
        if start >= len(stmts):
            return None
        stmt = stmts[start]
        if not isinstance(stmt, IRAssign) or not isinstance(stmt.target, IRLocal):
            return None
        arr_local = stmt.target
        if not self._is_alloc_array(stmt.expr):
            return None

        values: List[IRExpression] = []
        i = start + 1
        while i < len(stmts):
            elem_expr: Optional[IRExpression] = None
            store_stmt: Optional[IRAssign] = None
            # Look for an element initializer immediately followed by a store
            # using that same local.  This handles patterns like:
            #   var9 = new TestClass();
            #   arr[0] = var9;
            s1 = stmts[i]
            if isinstance(s1, IRAssign) and isinstance(s1.target, IRLocal) and i + 1 < len(stmts):
                s2 = stmts[i + 1]
                if (
                    isinstance(s2, IRAssign)
                    and isinstance(s2.target, IRArrayAccess)
                    and isinstance(s2.target.array, IRLocal)
                    and s2.target.array.name == arr_local.name
                    and isinstance(s2.target.index, IRConst)
                    and s2.target.index.const_type == IRConst.ConstType.INT
                    and isinstance(s2.expr, IRLocal)
                    and s2.expr.name == s1.target.name
                ):
                    elem_expr = s1.expr
                    store_stmt = s2
                    i += 2
            if elem_expr is None:
                # Otherwise accept a bare store.
                if (
                    isinstance(s1, IRAssign)
                    and isinstance(s1.target, IRArrayAccess)
                    and isinstance(s1.target.array, IRLocal)
                    and s1.target.array.name == arr_local.name
                    and isinstance(s1.target.index, IRConst)
                    and s1.target.index.const_type == IRConst.ConstType.INT
                ):
                    elem_expr = s1.expr
                    store_stmt = s1
                    i += 1
            if elem_expr is None or store_stmt is None:
                break
            store_access = cast(IRArrayAccess, store_stmt.target)
            idx_const = cast(IRConst, store_access.index)
            idx = int(idx_const.value.value if hasattr(idx_const.value, "value") else idx_const.value)
            if idx != len(values):
                break
            values.append(elem_expr)

        if not values:
            return None

        if i >= len(stmts):
            return None
        use_stmt = stmts[i]
        anon_call = self._find_anon_call(use_stmt, arr_local)
        if anon_call is None:
            return None

        assert isinstance(anon_call.target, IRConst) and isinstance(anon_call.target.value, Function)
        literal = IRArrayLiteral(
            self.func.code,
            values,
            anon_call.target.value.resolve_fun(self.func.code).ret.resolve(self.func.code),
        )
        assert isinstance(stmt.expr, IRCall)
        type_arg = stmt.expr.args[0]
        if isinstance(type_arg, IRConst) and isinstance(type_arg.value, Type):
            if type_arg.value.kind.value != Type.Kind.DYN.value:
                literal.recovered_elem_type = type_arg.value
        self._replace_child(use_stmt, anon_call, literal)
        use_stmt.adopt(*stmts[start:i])  # alloc + element/store statements are dropped
        return use_stmt, i - start + 1

    def _is_empty_alloc_array(
        self,
        expr: IRStatement,
        local_defs: Optional[Dict[IRLocal, IRExpression]] = None,
    ) -> bool:
        if isinstance(expr, IRLocal) and local_defs is not None:
            expr = local_defs.get(expr, expr)
        if not self._is_alloc_array(expr):
            return False
        call = cast(IRCall, expr)
        if len(call.args) != 2:
            return False
        type_arg, size_arg = call.args
        if isinstance(size_arg, IRLocal) and local_defs is not None:
            size_arg = local_defs.get(size_arg, size_arg)
        if not isinstance(size_arg, IRConst) or size_arg.const_type != IRConst.ConstType.INT:
            return False
        if int(size_arg.value.value if hasattr(size_arg.value, "value") else size_arg.value) != 0:
            return False
        if isinstance(type_arg, IRLocal) and local_defs is not None:
            type_arg = local_defs.get(type_arg, type_arg)
        if isinstance(type_arg, IRConst) and (
            type_arg.const_type == IRConst.ConstType.NULL or isinstance(type_arg.value, Type)
        ):
            return True
        return False

    def _is_empty_arrayobj_anon(
        self,
        expr: IRStatement,
        local_defs: Optional[Dict[IRLocal, IRExpression]] = None,
    ) -> bool:
        if not self._is_arrayobj_anon(expr):
            return False
        call = cast(IRCall, expr)
        return len(call.args) == 1 and self._is_empty_alloc_array(call.args[0], local_defs)

    def _is_arraydyn_alloc(self, expr: IRStatement) -> bool:
        if not isinstance(expr, IRCall):
            return False
        if not isinstance(expr.target, IRConst) or not isinstance(expr.target.value, Function):
            return False
        func = expr.target.value
        name = self.func.code.full_func_name(func)
        if not name:
            name = self.func.code.partial_func_name(func)
        if not name:
            return False
        return name.endswith("ArrayDyn.alloc")

    def _try_empty_array_dyn(
        self, stmts: List[IRStatement], start: int
    ) -> Optional[Tuple[IRStatement, int, int]]:
        # Pattern:
        #   temp = ArrayObj.anon(alloc_array(null, 0))   (or already-simplified temp = [])
        #   [flag = true]                                 (optional HashLink 1.15+ boilerplate)
        #   target = ArrayDyn.alloc(temp, true_or_new_ref(flag))
        # Rewrite to target = [] when temp has no later uses.
        if start + 1 >= len(stmts):
            return None
        s0 = stmts[start]
        if not isinstance(s0, IRAssign) or not isinstance(s0.target, IRLocal):
            return None
        temp = s0.target

        local_defs: Dict[IRLocal, IRExpression] = {}
        for stmt in stmts[:start]:
            if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
                local_defs[stmt.target] = stmt.expr

        s0_expr_is_empty_literal = isinstance(s0.expr, IRArrayLiteral) and len(s0.expr.elements) == 0
        if not (s0_expr_is_empty_literal or self._is_empty_arrayobj_anon(s0.expr, local_defs)):
            return None
        preceding_to_pop = 0
        if isinstance(s0.expr, IRCall) and isinstance(s0.expr.args[0], IRLocal):
            backing = s0.expr.args[0]
            if start == 0:
                return None
            allocation = stmts[start - 1]
            if not (
                isinstance(allocation, IRAssign)
                and allocation.target is backing
                and self._is_empty_alloc_array(allocation.expr, local_defs)
            ) or any(self._local_in_stmt(stmt, backing) for stmt in stmts[start + 1 :]):
                return None
            preceding_to_pop = 1

        # Look for the ArrayDyn.alloc call. HashLink 1.15+ inserts a boolean flag
        # temp assignment between the temp and the alloc call, so scan forward.
        alloc_idx = -1
        ref_defs: Dict[IRLocal, IRExpression] = {}
        boilerplate_locals: Set[IRLocal] = set()
        for j in range(start + 1, min(len(stmts), start + 4)):
            s = stmts[j]
            if isinstance(s, IRAssign) and isinstance(s.expr, IRConst) and isinstance(s.expr.value, bool):
                # Optional flag assignment, keep looking.
                if isinstance(s.target, IRLocal):
                    ref_defs[s.target] = s.expr
                    boilerplate_locals.add(s.target)
                continue
            if isinstance(s, IRAssign) and isinstance(s.target, IRLocal) and isinstance(s.expr, IRRefNew):
                ref_defs[s.target] = s.expr
                boilerplate_locals.add(s.target)
                continue
            if isinstance(s, IRAssign) and isinstance(s.expr, IRCall) and self._is_arraydyn_alloc(s.expr):
                alloc_idx = j
                break
            # Stop scanning if we hit a non-boilerplate statement.
            break

        if alloc_idx == -1:
            return None
        s1 = stmts[alloc_idx]
        assert isinstance(s1, IRAssign)
        call = s1.expr
        assert isinstance(call, IRCall)
        if len(call.args) != 2:
            return None
        first_arg, second_arg = call.args
        if isinstance(second_arg, IRLocal) and second_arg in ref_defs:
            second_arg = ref_defs[second_arg]
        if not isinstance(first_arg, IRLocal) or first_arg.name != temp.name:
            return None

        true_ok = False
        if isinstance(second_arg, IRConst) and isinstance(second_arg.value, bool) and second_arg.value:
            true_ok = True
        elif (
            isinstance(second_arg, (IRRef, IRRefNew))
            and isinstance(second_arg.target, IRConst)
            and isinstance(second_arg.target.value, bool)
            and second_arg.target.value
        ):
            true_ok = True
        elif isinstance(second_arg, IRRefNew) and isinstance(second_arg.target, IRLocal):
            # HashLink 1.15+ lowers the boolean flag to a stack-allocated Ref.
            ref_local = second_arg.target
            for prior in reversed(stmts[:alloc_idx]):
                if isinstance(prior, IRAssign) and prior.target is ref_local:
                    true_ok = isinstance(prior.expr, IRConst) and prior.expr.value is True
                    break
        if not true_ok:
            return None

        for later in stmts[alloc_idx + 1 :]:
            if self._local_in_stmt(later, temp) or any(
                self._local_in_stmt(later, local) for local in boilerplate_locals
            ):
                return None

        literal = IRArrayLiteral(self.func.code, [], s1.target.get_type())
        new_assign = IRAssign(self.func.code, s1.target, literal)
        consume_count = alloc_idx - start + 1
        new_assign.adopt(*stmts[start - preceding_to_pop : alloc_idx + 1])
        return new_assign, consume_count, preceding_to_pop

    def _index_shift(self, idx: IRStatement, local: IRLocal) -> Optional[int]:
        """Return the shift amount if `idx` is `local << const`."""
        if not isinstance(idx, IRArithmetic):
            return None
        if idx.op.value != "<<":
            return None
        if not isinstance(idx.left, IRLocal) or idx.left.name != local.name:
            return None
        if not isinstance(idx.right, IRConst) or idx.right.const_type != IRConst.ConstType.INT:
            return None
        val = idx.right.value.value if hasattr(idx.right.value, "value") else idx.right.value
        return int(val)

    def _parse_store_and_increment(
        self,
        stmts: List[IRStatement],
        i: int,
        bytes_var: IRLocal,
        idx_var: IRLocal,
        values: List[IRExpression],
        expected_shift: Optional[int] = None,
    ) -> Optional[Tuple[int, int]]:
        """Parse one element store of a typed array literal.

        HashLink lowers a single element in several ways; the smallest window is
        ``bytes[idx << n] = value; idx++`` and larger windows may cache the value
        and/or the shifted index in temporaries.  We accept any window of up to
        five statements that ends with ``idx_var++`` and whose preceding
        statements are only assignments to the temporaries consumed by the store.

        Returns ``(index_after_increment, shift)`` or None.
        """

        def is_idx_increment(stmt: IRStatement) -> bool:
            if not isinstance(stmt, IRAssign) or stmt.target != idx_var:
                return False
            expr = stmt.expr
            if isinstance(expr, IRCast):
                expr = expr.expr
            if not isinstance(expr, IRArithmetic) or expr.op != IRArithmetic.ArithmeticType.ADD:
                return False
            if expr.left != idx_var:
                return False
            if not isinstance(expr.right, IRConst) or expr.right.const_type != IRConst.ConstType.INT:
                return False
            return _int_const_value(expr.right) == 1

        def effective_shift(index_expr: IRExpression, before: int) -> Optional[int]:
            if isinstance(index_expr, IRArithmetic):
                return self._index_shift(index_expr, idx_var)
            if isinstance(index_expr, IRLocal):
                for k in range(before - 1, -1, -1):
                    s = stmts[i + k]
                    if isinstance(s, IRAssign) and s.target == index_expr:
                        if isinstance(s.expr, IRArithmetic):
                            return self._index_shift(s.expr, idx_var)
                        break
            return None

        def unwrap_value(expr: IRExpression, before: int) -> Optional[IRExpression]:
            if not isinstance(expr, IRLocal):
                return expr
            for k in range(before - 1, -1, -1):
                s = stmts[i + k]
                if isinstance(s, IRAssign) and s.target == expr:
                    return s.expr
            return None

        max_window = 5
        for inc_offset in range(1, max_window + 1):
            if i + inc_offset >= len(stmts):
                break
            if not is_idx_increment(stmts[i + inc_offset]):
                continue
            store_offset = inc_offset - 1
            store = stmts[i + store_offset]
            if not isinstance(store, IRAssign) or not isinstance(store.target, IRArrayAccess):
                continue
            access = store.target
            if not isinstance(access.array, IRLocal) or access.array.name != bytes_var.name:
                continue

            shift = effective_shift(access.index, store_offset)
            if shift is None:
                continue
            if expected_shift is not None and shift != expected_shift:
                continue

            value = unwrap_value(store.expr, store_offset)
            if value is None:
                continue

            consumed: Set[str] = set()
            if isinstance(access.index, IRLocal):
                consumed.add(access.index.name)
            if isinstance(store.expr, IRLocal):
                consumed.add(store.expr.name)
            # The shifted-index temp may be computed as ``tmp = const; tmp = idx << tmp``.
            for k in range(store_offset - 1, -1, -1):
                s = stmts[i + k]
                if isinstance(s, IRAssign) and isinstance(s.target, IRLocal):
                    if s.target.name in consumed:
                        if (
                            isinstance(s.expr, IRArithmetic)
                            and s.expr.op.value == "<<"
                            and isinstance(s.expr.right, IRLocal)
                        ):
                            consumed.add(s.expr.right.name)
                        continue
                    # Allow dead compiler-temp assignments that are not read before the store.
                    dead = True
                    for m in range(k + 1, store_offset + 1):
                        if self._local_in_stmt(stmts[i + m], s.target):
                            dead = False
                            break
                    if dead:
                        continue
                break
            else:
                values.append(value)
                return i + inc_offset + 1, shift
        return None

    _ALLOC_ELEM_TYPE_NAMES: Dict[str, str] = {
        "allocI32": "I32",
        "allocF32": "F32",
        "allocF64": "F64",
        "allocUI16": "U16",
    }

    def _try_empty_typed_array_alloc(
        self, stmts: List[IRStatement], start: int
    ) -> Optional[Tuple[IRStatement, int]]:
        # bytes_var = alloc_bytes(0); arr_var = allocXXX(bytes_var, 0)
        # -> arr_var = [] (element type recovered from the alloc helper name).
        # This is the growable-array shape used for both `new Array<T>()` and
        # `new haxe.ds.Vector<T>(n)` (which reads back .length and __expands
        # on each indexed write, same as an ordinary Array).
        if start >= len(stmts):
            return None
        alloc_stmt = stmts[start]
        if not isinstance(alloc_stmt, IRAssign) or not isinstance(alloc_stmt.target, IRLocal):
            return None
        if not self._is_alloc_bytes(alloc_stmt.expr):
            return None
        assert isinstance(alloc_stmt.expr, IRCall)
        if len(alloc_stmt.expr.args) != 1 or not self._is_int_const(alloc_stmt.expr.args[0], 0):
            return None
        # The wrap call is usually the very next statement, but harmless
        # register-reuse noise (e.g. a redundant `idx = 0` reassign not yet
        # cleaned up at this point in the pipeline) can sit in between.
        j = start + 1
        while j < len(stmts) and j < start + 6:
            s = stmts[j]
            if isinstance(s, IRAssign) and isinstance(s.target, IRLocal) and not isinstance(s.expr, IRCall):
                j += 1
                continue
            break
        if j >= len(stmts):
            return None
        wrap_stmt = stmts[j]
        if not isinstance(wrap_stmt, IRAssign) or not isinstance(wrap_stmt.target, IRLocal):
            return None
        alloc_name = self._is_alloc_typed_array(wrap_stmt.expr)
        if alloc_name is None:
            return None
        assert isinstance(wrap_stmt.expr, IRCall)
        call = wrap_stmt.expr
        if (
            len(call.args) != 2
            or not isinstance(call.args[0], IRLocal)
            or call.args[0].name != alloc_stmt.target.name
        ):
            return None
        if not self._is_int_const(call.args[1], 0):
            return None
        literal = IRArrayLiteral(self.func.code, [], wrap_stmt.target.get_type())
        elem_type_name = self._ALLOC_ELEM_TYPE_NAMES.get(alloc_name)
        if elem_type_name is not None:
            literal.recovered_elem_type = _get_type_in_code(self.func.code, elem_type_name)
        new_assign = IRAssign(self.func.code, wrap_stmt.target, literal)
        new_assign.adopt(*stmts[start : j + 1])
        return new_assign, j - start + 1

    def _is_int_const(self, expr: IRStatement, value: int) -> bool:
        if not isinstance(expr, IRConst) or expr.const_type != IRConst.ConstType.INT:
            return False
        v = expr.value.value if hasattr(expr.value, "value") else expr.value
        return int(v) == value

    def _try_array_literal(self, stmts: List[IRStatement], start: int) -> Optional[Tuple[IRStatement, int]]:
        # bytes_var = alloc_bytes(...)
        if start >= len(stmts):
            return None
        stmt = stmts[start]
        if not isinstance(stmt, IRAssign) or not isinstance(stmt.target, IRLocal):
            return None
        bytes_var = stmt.target
        if not self._is_alloc_bytes(stmt.expr):
            return None

        values: List[IRExpression] = []
        i: Optional[int] = None
        idx_var: Optional[IRLocal] = None
        shift: Optional[int] = None

        # Pattern 1: explicit `idx_var = 0` then a sequence of stores.
        if start + 1 < len(stmts):
            stmt2 = stmts[start + 1]
            if (
                isinstance(stmt2, IRAssign)
                and isinstance(stmt2.target, IRLocal)
                and isinstance(stmt2.expr, IRConst)
                and stmt2.expr.const_type == IRConst.ConstType.INT
                and int(stmt2.expr.value.value if hasattr(stmt2.expr.value, "value") else stmt2.expr.value)
                == 0
            ):
                idx_var = stmt2.target
                parsed = self._parse_store_and_increment(stmts, start + 2, bytes_var, idx_var, values)
                if parsed is not None:
                    i, shift = parsed
                    while True:
                        nxt = self._parse_store_and_increment(stmts, i, bytes_var, idx_var, values, shift)
                        if nxt is None:
                            break
                        i, _ = nxt
                    if not values:
                        i = None

        # Pattern 2: first store uses a constant 0 index; the counter is inferred
        # from the following increment (e.g. `bytes[0 << n] = v0; idx++; ...`).
        if i is None and shift is None and start + 2 < len(stmts):
            first_store = stmts[start + 1]
            if isinstance(first_store, IRAssign) and isinstance(first_store.target, IRArrayAccess):
                access = first_store.target
                if (
                    isinstance(access.array, IRLocal)
                    and access.array.name == bytes_var.name
                    and isinstance(access.index, IRArithmetic)
                    and access.index.op.value == "<<"
                    and isinstance(access.index.left, IRConst)
                    and access.index.left.const_type == IRConst.ConstType.INT
                    and int(
                        access.index.left.value.value
                        if hasattr(access.index.left.value, "value")
                        else access.index.left.value
                    )
                    == 0
                    and isinstance(access.index.right, IRConst)
                    and access.index.right.const_type == IRConst.ConstType.INT
                ):
                    shift = int(
                        access.index.right.value.value
                        if hasattr(access.index.right.value, "value")
                        else access.index.right.value
                    )
                    values = [first_store.expr]
                    inc_stmt = stmts[start + 2]
                    if (
                        isinstance(inc_stmt, IRAssign)
                        and isinstance(inc_stmt.target, IRLocal)
                        and isinstance(inc_stmt.expr, IRArithmetic)
                        and inc_stmt.expr.op.value == "+"
                        and isinstance(inc_stmt.expr.left, IRLocal)
                        and isinstance(inc_stmt.expr.right, IRConst)
                        and inc_stmt.expr.right.const_type == IRConst.ConstType.INT
                        and int(
                            inc_stmt.expr.right.value.value
                            if hasattr(inc_stmt.expr.right.value, "value")
                            else inc_stmt.expr.right.value
                        )
                        == 1
                    ):
                        idx_var = inc_stmt.target
                        parsed = self._parse_store_and_increment(
                            stmts, start + 3, bytes_var, idx_var, values, shift
                        )
                        if parsed is not None:
                            i, _ = parsed
                            while True:
                                nxt = self._parse_store_and_increment(
                                    stmts, i, bytes_var, idx_var, values, shift
                                )
                                if nxt is None:
                                    break
                                i, _ = nxt
                        else:
                            values = []
                            shift = None

        if not values or idx_var is None or i is None or shift is None:
            return None

        # Allow an optional `idx_var = count` assignment before the alloc call.
        if i < len(stmts):
            opt = stmts[i]
            if (
                isinstance(opt, IRAssign)
                and isinstance(opt.target, IRLocal)
                and opt.target.name == idx_var.name
                and isinstance(opt.expr, IRConst)
                and opt.expr.const_type == IRConst.ConstType.INT
            ):
                i += 1

        # arr_var = alloc*(bytes_var, count) OR return alloc*(bytes_var, count)
        if i >= len(stmts):
            return None
        final = stmts[i]
        if isinstance(final, IRAssign) and isinstance(final.expr, IRCall):
            call = final.expr
            return_target = final.target
        elif isinstance(final, IRReturn) and isinstance(final.value, IRCall):
            call = final.value
            return_target = None
        else:
            return None
        alloc_name = self._is_alloc_typed_array(call)
        if alloc_name is None:
            return None
        if self._ALLOC_SHIFTS.get(alloc_name) != shift:
            return None
        if len(call.args) != 2 or (isinstance(call.args[0], IRLocal) and call.args[0].name != bytes_var.name):
            return None

        assert isinstance(call.target, IRConst) and isinstance(call.target.value, Function)
        literal = IRArrayLiteral(
            self.func.code, values, call.target.value.resolve_fun(self.func.code).ret.resolve(self.func.code)
        )
        elem_type_name = self._ALLOC_ELEM_TYPE_NAMES.get(alloc_name)
        if elem_type_name is not None:
            literal.recovered_elem_type = _get_type_in_code(self.func.code, elem_type_name)

        # If the only uses of the recovered literal are constant-index reads, the
        # Haxe compiler will often constant-fold the whole array away.  Keep the
        # low-level allocation in that case so the recompiled bytecode stays close
        # to the original.
        if isinstance(return_target, IRLocal) and not self._array_literal_is_worth_recovering(
            return_target, stmts, i
        ):
            return None

        if return_target is not None:
            new_assign = IRAssign(self.func.code, return_target, literal)
            new_assign.adopt(*stmts[start : i + 1])
            return new_assign, i - start + 1
        else:
            new_return = IRReturn(self.func.code, literal)
            new_return.adopt(*stmts[start : i + 1])
            return new_return, i - start + 1

    def _array_literal_is_worth_recovering(
        self, arr_local: IRLocal, stmts: List[IRStatement], end_idx: int
    ) -> bool:
        """Return True if `arr_local` is used for anything other than a bounds
        guard after the literal allocation.

        Constant-index reads now count as real uses: recovering the array
        literal produces much cleaner Haxe source even though the compiler may
        later constant-fold it.
        """

        def _only_guard_fields(node: Optional[IRStatement]) -> bool:
            if node is None:
                return True
            if node == arr_local:
                return False
            if (
                isinstance(node, IRField)
                and node.target == arr_local
                and node.field_name in ("length", "bytes")
            ):
                return True
            for child in node.get_children():
                if not _only_guard_fields(child):
                    return False
            return True

        for stmt in stmts[end_idx + 1 :]:
            if self._local_in_stmt(stmt, arr_local):
                if isinstance(stmt, IRConditional) and _only_guard_fields(stmt.condition):
                    continue
                return True
        return False

    def _local_in_stmt(self, stmt: IRStatement, local: IRLocal) -> bool:
        if stmt == local:
            return True
        for child in stmt.get_children():
            if self._local_in_stmt(child, local):
                return True
        return False

    def _array_from_length_expr(
        self, stmts: List[IRStatement], start: int, expr: IRExpression
    ) -> Optional[Tuple[IRExpression, int]]:
        """Resolve the array expression behind a `.length` expression or a temp holding it.

        Returns the array expression (a local or a field access like `this.weights`)
        and the index of the statement that produced the length value, so the caller
        can consume it.
        """
        if isinstance(expr, IRField) and expr.field_name == "length" and isinstance(expr.target, IRLocal):
            return expr.target, start
        # Field-based array: `this.field.length` — the array is the field access
        # itself, read inline (no length temp to consume).
        if isinstance(expr, IRField) and expr.field_name == "length" and isinstance(expr.target, IRField):
            return expr.target, start
        if not isinstance(expr, IRLocal):
            return None
        for j in range(start - 1, max(-1, start - 5), -1):
            prev = stmts[j]
            if (
                isinstance(prev, IRAssign)
                and isinstance(prev.target, IRLocal)
                and prev.target.same_register(expr)
                and isinstance(prev.expr, IRField)
                and prev.expr.field_name == "length"
            ):
                return prev.expr.target, j
        return None

    def _try_array_access(
        self, stmts: List[IRStatement], start: int
    ) -> Optional[Tuple[IRStatement, int, int]]:
        # Pattern:
        #   if (idx >= arr.length) { value = default; } else { value = arr.bytes[idx << 2]; }
        # Returns (replacement_stmt, consumed_from_start, preceding_statements_to_pop).
        if start >= len(stmts):
            return None
        stmt = stmts[start]
        if not isinstance(stmt, IRConditional):
            return None
        cond = stmt.condition
        if not isinstance(cond, IRBoolExpr):
            return None
        if cond.op in (IRBoolExpr.CompareType.GTE, IRBoolExpr.CompareType.UGTE):
            idx_expr = cond.left
            length_expr = cond.right
        elif cond.op == IRBoolExpr.CompareType.LTE:
            length_expr = cond.left
            idx_expr = cond.right
        else:
            return None

        const_idx: Optional[int] = None
        idx_var: Optional[IRLocal] = None
        if isinstance(idx_expr, IRConst) and idx_expr.const_type == IRConst.ConstType.INT:
            const_idx = _int_const_value(idx_expr)
            if const_idx is None:
                return None
        elif isinstance(idx_expr, IRLocal):
            idx_var = idx_expr
        else:
            return None

        if length_expr is None:
            return None
        resolved = self._array_from_length_expr(stmts, start, length_expr)
        if resolved is None:
            return None
        arr_var, length_assign_idx = resolved

        then_block = stmt.true_block
        else_block = stmt.false_block
        if len(then_block.statements) != 1 or not else_block.statements:
            return None
        then_assign = then_block.statements[0]
        else_assign = else_block.statements[-1]
        if not isinstance(then_assign, IRAssign) or not isinstance(else_assign, IRAssign):
            return None
        if not isinstance(then_assign.expr, IRConst) or _int_const_value(then_assign.expr) != 0:
            return None
        if then_assign.target != else_assign.target or not isinstance(then_assign.target, IRLocal):
            return None
        value_var = then_assign.target
        if not isinstance(else_assign.expr, IRArrayAccess):
            return None
        access = else_assign.expr
        if isinstance(access.array, IRField):
            if len(else_block.statements) != 1:
                return None
            if access.array.field_name != "bytes" or not _structurally_equal(access.array.target, arr_var):
                return None
        elif isinstance(access.array, IRLocal):
            if len(else_block.statements) != 2:
                return None
            # HL splits the backing load into its own statement inside the else
            # branch: `t = arr.bytes; x = t[idx << 2]`. The conditional
            # replacement discards the whole else block, so the split load needs
            # no separate consumption — only a liveness check: the temp must be
            # unread after the guard, or collapsing would drop a live value.
            bytes_local = access.array
            bytes_load = else_block.statements[-2] if len(else_block.statements) >= 2 else None
            if not (
                isinstance(bytes_load, IRAssign)
                and bytes_load.target is bytes_local
                and isinstance(bytes_load.expr, IRField)
                and bytes_load.expr.field_name == "bytes"
                and _structurally_equal(bytes_load.expr.target, arr_var)
            ):
                return None
            for s in stmts[start + 1 :]:
                if isinstance(s, IRAssign) and s.target is bytes_local:
                    if self._local_in_stmt(s.expr, bytes_local):
                        return None
                    break
                if self._local_in_stmt(s, bytes_local):
                    return None
        else:
            return None
        if not isinstance(access.index, IRArithmetic) or access.index.op.value != "<<":
            return None
        if not isinstance(access.index.right, IRConst):
            return None

        if const_idx is None:
            # For constant-index accesses the compiler loads the constant into the
            # result register and then uses that register as the index scratchpad.
            # After debug-name splitting the index temp and the value temp look like
            # different locals, but reg_idx lets us recover the original constant.
            assert idx_var is not None
            const_idx = self._recover_constant_index(stmts, start, idx_var, access, value_var)
            # If the index local is a user-named variable (e.g. `i`), keep the
            # variable index so the source reads `a[i]`.  But when the index
            # register is the same register as the destination (`y = a[y]`),
            # the compiler just reused it as scratch — the constant must stay.
            if (
                const_idx is not None
                and idx_var is not None
                and not self._is_compiler_temp(idx_var)
                and not idx_var.same_register(value_var)
            ):
                const_idx = None

        if const_idx is not None:
            index_expr: IRExpression = IRConst(self.func.code, IRConst.ConstType.INT, value=const_idx)
        else:
            assert idx_var is not None
            index_expr = idx_var

        new_access = IRArrayAccess(self.func.code, arr_var, index_expr)
        new_assign = IRAssign(self.func.code, value_var, new_access)
        # If the length was loaded into a temp immediately before the guard, drop
        # that temp as well; otherwise later passes can leave a dead assignment.
        # When HL split the `.bytes` backing load out of the access (matched via
        # the else-branch temp above), the replacement discards the whole else
        # block, so no additional statement consumption is required.
        first_consumed = length_assign_idx
        preceding_to_pop = start - length_assign_idx
        new_assign.adopt(*stmts[first_consumed : start + 1])
        return new_assign, 1, preceding_to_pop

    def _recover_constant_index(
        self,
        stmts: List[IRStatement],
        start: int,
        idx_var: IRLocal,
        access: IRArrayAccess,
        value_var: IRLocal,
    ) -> Optional[int]:
        """Look for an immediately preceding `temp = const` that loads the index."""
        candidates = [idx_var, value_var]
        if isinstance(access.index, IRArithmetic) and isinstance(access.index.left, IRLocal):
            candidates.append(access.index.left)

        for candidate in candidates:
            val = self._const_loaded_for_local(stmts, start, candidate)
            if val is not None:
                return val
        return None

    def _is_compiler_temp(self, local: IRLocal) -> bool:
        return bool(re.fullmatch(r"var\d+", local.name))

    def _const_loaded_for_local(self, stmts: List[IRStatement], start: int, local: IRLocal) -> Optional[int]:
        """Scan the few statements before `start` for `local_reg = const`."""
        for j in range(start - 1, max(-1, start - 5), -1):
            prev = stmts[j]
            if isinstance(prev, IRAssign) and isinstance(prev.target, IRLocal):
                if prev.target.same_register(local):
                    if isinstance(prev.expr, IRConst):
                        return _int_const_value(prev.expr)
                    return None
        return None

    def _try_array_dyn_literal(
        self, stmts: List[IRStatement], start: int
    ) -> Optional[Tuple[IRStatement, int]]:
        """Rewrite `target = ArrayDyn.alloc([...], true)` to `target = [...]`.

        The ArrayObj.anon + ArrayDyn.alloc pair is already lowered to a typed
        array literal for the first argument. Removing the wrapper lets Haxe
        infer the target as Array<Dynamic>, which is required for mixed-type
        literals to recompile.
        """
        if start >= len(stmts):
            return None
        s = stmts[start]
        if not isinstance(s, IRAssign) or not isinstance(s.expr, IRCall):
            return None
        call = s.expr
        if not self._is_arraydyn_alloc(call):
            return None
        if len(call.args) != 2:
            return None
        first_arg, second_arg = call.args
        # A local already owns an allocated array. Substituting its defining
        # literal here would allocate twice and break identity and aliasing.
        if not isinstance(first_arg, IRArrayLiteral):
            return None

        true_ok = False
        if isinstance(second_arg, IRConst) and isinstance(second_arg.value, bool) and second_arg.value:
            true_ok = True
        elif (
            isinstance(second_arg, (IRRef, IRRefNew))
            and isinstance(second_arg.target, IRConst)
            and isinstance(second_arg.target.value, bool)
            and second_arg.target.value
        ):
            true_ok = True
        elif isinstance(second_arg, IRRefNew) and isinstance(second_arg.target, IRLocal):
            ref_local = second_arg.target
            for prior in reversed(stmts[:start]):
                if isinstance(prior, IRAssign) and prior.target == ref_local:
                    true_ok = isinstance(prior.expr, IRConst) and prior.expr.value is True
                    break
        if not true_ok:
            return None
        return IRAssign(self.func.code, s.target, first_arg).adopt(s), 1

    @staticmethod
    def _expr_eq(a: Optional[IRExpression], b: Optional[IRExpression]) -> bool:
        """Equality that also handles IRConst, which has no value-based `__eq__`
        (constant propagation creates a fresh IRConst node per substitution site,
        so identity/default equality spuriously fails for equal constants)."""
        if isinstance(a, IRConst) and isinstance(b, IRConst):
            return _int_const_value(a) == _int_const_value(b) and a.const_type == b.const_type
        return a == b

    def _try_write_bounds_guard(self, stmts: List[IRStatement], start: int) -> Optional[int]:
        """Drop the no-op `if (C >= a.length) a.__expand(C)` guard before an array write."""
        if start + 1 >= len(stmts):
            return None
        stmt = stmts[start]
        if not isinstance(stmt, IRConditional):
            return None
        cond = stmt.condition
        if not isinstance(cond, IRBoolExpr):
            return None
        if cond.op == IRBoolExpr.CompareType.GTE:
            idx_expr = cond.left
            length_expr = cond.right
        elif cond.op == IRBoolExpr.CompareType.LTE:
            length_expr = cond.left
            idx_expr = cond.right
        else:
            return None

        if length_expr is None:
            return None
        arr_var = self._array_var_from_length_expr(length_expr)
        if arr_var is None:
            return None

        if len(stmt.true_block.statements) != 1 or stmt.false_block.statements:
            return None
        call_stmt = stmt.true_block.statements[0]
        if not isinstance(call_stmt, IRCall):
            return None
        if not isinstance(call_stmt.target, IRConst) or not isinstance(call_stmt.target.value, Function):
            return None
        if self.func.code.partial_func_name(call_stmt.target.value) != "__expand":
            return None
        if len(call_stmt.args) != 2:
            return None
        # Keep the guard when __expand is called on `this`: that's the array
        # impl class's own setDyn body (real source), not a compiler-inserted
        # guard fronting a user's `arr[i] = v`.
        if isinstance(call_stmt.args[0], IRLocal) and call_stmt.args[0].name == "this":
            return None
        if call_stmt.args[0] != arr_var or not self._expr_eq(call_stmt.args[1], idx_expr):
            return None

        pos = start + 1
        bytes_temp_name: Optional[str] = None
        _s = stmts[pos] if pos < len(stmts) else None
        if (
            _s is not None
            and isinstance(_s, IRAssign)
            and isinstance(_s.target, IRLocal)
            and isinstance(_s.expr, IRField)
            and _s.expr.field_name == "bytes"
            and isinstance(_s.expr.target, IRLocal)
            and _s.expr.target.name == arr_var.name
        ):
            # `a.bytes` was hoisted into a temp before the write; look past it.
            bytes_temp_name = _s.target.name
            pos += 1

        # A leftover dead store (e.g. loading the shift amount into a scratch
        # register that the actual shift below recomputes from constants
        # directly) can sit here too; skip over a bounded run of those.
        while pos < len(stmts) and pos + 1 < len(stmts):
            _cur = stmts[pos]
            _nxt = stmts[pos + 1]
            if (
                isinstance(_cur, IRAssign)
                and isinstance(_cur.target, IRLocal)
                and isinstance(_cur.expr, IRConst)
                and isinstance(_nxt, IRAssign)
                and isinstance(_nxt.target, IRLocal)
                and _nxt.target.name == _cur.target.name
            ):
                pos += 1
            else:
                break

        # The `idx << 2` byte offset may also have been hoisted into its own temp
        # rather than appearing inline in the array access.
        idx_temp_expr: Optional[IRExpression] = None
        _s2 = stmts[pos] if pos < len(stmts) else None
        if (
            _s2 is not None
            and isinstance(_s2, IRAssign)
            and isinstance(_s2.target, IRLocal)
            and isinstance(_s2.expr, IRArithmetic)
            and _s2.expr.op.value == "<<"
            and self._expr_eq(_s2.expr.left, idx_expr)
            and isinstance(_s2.expr.right, IRConst)
        ):
            idx_temp_expr = _s2.target
            pos += 1

        if pos >= len(stmts):
            return None
        next_stmt = stmts[pos]
        if not isinstance(next_stmt, IRAssign) or not isinstance(next_stmt.target, IRArrayAccess):
            return None
        access = next_stmt.target

        def _matches_shifted_index(index: IRExpression) -> bool:
            if idx_temp_expr is not None:
                return self._expr_eq(index, idx_temp_expr)
            if not isinstance(index, IRArithmetic) or index.op.value != "<<":
                return False
            if not self._expr_eq(index.left, idx_expr):
                return False
            return isinstance(index.right, IRConst)

        # High-level store: a[idx]
        if isinstance(access.array, IRLocal) and access.array.name == arr_var.name:
            if not self._expr_eq(access.index, idx_expr):
                return None
        # Low-level store via the hoisted bytes temp: tmp[idx << 2]
        elif (
            bytes_temp_name is not None
            and isinstance(access.array, IRLocal)
            and access.array.name == bytes_temp_name
        ):
            if not _matches_shifted_index(access.index):
                return None
        # Low-level store: a.bytes[idx << 2]
        elif isinstance(access.array, IRField) and access.array.field_name == "bytes":
            if not isinstance(access.array.target, IRLocal) or access.array.target.name != arr_var.name:
                return None
            if not isinstance(access.index, IRArithmetic) or access.index.op.value != "<<":
                return None
            if not self._expr_eq(access.index.left, idx_expr):
                return None
            if not isinstance(access.index.right, IRConst):
                return None
        else:
            return None

        return 1

    def _array_var_from_length_expr(self, expr: IRExpression) -> Optional[IRLocal]:
        """Return the array local if `expr` is `arr.length` (or a temp holding it)."""
        if isinstance(expr, IRField) and expr.field_name == "length" and isinstance(expr.target, IRLocal):
            return expr.target
        if isinstance(expr, IRLocal):
            # We do not attempt to trace back to the source here; the preceding
            # temp must have been removed or inlined by the time this runs.
            return None
        return None

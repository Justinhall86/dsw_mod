"""
Structural cleanup and dead-code elimination optimizers.
"""

from __future__ import annotations

import copy
import re
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, Union, cast

if TYPE_CHECKING:
    from ..function import IRFunction

from ...core import (
    DynObj,
    Enum,
    Function,
    Obj,
    Type,
    Virtual,
    destaticify,
    tIndex,
)
from ...errors import DecompError
from ... import disasm
from ...globals import DEBUG, dbg_print
from ..ir import (
    IRStatement,
    IRExpression,
    IRBlock,
    IRLocal,
    IRArithmetic,
    IRNeg,
    IRNot,
    IRTypeOf,
    IRTypeKind,
    IRAssign,
    IRCall,
    IRBoolExpr,
    IRConst,
    IRConditional,
    IRPrimitiveLoop,
    IRBreak,
    IRContinue,
    IRReturn,
    IRThrow,
    IRTrace,
    IRTryCatch,
    IRSwitch,
    IRPrimitiveJump,
    IRWhileLoop,
    IRForEachLoop,
    IRIntRangeLoop,
    IRField,
    IRNew,
    IRNativeArrayNew,
    IRCast,
    IRArrayLiteral,
    IRObjectLiteral,
    IRArrayAccess,
    IRRef,
    IRRefNew,
    IREnumConstruct,
    IREnumIndex,
    IREnumField,
    IRTernary,
    IRNullCoalesce,
)

from . import (
    IROptimizer,
    TraversingIROptimizer,
    _has_observable_effects,
    _ir_structurally_equal,
    _structurally_equal,
    _stmt_lists_structurally_equal,
)
from .inliner import _ReferenceAwareOptimizer, _is_pure_numeric_cast_tree


class IRLoopConditionOptimizer(_ReferenceAwareOptimizer):
    """
    Optimizes IRPrimitiveLoop structures into IRWhileLoop.
    It expects the IRPrimitiveLoop's condition block to end with an IRBoolExpr
    (which would typically have been lifted from a jump by IRPrimitiveJumpLifter).
    This IRBoolExpr determines the loop *exit* condition.

    Setup assignments may move into the condition only as a single-evaluation,
    ordered expression chain. Unsupported chains retain their original statements
    in a while(true)/break loop; potentially throwing reads are never discarded.
    """

    def _clone_bool_expr(self, expr: IRBoolExpr) -> IRBoolExpr:
        return IRBoolExpr(expr.code, expr.op, expr.left, expr.right).adopt(expr)

    def optimize(self) -> None:
        self._loop_live_out: Dict[int, Set[str]] = {}
        self._catch_reads: Set[str] = set()
        pending: List[IRStatement] = [self.func.block]
        visited: Set[int] = set()
        while pending:
            stmt = pending.pop()
            if id(stmt) in visited:
                continue
            visited.add(id(stmt))
            if isinstance(stmt, IRTryCatch):
                # A later throw can expose an earlier setup store to a handler.
                self._catch_reads.update(self._read_names(stmt))
            pending.extend(stmt.get_children())
        self._live_before(self.func.block, set())
        super().optimize()

    def _read_names(self, stmt: IRStatement) -> Set[str]:
        if isinstance(stmt, IRLocal):
            return {stmt.name}
        if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
            return self._read_names(stmt.expr)
        names: Set[str] = set()
        for child in stmt.get_children():
            names.update(self._read_names(child))
        return names

    def _live_before(self, stmt: IRStatement, live_out: Set[str]) -> Set[str]:
        if isinstance(stmt, IRBlock):
            live = set(live_out)
            for child in reversed(stmt.statements):
                live = self._live_before(child, live)
            return live
        if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
            return (live_out - {stmt.target.name}) | self._read_names(stmt.expr)
        if isinstance(stmt, IRConditional):
            return (
                self._read_names(stmt.condition)
                | self._live_before(stmt.true_block, live_out)
                | (self._live_before(stmt.false_block, live_out) if stmt.false_block else live_out)
            )
        if isinstance(stmt, (IRPrimitiveLoop, IRWhileLoop)):
            self._loop_live_out.setdefault(id(stmt), set()).update(live_out)
            live = set(live_out)
            while True:
                body_in = self._live_before(stmt.body, live)
                before = self._live_before(stmt.condition, body_in | live_out) | live
                if before == live:
                    return live
                live = before
        # Unknown control flow does not kill a live value. Still visit nested
        # blocks so their loops receive conservative continuation information.
        live = live_out | self._read_names(stmt)
        for child in stmt.get_children():
            if isinstance(child, IRBlock):
                self._live_before(child, live)
        return live

    def _condition_children(self, expr: IRExpression) -> Optional[List[str]]:
        if isinstance(expr, (IRLocal, IRConst)):
            return [] if not _has_observable_effects(expr) else None
        if isinstance(expr, (IRField, IRArrayAccess)):
            # Ordered, possibly-faulting reads: the proof below checks that
            # folding keeps them in the same sequence.
            return ["target"] if isinstance(expr, IRField) else ["array", "index"]
        if isinstance(expr, IRBoolExpr):
            if expr.op in (IRBoolExpr.CompareType.AND, IRBoolExpr.CompareType.OR):
                return None
            return [attr for attr in ("left", "right") if getattr(expr, attr) is not None]
        if isinstance(expr, IRArithmetic):
            # Check the operation itself without classifying its field operands
            # as discardable. Division, dynamic arithmetic, etc. stay unsupported.
            shell = copy.copy(expr)
            shell._cached_type = expr.get_type()
            shell.left = IRConst(expr.code, IRConst.ConstType.INT, value=0)
            shell.right = shell.left
            if not _has_observable_effects(shell):
                return ["left", "right"]
        if isinstance(expr, (IRNeg, IRNot)):
            return ["expr"]
        return None

    def _fold_condition_setup(
        self,
        loop: Union[IRPrimitiveLoop, IRWhileLoop],
        setup: List[IRStatement],
        condition: IRBoolExpr,
    ) -> Optional[IRBoolExpr]:
        reads: List[int] = []

        def ordered_reads(expr: IRExpression, result: List[int]) -> bool:
            attrs = self._condition_children(expr)
            if attrs is None or self._reads_address_taken(expr):
                return False
            for attr in attrs:
                if not ordered_reads(getattr(expr, attr), result):
                    return False
            if isinstance(expr, (IRField, IRArrayAccess)):
                result.append(id(expr))
            return True

        assignments: List[IRAssign] = []
        for stmt in setup:
            if not (
                isinstance(stmt, IRAssign)
                and isinstance(stmt.target, IRLocal)
                and not self._is_address_taken(stmt.target)
                and ordered_reads(stmt.expr, reads)
            ):
                return None
            assignments.append(stmt)
        if not ordered_reads(condition, reads):
            return None

        # Copy only changed expression paths, preserving field identities for
        # the evaluation-order proof below (rather than copying the Bytecode).
        field_origins: Dict[int, int] = {}

        def substitute(expr: IRExpression, target: IRLocal, value: IRExpression) -> Tuple[IRExpression, int]:
            if expr == target:
                return value, 1
            changed = 0
            result = expr
            for attr in self._condition_children(expr) or []:
                child, count = substitute(getattr(expr, attr), target, value)
                if count:
                    if result is expr:
                        result = copy.copy(expr)
                        if isinstance(expr, (IRField, IRArrayAccess)):
                            field_origins[id(result)] = field_origins.get(id(expr), id(expr))
                    setattr(result, attr, child)
                    changed += count
            return result, changed

        working: IRExpression = condition
        for i in range(len(assignments) - 1, -1, -1):
            stmt = assignments[i]
            target = cast(IRLocal, stmt.target)
            later = assignments[i + 1 :]
            # A killed register's old value may be folded, but its operands
            # must still denote the values captured at this assignment.
            if any(self._statement_reads_target(stmt.expr, other.target) for other in later):
                return None
            killed = any(other.target == target for other in later)
            if target.name in self._catch_reads:
                return None
            if not killed and (
                target.name in self._loop_live_out.get(id(loop), set())
                or self._reads_target_before_redefine(list(loop.body.statements) + setup[: i + 1], target)
            ):
                return None
            working, count = substitute(working, target, stmt.expr)
            if count != 1:
                return None

        folded_reads: List[int] = []
        if not ordered_reads(working, folded_reads):
            return None
        if reads != [field_origins.get(origin, origin) for origin in folded_reads]:
            return None
        result = cast(IRBoolExpr, working)
        result = self._clone_bool_expr(result)
        for stmt in assignments:
            result.adopt(stmt)
        return result

    def _reads_target_before_redefine(
        self, statements: List[IRStatement], target: IRLocal | IRField | IRArrayAccess
    ) -> bool:
        """Scan a top-level statement list in order for a read of `target`, stopping at
        the first statement that reassigns it. HL freely reuses dead registers, so a
        later statement matching `target` by name/register may be a genuine read of our
        value, or it may be operating on the register after it's been overwritten for an
        unrelated purpose - once reassigned, later statements can no longer be reading
        the value we're trying to inline."""
        for stmt in statements:
            if self._statement_reads_target(stmt, target):
                return True
            pending = [stmt]
            while pending:
                child = pending.pop()
                if isinstance(child, (IRBreak, IRContinue, IRReturn, IRThrow)):
                    return True
                pending.extend(child.get_children())
            if isinstance(stmt, IRAssign) and stmt.target == target:
                return False
        return False

    def _statement_reads_target(
        self, statement: IRStatement, target: IRLocal | IRField | IRArrayAccess | IREnumField | IRConst
    ) -> bool:
        if statement == target:
            return True
        if isinstance(statement, IRAssign) and isinstance(statement.target, IRLocal):
            return self._statement_reads_target(statement.expr, target)
        if isinstance(statement, (IRBoolExpr, IRArithmetic)):
            return (statement.left is not None and self._statement_reads_target(statement.left, target)) or (
                statement.right is not None and self._statement_reads_target(statement.right, target)
            )
        return any(self._statement_reads_target(child, target) for child in statement.get_children())

    def _convert_to_while_true_break(
        self,
        loop: IRPrimitiveLoop,
        setup_statements: List[IRStatement],
        exit_condition_expr: IRBoolExpr,
    ) -> IRWhileLoop:
        true_loop_condition = IRBoolExpr(loop.code, IRBoolExpr.CompareType.TRUE)
        break_block = IRBlock(loop.code)
        break_block.statements.append(IRBreak(loop.code))
        if_break_stmt = IRConditional(loop.code, exit_condition_expr, break_block, IRBlock(loop.code))

        new_body_block = IRBlock(loop.code)
        new_body_block.statements = setup_statements + [if_break_stmt] + list(loop.body.statements)

        new_while_loop = IRWhileLoop(loop.code, true_loop_condition, new_body_block)
        new_while_loop.comment = loop.comment
        new_while_loop.adopt(loop, exit_condition_expr)
        return new_while_loop

    def __init__(self, function: "IRFunction", retry: bool = False):
        super().__init__(function)
        # A retry pass revisits the while(true)+break form this optimizer
        # emits when it first runs: by then array guards have collapsed, so a
        # condition that read an element is no longer a branch.
        self.retry = retry

    def visit_block(self, block: IRBlock) -> None:
        new_statements: List[IRStatement] = []
        for stmt in block.statements:
            if isinstance(stmt, IRPrimitiveLoop):
                converted_loop = self._try_convert_to_while(stmt)
                new_statements.append(converted_loop if converted_loop else stmt)
            elif self.retry and isinstance(stmt, IRWhileLoop):
                recovered = self._try_recover_condition(stmt)
                new_statements.append(recovered if recovered else stmt)
            else:
                new_statements.append(stmt)
        block.statements = new_statements

    def _try_recover_condition(self, loop: IRWhileLoop) -> Optional[IRWhileLoop]:
        """Rebuild `while (cond)` from the while(true) + leading break form."""
        condition = loop.condition
        if not (isinstance(condition, IRBoolExpr) and condition.op == IRBoolExpr.CompareType.TRUE):
            return None
        statements = loop.body.statements
        branch_idx = next(
            (index for index, stmt in enumerate(statements) if isinstance(stmt, IRConditional)), None
        )
        if branch_idx is None:
            return None
        setup = statements[:branch_idx]
        branch = cast(IRConditional, statements[branch_idx])
        rest = statements[branch_idx + 1 :]

        def breaks(block: Optional[IRBlock]) -> bool:
            return (
                block is not None and len(block.statements) == 1 and isinstance(block.statements[0], IRBreak)
            )

        def empty(block: Optional[IRBlock]) -> bool:
            return block is None or not block.statements

        if not isinstance(branch.condition, IRBoolExpr):
            return None
        if breaks(branch.true_block) and empty(branch.false_block):
            exit_condition = self._clone_bool_expr(branch.condition)
            body_statements = list(rest)
        elif breaks(branch.false_block) and branch.true_block is not None:
            exit_condition = self._clone_bool_expr(branch.condition)
            exit_condition.invert()
            body_statements = list(branch.true_block.statements) + list(rest)
        else:
            return None

        if setup:
            # Setup the condition never reads stays in the loop, at the head of
            # the body: it still runs once per iteration, just after the test
            # it cannot influence.
            required, deferred = self._split_condition_setup(setup, exit_condition)
            if any(not isinstance(stmt, IRAssign) or _has_observable_effects(stmt.expr) for stmt in deferred):
                return None
            if required:
                folded = self._fold_condition_setup(loop, required, exit_condition)
                if folded is None:
                    return None
                exit_condition = folded
            body_statements = list(deferred) + body_statements

        continuation = self._clone_bool_expr(exit_condition)
        continuation.invert()
        body = IRBlock(loop.code)
        body.statements = body_statements
        recovered = IRWhileLoop(loop.code, continuation, body)
        recovered.comment = loop.comment
        recovered.adopt(loop, branch)
        if DEBUG:
            dbg_print(f"IRLoopCondOpt: recovered while condition {continuation}")
        return recovered

    def _split_condition_setup(
        self, setup: List[IRStatement], condition: IRBoolExpr
    ) -> Tuple[List[IRStatement], List[IRStatement]]:
        """Partition setup into what the condition depends on and the rest."""
        needed_names = self._read_names(condition)
        required_ids: Set[int] = set()
        for stmt in reversed(setup):
            if (
                isinstance(stmt, IRAssign)
                and isinstance(stmt.target, IRLocal)
                and stmt.target.name in needed_names
            ):
                required_ids.add(id(stmt))
                needed_names |= self._read_names(stmt.expr)
        required = [stmt for stmt in setup if id(stmt) in required_ids]
        deferred = [stmt for stmt in setup if id(stmt) not in required_ids]
        return required, deferred

    def _try_convert_to_while(self, loop: IRPrimitiveLoop) -> Optional[IRWhileLoop]:
        if not loop.condition.statements:
            dbg_print(f"IRLoopCondOpt: PrimitiveLoop at {loop} has empty condition block. Cannot convert.")
            return None

        last_cond_stmt = loop.condition.statements[-1]

        if not isinstance(last_cond_stmt, IRBoolExpr):
            dbg_print(
                f"IRLoopCondOpt: PrimitiveLoop at {loop} condition does not end with IRBoolExpr. Ends with {type(last_cond_stmt).__name__}. Cannot convert."
            )
            return None

        setup_statements_for_body = loop.condition.statements[:-1]
        working_exit_condition = self._clone_bool_expr(last_cond_stmt)
        if setup_statements_for_body:
            folded = self._fold_condition_setup(loop, setup_statements_for_body, working_exit_condition)
            if folded is None:
                dbg_print("IRLoopCondOpt: Preserving condition setup in while(true)+break form.")
                return self._convert_to_while_true_break(
                    loop, setup_statements_for_body, working_exit_condition
                )
            working_exit_condition = folded

        loop_continuation_expr = self._clone_bool_expr(working_exit_condition)
        loop_continuation_expr.invert()

        new_body_statements = list(loop.body.statements)
        new_body_block = IRBlock(loop.code)
        new_body_block.statements = new_body_statements

        new_while_loop = IRWhileLoop(loop.code, loop_continuation_expr, new_body_block)

        new_while_loop.comment = loop.comment
        new_while_loop.adopt(loop, loop_continuation_expr)

        dbg_print(
            f"IRLoopCondOpt: Converted IRPrimitiveLoop to IRWhileLoop. While condition: {loop_continuation_expr}"
        )
        return new_while_loop


class IRSelfAssignOptimizer(TraversingIROptimizer):
    """
    Optimizes away redundant assignments like `x = x`, including cases where
    `x` is wrapped in round-trip casts back to its own type (e.g. HL's
    Dyn->I32->Dyn unboxing shim on generic-method results).
    """

    @staticmethod
    def _strip_casts(expr: IRExpression) -> IRExpression:
        while isinstance(expr, IRCast):
            expr = expr.expr
        return expr

    def visit_block(self, block: IRBlock) -> None:
        new_statements = []

        for stmt in block.statements:
            if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
                # only elide if the assignment's own outer type is a no-op
                # round-trip back to the target's declared type
                if isinstance(stmt.expr, IRCast) and stmt.expr.get_type() is not stmt.target.get_type():
                    new_statements.append(stmt)
                    continue
                inner = self._strip_casts(stmt.expr)
                if stmt.target == inner:
                    if DEBUG:
                        dbg_print(f"IRSelfAssignOptimizer: Removing redundant assignment: {stmt}")
                    continue
            new_statements.append(stmt)

        block.statements = new_statements


def _next_stmt_is_return_of(stmts: List[IRStatement], idx: int, target: IRLocal) -> bool:
    """True if the statement right after `idx` is `return target;`."""
    if idx + 1 >= len(stmts):
        return False
    nxt = stmts[idx + 1]
    return isinstance(nxt, IRReturn) and nxt.value is not None and nxt.value == target


class IRBoolMaterializationCollapser(TraversingIROptimizer):
    """
    Collapses `if (cond) { t = true; } else { t = false; }` into `t = cond`,
    the inverted constant pair into `t = !cond`, and unwraps double negation.
    """

    @staticmethod
    def _negated_operand(expr: IRExpression) -> Optional[IRExpression]:
        if isinstance(expr, IRNot):
            return expr.expr
        if (
            isinstance(expr, IRBoolExpr)
            and expr.op in (IRBoolExpr.CompareType.ISFALSE, IRBoolExpr.CompareType.NOT)
            and expr.left is not None
        ):
            return expr.left
        return None

    @staticmethod
    def _strip_istrue(expr: IRExpression) -> IRExpression:
        while (
            isinstance(expr, IRBoolExpr)
            and expr.op == IRBoolExpr.CompareType.ISTRUE
            and expr.left is not None
        ):
            expr = expr.left
        return expr

    @classmethod
    def _unwrap_double_not(cls, expr: IRExpression) -> IRExpression:
        inner = cls._negated_operand(cls._strip_istrue(expr))
        if inner is None:
            return expr
        inner2 = cls._negated_operand(cls._strip_istrue(inner))
        if inner2 is None:
            return expr
        return cls._unwrap_double_not(inner2)

    @staticmethod
    def _branch_bool_assign(block: Optional[IRBlock]) -> Optional[Tuple[IRLocal, bool]]:
        if block is None or len(block.statements) != 1:
            return None
        stmt = block.statements[0]
        if (
            isinstance(stmt, IRAssign)
            and isinstance(stmt.target, IRLocal)
            and isinstance(stmt.expr, IRConst)
            and stmt.expr.const_type == IRConst.ConstType.BOOL
        ):
            return stmt.target, bool(stmt.expr.value)
        return None

    def _is_scoped_user_local(self, local: IRLocal) -> bool:
        """Whether a `varN` local is genuinely user-named: its register carries
        a debug assign at the local's own defining op. Anonymous temps that
        reuse a user-named register outside that variable's scope are not."""
        scoped = getattr(self.func, "is_scoped_user_temp", None)
        return bool(scoped(local)) if scoped is not None else True

    def visit_block(self, block: IRBlock) -> None:
        new_statements: List[IRStatement] = []
        for idx, stmt in enumerate(block.statements):
            if isinstance(stmt, IRAssign) and isinstance(stmt.expr, IRExpression):
                stmt.expr = self._unwrap_double_not(stmt.expr)
            elif isinstance(stmt, IRConditional):
                stmt.condition = self._unwrap_double_not(stmt.condition)
            elif isinstance(stmt, IRWhileLoop):
                stmt.condition = self._unwrap_double_not(stmt.condition)
            elif isinstance(stmt, IRReturn) and stmt.value is not None:
                stmt.value = self._unwrap_double_not(stmt.value)
            if isinstance(stmt, IRConditional):
                true_assign = self._branch_bool_assign(stmt.true_block)
                false_assign = self._branch_bool_assign(stmt.false_block)
                if (
                    true_assign is not None
                    and false_assign is not None
                    and true_assign[0] == false_assign[0]
                    and true_assign[1] != false_assign[1]
                    and not (
                        isinstance(true_assign[0], IRLocal)
                        and re.match(r"^var\d+$", true_assign[0].name)
                        # A genuinely anonymous compiler temp (no debug name at
                        # its own defining op) is not a user variable — a
                        # boolean if/else writing it is just `t = cond`. Only a
                        # varN that a debug assign actually names (a scoped user
                        # temp) keeps the branch structure for round-trip.
                        and self._is_scoped_user_local(true_assign[0])
                        # Exception: collapse `if (cond) { t = C1; } else { t = C2; }
                        # return t;` into `return cond;` even for varN temps, so
                        # `return x != null` doesn't decompile as a 4-line if/else.
                        and not _next_stmt_is_return_of(block.statements, idx, true_assign[0])
                    )
                ):
                    target = true_assign[0]
                    cond = stmt.condition
                    if not true_assign[1]:
                        # Negate: prefer inverting a comparison in-place over
                        # wrapping in IRNot to avoid `!(a >= b)` → `a < b`.
                        if isinstance(cond, IRBoolExpr) and cond.op in (
                            IRBoolExpr.CompareType.LT,
                            IRBoolExpr.CompareType.LTE,
                            IRBoolExpr.CompareType.GT,
                            IRBoolExpr.CompareType.GTE,
                            IRBoolExpr.CompareType.EQ,
                            IRBoolExpr.CompareType.NEQ,
                            IRBoolExpr.CompareType.NULL,
                            IRBoolExpr.CompareType.NOT_NULL,
                        ):
                            cond = copy.copy(cond)
                            cond.invert()
                        else:
                            cond = cond.expr if isinstance(cond, IRNot) else IRNot(self.func.code, cond)
                    assign = IRAssign(self.func.code, target, cond)
                    assign.adopt(stmt)
                    # The collapsed `t = cond` is a synthetic merge of the original
                    # branch — folding constants into it would lose the branch
                    # structure on recompile (e.g. `cond = 4 != 3` → `Bool True`).
                    assign._no_user_inline = True
                    dbg_print(f"IRBoolMaterializationCollapser: {stmt} -> {assign}")
                    new_statements.append(assign)
                    continue
            new_statements.append(stmt)
        block.statements = new_statements


class IRTernaryRecovery(TraversingIROptimizer):
    """Recovers the ternary operator from HL's statement-level conditional write.

    HashLink has no ternary opcode; `cond ? a : b` lowers to a full
    `if (cond) { x = a; } else { x = b; }` (or `if (cond) return a; else
    return b;`). When both branches are a single assignment to the *same*
    target, this rewrites the conditional into `x = (cond ? a : b)`; when both
    branches are a bare return, into `return (cond ? a : b)`. The result is an
    IRTernary expression — pseudo.py only renders it, no pattern matching
    there.

    Only runs when the two branch expressions are side-effect-free and the
    shared target is a plain local: the ternary evaluates both arms' reads
    unconditionally at the same point, so a throwing/calling arm would change
    behavior if moved out of its branch.
    """

    def visit_block(self, block: IRBlock) -> None:
        new_statements: List[IRStatement] = []
        i = 0
        statements = block.statements
        while i < len(statements):
            stmt = statements[i]
            # `x ?? default`: `if (x != null) { <yield x>; }` (empty else)
            # immediately followed by `<yield default>` at the same level.
            if i + 1 < len(statements):
                coal = self._try_null_coalesce(stmt, statements[i + 1])
                if coal is not None:
                    dbg_print(f"IRTernaryRecovery (??): {stmt} + {statements[i + 1]} -> {coal}")
                    new_statements.append(coal)
                    i += 2
                    continue
                # `cond ? a : b` with a fallthrough else: `if (cond) { return/
                # assign a; }` (empty else) then `return/assign b;`.
                fall = self._try_fallthrough_ternary(stmt, statements[i + 1])
                if fall is not None:
                    dbg_print(f"IRTernaryRecovery (fallthrough): {stmt} + {statements[i + 1]} -> {fall}")
                    new_statements.append(fall)
                    i += 2
                    continue
            # `if (c) { v = A; } else { return B; } return v;` -> `return c ? A : B`
            # (and the mirror with the assign in the else). The temp is
            # compiler-generated (single assignment, immediately returned), so
            # folding it away is exact. Only pure arms.
            if i + 1 < len(statements):
                tail = self._try_conditional_return_temp(stmt, statements[i + 1])
                if tail is not None:
                    dbg_print(f"IRTernaryRecovery (return-temp): {stmt} + {statements[i + 1]} -> {tail}")
                    new_statements.append(tail)
                    i += 2
                    continue
            recovered = self._try_recover(stmt)
            if recovered is not None:
                dbg_print(f"IRTernaryRecovery: {stmt} -> {recovered}")
                new_statements.append(recovered)
            else:
                new_statements.append(stmt)
            i += 1
        block.statements = new_statements

    def _try_fallthrough_ternary(
        self, cond_stmt: IRStatement, fallthrough: IRStatement
    ) -> Optional[IRStatement]:
        """Recover `cond ? a : b` from `if (cond) { return/assign a; }` (empty
        else) immediately followed by `return/assign b`. This is the form HL
        emits when the false arm falls through rather than living in an
        explicit `else` block. Both arms must be pure (a throwing/calling arm
        moved out of its branch would change behavior)."""
        if not isinstance(cond_stmt, IRConditional):
            return None
        if cond_stmt.false_block and cond_stmt.false_block.statements:
            return None
        true_stmts = cond_stmt.true_block.statements if cond_stmt.true_block else []
        if len(true_stmts) != 1:
            return None
        in_branch = true_stmts[0]
        if isinstance(in_branch, IRReturn) and isinstance(fallthrough, IRReturn):
            if in_branch.value is None or fallthrough.value is None:
                return None
            if not (self._safe_arm(in_branch.value) and self._safe_arm(fallthrough.value)):
                return None
            expr = self._make_ternary(
                cond_stmt.condition, in_branch.value, fallthrough.value, self._type_index(in_branch.value)
            )
            out = IRReturn(self.func.code, expr)
            out.adopt(cond_stmt, fallthrough)
            return out
        if isinstance(in_branch, IRAssign) and isinstance(fallthrough, IRAssign):
            if not (
                isinstance(in_branch.target, IRLocal)
                and _ir_structurally_equal(in_branch.target, fallthrough.target)
            ):
                return None
            if not (self._safe_arm(in_branch.expr) and self._safe_arm(fallthrough.expr)):
                return None
            expr = self._make_ternary(
                cond_stmt.condition, in_branch.expr, fallthrough.expr, in_branch.target.type
            )
            out = IRAssign(self.func.code, in_branch.target, expr)
            return out
        return None

    def _try_conditional_return_temp(
        self, stmt: IRStatement, following: IRStatement
    ) -> Optional[IRStatement]:
        """Recover `if (c) { v = A; } else { return B; } return v;` into
        `return c ? A : B` (and the mirror with the assign in the else).

        The temp `v` is compiler-generated — assigned exactly once in the
        branch and read only by the trailing return — so folding it away is
        exact. Both produced arms must be pure.
        """
        if not isinstance(stmt, IRConditional) or not isinstance(following, IRReturn):
            return None
        if following.value is None:
            return None
        true_stmts = stmt.true_block.statements if stmt.true_block else []
        false_stmts = stmt.false_block.statements if stmt.false_block else []
        if len(true_stmts) != 1 or len(false_stmts) != 1:
            return None
        t, f = true_stmts[0], false_stmts[0]
        # Identify the assigning branch and the returning branch.
        assign_side: Optional[IRAssign] = None
        return_side: Optional[IRReturn] = None
        assign_is_true = False
        if isinstance(t, IRAssign) and isinstance(f, IRReturn):
            assign_side, return_side, assign_is_true = t, f, True
        elif isinstance(f, IRAssign) and isinstance(t, IRReturn):
            assign_side, return_side, assign_is_true = f, t, False
        else:
            return None
        if return_side.value is None:
            return None
        # The assign target must be a compiler temp (`varN`) read only by the
        # trailing return — an explicit user variable stays an assignment.
        target = assign_side.target
        if not (isinstance(target, IRLocal) and target.name.startswith("var") and target.name[3:].isdigit()):
            return None
        if not _ir_structurally_equal(following.value, target):
            return None
        if not (self._safe_arm(assign_side.expr) and self._safe_arm(return_side.value)):
            return None
        then_expr = assign_side.expr if assign_is_true else return_side.value
        else_expr = return_side.value if assign_is_true else assign_side.expr
        expr = self._make_ternary(stmt.condition, then_expr, else_expr, self._type_index(then_expr))
        out = IRReturn(self.func.code, expr)
        out.adopt(stmt, following)
        return out

    def _try_null_coalesce(self, cond_stmt: IRStatement, fallthrough: IRStatement) -> Optional[IRStatement]:
        """Recover `value ?? default` from `if (value != null) { return/assign
        value; }` (empty else) followed by `return/assign default`."""
        if not isinstance(cond_stmt, IRConditional):
            return None
        cond = cond_stmt.condition
        if not (isinstance(cond, IRBoolExpr) and cond.op == IRBoolExpr.CompareType.NOT_NULL):
            return None
        true_stmts = cond_stmt.true_block.statements if cond_stmt.true_block else []
        if len(true_stmts) != 1:
            return None
        if cond_stmt.false_block and cond_stmt.false_block.statements:
            return None
        value = cond.left
        if value is None:
            return None
        in_branch = true_stmts[0]
        # Match `return value;` / `x = value;` in the branch against the
        # fallthrough `return default;` / `x = default;`.
        if isinstance(in_branch, IRReturn) and isinstance(fallthrough, IRReturn):
            if in_branch.value is None or fallthrough.value is None:
                return None
            if not _ir_structurally_equal(self._unwrap_value(in_branch.value), self._unwrap_value(value)):
                return None
            if not self._safe_arm(value) or not self._safe_arm(fallthrough.value):
                return None
            coal = IRNullCoalesce(
                self.func.code, in_branch.value, fallthrough.value, self._type_index(in_branch.value)
            )
            out = IRReturn(self.func.code, coal)
            out.adopt(cond_stmt, fallthrough)
            return out
        if isinstance(in_branch, IRAssign) and isinstance(fallthrough, IRAssign):
            if not _ir_structurally_equal(in_branch.target, fallthrough.target):
                return None
            if not isinstance(fallthrough.target, IRLocal):
                return None
            if not _ir_structurally_equal(self._unwrap_value(in_branch.expr), self._unwrap_value(value)):
                return None
            if not self._safe_arm(value) or not self._safe_arm(fallthrough.expr):
                return None
            coal = IRNullCoalesce(self.func.code, value, fallthrough.expr, fallthrough.target.type)
            out = IRAssign(self.func.code, fallthrough.target, coal)
            out.adopt(cond_stmt, fallthrough)
            out._no_user_inline = True
            return out
        return None

    def _unwrap_value(self, expr: IRExpression) -> IRExpression:
        """Strip representation casts so `(T)v` matches the tested `v`."""
        while isinstance(expr, IRCast):
            expr = expr.expr
        return expr

    def _bool_const(self, expr: IRExpression) -> Optional[bool]:
        """The boolean literal an arm is, if it is one."""
        if isinstance(expr, IRConst) and expr.const_type == IRConst.ConstType.BOOL:
            return bool(expr.value)
        return None

    def _make_ternary(
        self, cond: IRExpression, then_expr: IRExpression, else_expr: IRExpression, result_type: "tIndex"
    ) -> IRExpression:
        """Build a ternary, collapsing the redundant boolean forms:
        `cond ? true : false` is just `cond`, and `cond ? false : true` is
        `!cond` (inverting a comparison in place where possible)."""
        t_bool = self._bool_const(then_expr)
        f_bool = self._bool_const(else_expr)
        if t_bool is not None and f_bool is not None and t_bool != f_bool:
            if t_bool:  # cond ? true : false  ==  cond
                return cond
            # cond ? false : true  ==  !cond — invert a comparison in place.
            if isinstance(cond, IRBoolExpr) and cond.op in (
                IRBoolExpr.CompareType.LT,
                IRBoolExpr.CompareType.LTE,
                IRBoolExpr.CompareType.GT,
                IRBoolExpr.CompareType.GTE,
                IRBoolExpr.CompareType.EQ,
                IRBoolExpr.CompareType.NEQ,
                IRBoolExpr.CompareType.NULL,
                IRBoolExpr.CompareType.NOT_NULL,
            ):
                inverted = copy.copy(cond)
                inverted.invert()
                return inverted
            return IRNot(self.func.code, cond)
        return IRTernary(self.func.code, cond, then_expr, else_expr, result_type)

    def _try_recover(self, stmt: IRStatement) -> Optional[IRStatement]:
        if not isinstance(stmt, IRConditional):
            return None
        true_stmts = stmt.true_block.statements if stmt.true_block else []
        false_stmts = stmt.false_block.statements if stmt.false_block else []
        if len(true_stmts) != 1 or len(false_stmts) != 1:
            return None
        t, f = true_stmts[0], false_stmts[0]

        # if (cond) return a; else return b;  ->  return (cond ? a : b)
        if (
            isinstance(t, IRReturn)
            and isinstance(f, IRReturn)
            and t.value is not None
            and f.value is not None
        ):
            if self._safe_arm(t.value) and self._safe_arm(f.value):
                expr = self._make_ternary(stmt.condition, t.value, f.value, self._type_index(t.value))
                out = IRReturn(self.func.code, expr)
                out.adopt(stmt)
                return out
            return None

        # if (cond) { x = a; } else { x = b; }  ->  x = (cond ? a : b)
        if not (isinstance(t, IRAssign) and isinstance(f, IRAssign)):
            return None
        if not (isinstance(t.target, IRLocal) and _ir_structurally_equal(t.target, f.target)):
            return None
        if not (self._safe_arm(t.expr) and self._safe_arm(f.expr)):
            return None
        # The shared target's declared type is the ternary's result type.
        expr = self._make_ternary(stmt.condition, t.expr, f.expr, t.target.type)
        out = IRAssign(self.func.code, t.target, expr)
        out.adopt(stmt)
        # let constants fold into the ternary's condition.
        out._no_user_inline = True
        return out

    def _type_index(self, expr: IRExpression) -> "tIndex":
        """Resolve an expression's type back to its tIndex (identity search over
        the code's type table). Return arms are expressions, not locals, so we
        can't read `.type` off them directly."""
        from ...core import tIndex

        resolved = expr.get_type()
        for idx, t in enumerate(self.func.code.types):
            if t is resolved:
                return tIndex(idx)
        # Unresolvable (shouldn't happen for value-returning arms); Bool is the
        # safest ternary default.
        return tIndex(
            next(i for i, t in enumerate(self.func.code.types) if t.kind.value == Type.Kind.BOOL.value)
        )

    def _safe_arm(self, expr: IRExpression) -> bool:
        """Whether a branch arm can be hoisted into an unconditional ternary
        operand — pure, with no calls/allocation/throwing reads."""
        return not _has_observable_effects(expr)


class IRArrayGrowGuardEliminator(TraversingIROptimizer):
    """
    Removes `if (idx >= arr.length) arr.__expand(idx);` guards.

    HL's compiler emits this guard in front of *every* bracket write to a
    typed array (`arr[idx] = value;`), growing the backing storage first if
    needed. `__expand` isn't a real method of `Array<T>` though — it only
    exists on the internal ArrayBytes_T/ArrayObj implementation classes —
    so rendering this guard literally produces Haxe that doesn't compile.
    Since the guard is implied by (and always paired with) an ordinary
    bracket write, it's safe to drop unconditionally rather than try to
    render it.
    """

    def visit_block(self, block: IRBlock) -> None:
        new_statements = []

        for stmt in block.statements:
            if isinstance(stmt, IRConditional) and not (stmt.false_block and stmt.false_block.statements):
                true_stmts = stmt.true_block.statements if stmt.true_block else []
                if (
                    len(true_stmts) == 1
                    and isinstance(true_stmts[0], IRCall)
                    and isinstance(true_stmts[0].target, IRConst)
                    and isinstance(true_stmts[0].target.value, Function)
                    and self.func.code.partial_func_name(true_stmts[0].target.value) == "__expand"
                    # Keep the guard when __expand is called on `this`: that's the
                    # array impl class's own setDyn body (real source), not a
                    # compiler-inserted guard fronting a user's `arr[i] = v`.
                    and not (
                        true_stmts[0].args
                        and isinstance(true_stmts[0].args[0], IRLocal)
                        and true_stmts[0].args[0].name == "this"
                    )
                ):
                    if DEBUG:
                        dbg_print(f"IRArrayGrowGuardEliminator: Removing __expand guard: {stmt}")
                    continue
            new_statements.append(stmt)

        block.statements = new_statements


class IRArrayObjBoundsCheckCollapser(TraversingIROptimizer):
    """
    Collapses HL's compiler-emitted null-safe bounds check for reading an
    `Array<T>` of objects (backed by ArrayObj) into a plain bracket access:

        if (idx >= arr.length) x = null; else x = (T) arr.array[idx];
        ->
        x = arr[idx];

    `.array` is ArrayObj's internal backing-storage field — not a real,
    user-visible field of `Array<T>` — so rendering it literally produces
    Haxe that doesn't recompile. The collapse is semantics-preserving:
    Haxe's `Array<T>.__get` already returns null for an out-of-range index,
    which is exactly what the guard being removed was open-coding.
    """

    def visit_block(self, block: IRBlock) -> None:
        changed = True
        while changed:
            changed = False
            stmts = block.statements
            for idx, stmt in enumerate(stmts):
                match = self._try_collapse(stmts, idx)
                if match is None:
                    continue
                assign, consumed = match
                if DEBUG:
                    dbg_print(f"IRArrayObjBoundsCheckCollapser: {stmt} -> {assign}")
                block.statements = [
                    assign if k == idx else s for k, s in enumerate(stmts) if k == idx or k not in consumed
                ]
                changed = True
                break

    def _is_temp(self, local: IRLocal) -> bool:
        return local.reg_idx is not None and local.reg_idx not in self.func._user_reg_indices

    def _is_guard_default(self, expr: IRExpression) -> bool:
        """The value HL substitutes for an out-of-range read.

        Object arrays yield null; the primitive `ArrayBytes` specializations
        yield the element type's zero. Haxe's own `Array<T>` accessor returns
        exactly the same value, which is what makes dropping the guard safe.
        """
        if not isinstance(expr, IRConst):
            return False
        if expr.const_type == IRConst.ConstType.NULL:
            return True
        value = expr.value
        value = getattr(value, "value", value)
        return value in (0, 0.0, False)

    def _resolve(self, expr: IRExpression, defs: Dict[str, IRExpression]) -> IRExpression:
        """See through the temps HL hoists the guard's operands into."""
        seen: Set[int] = set()
        while isinstance(expr, IRLocal) and expr.name in defs and id(expr) not in seen:
            seen.add(id(expr))
            expr = defs[expr.name]
        return expr

    def _outer_defs(self, stmts: List[IRStatement], idx: int) -> Dict[str, IRExpression]:
        """Temp definitions visible to the guard, nearest definition winning."""
        defs: Dict[str, IRExpression] = {}
        for stmt in stmts[:idx]:
            if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
                if self._is_temp(stmt.target):
                    defs[stmt.target.name] = stmt.expr
                else:
                    defs.pop(stmt.target.name, None)
        return defs

    def _array_base(self, expr: IRExpression, defs: Dict[str, IRExpression]) -> Optional[IRExpression]:
        """The `Array<T>` an indexed access ultimately targets.

        Object arrays index HL's internal `.array` storage (and the primitive
        specializations their `.bytes`), reached either inline or through a
        temp. Anything else is already the array itself and must stay as
        written — resolving it further would name whatever expression the
        array happened to come from.
        """
        if isinstance(expr, IRField) and expr.field_name in ("array", "bytes"):
            return expr.target
        if isinstance(expr, IRLocal):
            resolved = self._resolve(expr, defs)
            if isinstance(resolved, IRField) and resolved.field_name in ("array", "bytes"):
                return resolved.target
            return expr
        return None

    def _try_collapse(self, stmts: List[IRStatement], idx: int) -> Optional[Tuple[IRStatement, Set[int]]]:
        stmt = stmts[idx]
        if not isinstance(stmt, IRConditional):
            return None
        cond = stmt.condition
        if not (
            isinstance(cond, IRBoolExpr)
            and cond.op in (IRBoolExpr.CompareType.GTE, IRBoolExpr.CompareType.UGTE)
        ):
            return None

        true_stmts = stmt.true_block.statements if stmt.true_block else []
        false_stmts = stmt.false_block.statements if stmt.false_block else []
        if len(true_stmts) != 1 or not false_stmts:
            return None
        true_stmt, last_false = true_stmts[0], false_stmts[-1]
        if not (isinstance(true_stmt, IRAssign) and isinstance(last_false, IRAssign)):
            return None
        if not self._is_guard_default(true_stmt.expr):
            return None
        if not _structurally_equal(true_stmt.target, last_false.target):
            return None

        outer_defs = self._outer_defs(stmts, idx)
        # The taken branch materializes the element through its own temps
        # (backing storage, raw element, cast); every one of them must be a
        # temp definition, or this is not compiler-emitted guard code.
        branch_defs = dict(outer_defs)
        for inner in false_stmts[:-1]:
            if not (
                isinstance(inner, IRAssign)
                and isinstance(inner.target, IRLocal)
                and self._is_temp(inner.target)
            ):
                return None
            branch_defs[inner.target.name] = inner.expr

        cast_elem_type: Optional[tIndex] = None
        value = self._resolve(last_false.expr, branch_defs)
        while isinstance(value, IRCast):
            cast_elem_type = value.target_type_idx
            value = self._resolve(value.expr, branch_defs)
        if not isinstance(value, IRArrayAccess):
            return None

        if cond.left is None or cond.right is None:
            return None
        base = self._array_base(value.array, branch_defs)
        length = self._resolve(cond.right, outer_defs)
        if base is None or not (isinstance(length, IRField) and length.field_name == "length"):
            return None
        if not _structurally_equal(length.target, base):
            return None
        if not _structurally_equal(
            self._resolve(cond.left, outer_defs), self._resolve(value.index, branch_defs)
        ):
            return None

        new_access = IRArrayAccess(self.func.code, base, value.index, cast_elem_type)
        assign = IRAssign(self.func.code, true_stmt.target, new_access)
        assign.adopt(stmt, *false_stmts)
        # The hoisted length read exists only for the guard; drop it when the
        # collapsed access is its last reader.
        consumed: Set[int] = set()
        if isinstance(cond.right, IRLocal) and self._is_temp(cond.right):
            length_def = self._last_def(stmts, idx, cond.right)
            if length_def is not None and not self._read_after(stmts, idx, cond.right):
                consumed.add(length_def)
                assign.adopt(stmts[length_def])
        return assign, consumed

    def _last_def(self, stmts: List[IRStatement], before: int, local: IRLocal) -> Optional[int]:
        for k in range(before - 1, -1, -1):
            s = stmts[k]
            if isinstance(s, IRAssign) and isinstance(s.target, IRLocal) and s.target == local:
                return k
        return None

    def _read_after(self, stmts: List[IRStatement], idx: int, local: IRLocal) -> bool:
        used: Set[str] = set()
        for stmt in stmts[idx + 1 :]:
            if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal) and stmt.target == local:
                self._collect_used_in_expr(stmt.expr, used)
                return local.name in used
            self._collect_used_in_stmt(stmt, used)
            if local.name in used:
                return True
        return False

    def _collect_used_in_stmt(self, stmt: IRStatement, used: Set[str]) -> None:
        if isinstance(stmt, IRLocal):
            used.add(stmt.name)
        for child in stmt.get_children():
            self._collect_used_in_stmt(child, used)

    def _collect_used_in_expr(self, expr: IRExpression, used: Set[str]) -> None:
        self._collect_used_in_stmt(expr, used)


class IRArrayGuardResidueEliminator(TraversingIROptimizer):
    """
    Drops the storage reads left behind by a collapsed array access guard.

    Writing `a[i] = v` lowers to a capacity check that reads `a.length` and
    `a.bytes` (or `.array`) before the store. Once the store itself is
    recovered, those reads have no reader left, but dead-store elimination
    keeps them as bare statements because a field read on a null receiver
    faults. That fault is not lost by dropping them: the access that follows
    dereferences the very same array, in the same order.
    """

    _STORAGE_FIELDS = ("length", "bytes", "array")

    def visit_block(self, block: IRBlock) -> None:
        statements = block.statements
        kept = [stmt for idx, stmt in enumerate(statements) if not self._is_residue(statements, idx)]
        if len(kept) != len(statements):
            block.statements = kept

    def _is_residue(self, stmts: List[IRStatement], idx: int) -> bool:
        stmt = stmts[idx]
        if not (isinstance(stmt, IRField) and stmt.field_name in self._STORAGE_FIELDS):
            return False
        base = stmt.target
        if not isinstance(base, IRLocal):
            return False
        for later in stmts[idx + 1 :]:
            if self._dereferences(later, base):
                return True
            if self._reassigns(later, base):
                return False
        return False

    def _dereferences(self, stmt: IRStatement, base: IRLocal) -> bool:
        """Whether `stmt` faults on the same null receiver this read would."""
        if isinstance(stmt, IRArrayAccess) and _structurally_equal(stmt.array, base):
            return True
        if isinstance(stmt, IRField) and _structurally_equal(stmt.target, base):
            return True
        if isinstance(stmt, IRAssign):
            return self._dereferences(stmt.target, base) or self._dereferences(stmt.expr, base)
        if isinstance(stmt, IRBlock):
            # A nested block only runs conditionally; it cannot stand in for
            # the fault this statement would raise unconditionally.
            return False
        return any(self._dereferences(child, base) for child in stmt.get_children())

    def _reassigns(self, stmt: IRStatement, base: IRLocal) -> bool:
        if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
            return stmt.target == base
        return False


def _is_closure_producing_field(expr: IRExpression) -> bool:
    """True if `expr` is a field read whose value is a function/method.

    `obj.method` allocates a fresh bound-closure object on every evaluation
    (HL's InstanceClosure), unlike a data field read which just observes a
    value — so two syntactically identical `obj.method` reads are NOT the
    same value and must never be deduplicated to one.
    """
    if not isinstance(expr, IRField):
        return False
    try:
        kind = expr.get_type().kind.value
    except Exception:
        return False
    return kind in (Type.Kind.FUN.value, Type.Kind.METHOD.value)


class IRRedundantRecomputeEliminator(_ReferenceAwareOptimizer):
    """
    Rewrites `t1 = E; t2 = E;` (the same expression recomputed verbatim in the
    very next statement) into `t1 = E; t2 = t1;`.

    This undoes copy-propagation's effect on a `temp = expr; user = temp;`
    pattern when it inlined `expr` into the second assignment instead of
    leaving a plain copy: HashLink's own compiler always lowers compound
    assignment (`x += n`) to exactly that compute-then-copy shape (`Add`
    then `Mov`), so re-expanding the second assignment into a fresh `Add`
    produces extra opcodes that don't exist in the original bytecode.
    """

    def visit_block(self, block: IRBlock) -> None:
        new_statements: List[IRStatement] = []
        i = 0
        stmts = block.statements
        while i < len(stmts):
            stmt = stmts[i]
            nxt = stmts[i + 1] if i + 1 < len(stmts) else None
            if (
                nxt is not None
                and isinstance(stmt, IRAssign)
                and isinstance(stmt.target, IRLocal)
                and isinstance(nxt, IRAssign)
                and isinstance(nxt.target, IRLocal)
                and nxt.target != stmt.target
                and not isinstance(stmt.expr, (IRLocal, IRConst))
                and not _has_observable_effects(stmt.expr)
                and not _is_closure_producing_field(stmt.expr)
                and _structurally_equal(stmt.expr, nxt.expr)
            ):
                new_statements.append(stmt)
                new_statements.append(IRAssign(self.func.code, nxt.target, stmt.target).adopt(nxt))
                i += 2
                continue
            # `t = E; return E;` (or throw) — the terminator re-evaluates E
            # independently rather than reading t (e.g. left over from a
            # condition check that reused the checked value), so t's
            # assignment is pure overhead. Safe regardless of whether t is
            # used elsewhere: a return ends this path, so nothing after it
            # on this path could have read t anyway.
            if (
                nxt is not None
                and isinstance(stmt, IRAssign)
                and isinstance(stmt.target, IRLocal)
                and not self._is_address_taken(stmt.target)
                and not _has_observable_effects(stmt.expr)
                and not isinstance(stmt.expr, (IRLocal, IRConst))
                and isinstance(nxt, (IRReturn, IRThrow))
                and nxt.value is not None
                and _structurally_equal(stmt.expr, nxt.value)
            ):
                nxt.adopt(stmt)  # stmt is dropped; nxt (return/throw) is kept as-is below
                i += 1
                continue
            new_statements.append(stmt)
            i += 1
        block.statements = new_statements


class IRBlockFlattener(TraversingIROptimizer):
    """
    Flattens nested IRBlock structures. For example, an IRBlock child of another IRBlock
    will have its statements merged into the parent IRBlock. This simplifies the IR by
    removing unnecessary layers of blocks.

    This optimizer works by ensuring that any IRBlock child of a currently visited IRBlock
    is itself visited (and thus potentially flattened internally) before its statements
    are pulled up into the parent.
    """

    def visit_block(self, block: IRBlock) -> None:
        original_statements = list(block.statements)
        new_statements: List[IRStatement] = []

        made_structural_change = False

        for stmt in original_statements:
            if isinstance(stmt, IRBlock):
                self.visit(stmt)

                new_statements.extend(stmt.statements)
                made_structural_change = True
            else:
                new_statements.append(stmt)

        if made_structural_change or new_statements != original_statements:
            block.statements = new_statements
            dbg_print(
                f"IRBlockFlattener: Processed block. Original item count: {len(original_statements)}, New item count: {len(new_statements)}"
            )


class IREmptyConditionalNormalizer(TraversingIROptimizer):
    """
    Un-inverts `if (a >= b) {}` (both branches emptied by dead-store
    elimination, e.g. a dead bool materialization) back to `if (a < b) {}`.
    Lifting negates the bytecode jump's condition to make the fallthrough the
    true branch; with both branches empty the negation is pure residue, and
    the jump's own comparison is what the source contained (and what Haxe
    re-lowers an empty if back to).
    """

    def visit_block(self, block: IRBlock) -> None:
        for s in block.statements:
            if (
                isinstance(s, IRConditional)
                and not (s.true_block and s.true_block.statements)
                and not (s.false_block and s.false_block.statements)
                and isinstance(s.condition, IRBoolExpr)
                and s.condition.op
                in (
                    IRBoolExpr.CompareType.LT,
                    IRBoolExpr.CompareType.LTE,
                    IRBoolExpr.CompareType.GT,
                    IRBoolExpr.CompareType.GTE,
                    IRBoolExpr.CompareType.EQ,
                    IRBoolExpr.CompareType.NEQ,
                )
            ):
                s.condition.invert()


class IRElseFlattener(TraversingIROptimizer):
    """
    Flattens `if (c) { ...; return } else { A }` into `if (c) { ...; return } A`.
    When the true branch always terminates, the else block is the only
    continuation, so hoisting it exposes its statements to the sequential
    inliners. Skips DAG-shared else blocks to avoid duplicating statements.
    """

    def optimize(self) -> None:
        self._block_refs: Dict[int, int] = {}
        if hasattr(self.func, "block"):
            self._count_refs(self.func.block, set())
        super().optimize()

    def _count_refs(self, block: IRBlock, visited: Set[int]) -> None:
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self._block_refs[id(child)] = self._block_refs.get(id(child), 0) + 1
                    if id(child) not in visited:
                        visited.add(id(child))
                        self._count_refs(child, visited)

    def visit_block(self, block: IRBlock) -> None:
        new_statements: List[IRStatement] = []
        for stmt in block.statements:
            new_statements.append(stmt)
            if (
                isinstance(stmt, IRConditional)
                and stmt.false_block is not None
                and stmt.false_block.statements
                and stmt.true_block.statements
                and isinstance(
                    stmt.true_block.statements[-1],
                    (IRReturn, IRThrow, IRBreak, IRContinue),
                )
                and self._block_refs.get(id(stmt.false_block), 0) <= 1
            ):
                new_statements.extend(stmt.false_block.statements)
                stmt.false_block = IRBlock(self.func.code)
        block.statements = new_statements


class IRCommonBlockMerger(TraversingIROptimizer):
    """
    Finds IRConditional statements where both the true and false blocks end
    with the same sequence of statements. It "hoists" this common suffix out
    of the conditional and places it after the if/else block.

    For example:
        if (cond) {
            do_a();
            common_code();
        } else {
            do_b();
            common_code();
        }

    Becomes:
        if (cond) {
            do_a();
        } else {
            do_b();
        }
        common_code();
    """

    def visit_block(self, block: IRBlock) -> None:
        made_change = False
        new_statements: List[IRStatement] = []

        for stmt in block.statements:
            if isinstance(stmt, IRConditional):
                # We can only merge if there is an 'else' block
                if not stmt.false_block or not stmt.false_block.statements:
                    new_statements.append(stmt)
                    continue

                true_stmts = stmt.true_block.statements
                false_stmts = stmt.false_block.statements

                common_suffix: List[IRStatement] = []
                # Compare statements from the end of each block
                t_idx, f_idx = len(true_stmts) - 1, len(false_stmts) - 1
                while t_idx >= 0 and f_idx >= 0:
                    # Cheap type check first: a mismatch here means the repr()s can never
                    # be equal, so we skip fully rendering large nested subtrees (e.g. a
                    # branch ending in a deeply nested IRConditional from a cascading
                    # if/elif chain) just to find out they differ.
                    if type(true_stmts[t_idx]) is not type(false_stmts[f_idx]):
                        break
                    # Structural comparison without rendering: repr()/pformat on
                    # the IR DAG re-expands shared continuation blocks and is
                    # exponential for branchy code. _ir_structurally_equal walks
                    # the pair in lockstep with memoization instead.
                    if _ir_structurally_equal(true_stmts[t_idx], false_stmts[f_idx]):
                        # Prepend to keep the order correct
                        common_suffix.insert(0, true_stmts[t_idx])
                        t_idx -= 1
                        f_idx -= 1
                    else:
                        break

                if common_suffix:
                    dbg_print(f"IRCommonBlockMerger: Found {len(common_suffix)} common statements to merge.")
                    made_change = True

                    # Truncate the original blocks
                    stmt.true_block.statements = true_stmts[: t_idx + 1]
                    stmt.false_block.statements = false_stmts[: f_idx + 1]

                    # Add the modified conditional, then the common code after it.
                    new_statements.append(stmt)
                    new_statements.extend(common_suffix)
                else:
                    new_statements.append(stmt)
            else:
                new_statements.append(stmt)

        if made_change:
            block.statements = new_statements


class IRRedundantContinueEliminator(TraversingIROptimizer):
    """
    Removes redundant `else { continue; }` blocks that are the last statement
    of a loop body. After the if-block, control naturally falls through to the
    end of the loop body, which is equivalent to continuing the loop, so the
    explicit else-continue is just noise.
    """

    def __init__(self, function: "IRFunction") -> None:
        super().__init__(function)
        self._loop_depth = 0

    def before_visit_statement(self, statement: IRStatement) -> None:
        if isinstance(statement, (IRWhileLoop, IRPrimitiveLoop)):
            self._loop_depth += 1

    def after_visit_statement(self, statement: IRStatement) -> None:
        if isinstance(statement, (IRWhileLoop, IRPrimitiveLoop)):
            self._loop_depth -= 1

    def visit_block(self, block: IRBlock) -> None:
        if self._loop_depth == 0 or not block.statements:
            super().visit_block(block)
            return

        last = block.statements[-1]
        if isinstance(last, IRConditional) and last.false_block is not None:
            false_stmts = [s for s in last.false_block.statements if not isinstance(s, IRReturn)]
            if len(false_stmts) == 1 and isinstance(false_stmts[0], IRContinue):
                dbg_print("IRRedundantContinueEliminator: removing trailing else { continue; }")
                last.false_block = IRBlock(self.func.code)
                last.false_block.statements = []

        super().visit_block(block)


class IRVoidAssignOptimizer(TraversingIROptimizer):
    """
    Removes assignments to IRLocals of type Void, keeping the expression
    for its side effects and annotating the discard.
    E.g., `var_void_local:Void = some_call();` becomes `some_call();`
    """

    def visit_block(self, block: IRBlock) -> None:
        new_statements: List[IRStatement] = []
        made_change_this_pass = False

        for stmt in block.statements:
            if isinstance(stmt, IRAssign):
                target = stmt.target
                if isinstance(target, IRLocal):
                    target_type_resolved = target.type.resolve(self.func.code)
                    if target_type_resolved.kind.value == Type.Kind.VOID.value:
                        if DEBUG:
                            dbg_print(
                                f"IRVoidAssignOptimizer: Removing void assignment: {stmt} (target: {target.name})"
                            )

                        expr_being_kept = stmt.expr
                        expr_being_kept.adopt(stmt)  # opcode was tagged on the assign, not its expr
                        new_statements.append(expr_being_kept)
                        made_change_this_pass = True
                        continue
            new_statements.append(stmt)

        if made_change_this_pass:
            block.statements = new_statements


class IRDeadTempEliminator(_ReferenceAwareOptimizer):
    """Removes assignments to compiler-generated temp variables that are never read."""

    def optimize(self) -> None:
        if not hasattr(self.func, "block"):
            return
        user_names = self._collect_user_names()
        user_regs = self._collect_user_reg_indices()
        globally_used = self._collect_all_used_names(self.func.block)
        self._remove_dead(self.func.block, user_names, user_regs, globally_used)

    def _collect_user_names(self) -> Set[str]:
        names: Set[str] = set()
        if self.func.func.has_debug and self.func.func.assigns:
            for name_ref, _ in self.func.func.assigns:
                names.add(name_ref.resolve(self.func.code))
        return names

    def _collect_user_reg_indices(self) -> Set[int]:
        indices: Set[int] = set()
        if self.func.func.has_debug and self.func.func.assigns:
            for _, op_idx in self.func.func.assigns:
                val = op_idx.value - 1
                if val >= 0 and val < len(self.func.ops):
                    op = self.func.ops[val]
                    try:
                        indices.add(op.df["dst"].value)
                    except KeyError:
                        pass
        return indices

    def _is_user_local(self, local: IRLocal, user_names: Set[str], user_regs: Set[int]) -> bool:
        if local.name in user_names:
            return True
        # Preserve names like `b1` that were generated to disambiguate two
        # user-named locals with different types.
        for name in user_names:
            if local.name.startswith(name) and local.name[len(name) :].isdigit():
                return True
        if local.name.startswith("var"):
            try:
                idx = int(local.name[3:])
                if idx in user_regs:
                    return True
            except ValueError:
                pass
        return False

    def _is_dead_removable(self, local: IRLocal, user_names: Set[str], user_regs: Set[int]) -> bool:
        """Return True if an unread assignment to `local` is safe to delete.

        Non-user locals are always removable. A purely synthetic `varN` temp is
        also removable even when its register index is reused by a user variable:
        the caller has already confirmed the name is never read anywhere, so the
        register-reuse protection (meant to keep live SSA-split user values) does
        not apply. User-named locals (real names, or `nameN` disambiguations) are
        never removed here.
        """
        if not self._is_user_local(local, user_names, user_regs):
            return True
        if local.name in user_names:
            return False
        for name in user_names:
            if local.name.startswith(name) and local.name[len(name) :].isdigit():
                return False
        # Only reached for `varN` names kept alive solely by register reuse.
        return bool(re.fullmatch(r"var\d+", local.name))

    def _collect_all_used_names(self, block: IRBlock, _visited: Optional[Set[int]] = None) -> Set[str]:
        # DAG-aware: shared continuation blocks are reachable from many parents,
        # so prune already-visited blocks to avoid exponential re-walks.
        if _visited is None:
            _visited = set()
        used: Set[str] = set()
        if id(block) in _visited:
            return used
        _visited.add(id(block))
        for stmt in block.statements:
            self._collect_used_in_stmt(stmt, used)
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    used.update(self._collect_all_used_names(child, _visited))
        return used

    def _collect_used_in_stmt(self, stmt: IRStatement, used: Set[str]) -> None:
        if isinstance(stmt, IRAssign):
            self._collect_used_in_expr(stmt.expr, used)
            # For array-element assignments, the array/index expressions are still reads.
            if isinstance(stmt.target, IRArrayAccess):
                self._collect_used_in_expr(stmt.target.array, used)
                self._collect_used_in_expr(stmt.target.index, used)
            # For field-store assignments (`obj.field = value`), the object
            # expression is still a read, even though the statement as a whole
            # is a write.
            elif isinstance(stmt.target, IRField):
                self._collect_used_in_expr(stmt.target.target, used)
        elif isinstance(stmt, IRReturn) and stmt.value:
            self._collect_used_in_expr(stmt.value, used)
        elif isinstance(stmt, IRThrow):
            self._collect_used_in_expr(stmt.value, used)
        elif isinstance(stmt, IRCall):
            self._collect_used_in_expr(stmt.target, used)
            for arg in stmt.args:
                self._collect_used_in_expr(arg, used)
        elif isinstance(stmt, IRTrace):
            self._collect_used_in_expr(stmt.msg, used)
        elif isinstance(stmt, IRConditional):
            self._collect_used_in_expr(stmt.condition, used)
        elif isinstance(stmt, IRWhileLoop):
            self._collect_used_in_expr(stmt.condition, used)
        elif isinstance(stmt, IRPrimitiveLoop):
            used.update(self._collect_all_used_names(stmt.condition))
        elif isinstance(stmt, IRSwitch):
            self._collect_used_in_expr(stmt.value, used)
        else:
            # Generic fallback (e.g. IRRefSet): treat any expression child as a
            # read, so a missing case can't delete a still-needed assignment.
            for child in stmt.get_children():
                if isinstance(child, IRExpression):
                    self._collect_used_in_expr(child, used)

    def _collect_used_in_expr(self, expr: Optional[IRExpression], used: Set[str]) -> None:
        if expr is None:
            return
        if isinstance(expr, IRLocal):
            used.add(expr.name)
        elif isinstance(expr, IRArithmetic):
            self._collect_used_in_expr(expr.left, used)
            self._collect_used_in_expr(expr.right, used)
        elif isinstance(expr, IRArrayAccess):
            self._collect_used_in_expr(expr.array, used)
            self._collect_used_in_expr(expr.index, used)
        elif isinstance(expr, IRArrayLiteral):
            for element in expr.elements:
                self._collect_used_in_expr(element, used)
        elif isinstance(expr, IRBoolExpr):
            self._collect_used_in_expr(expr.left, used)
            self._collect_used_in_expr(expr.right, used)
        elif isinstance(expr, IRCast):
            self._collect_used_in_expr(expr.expr, used)
        elif isinstance(expr, IRCall):
            self._collect_used_in_expr(expr.target, used)
            for arg in expr.args:
                self._collect_used_in_expr(arg, used)
        elif isinstance(expr, IREnumConstruct):
            for arg in expr.args:
                self._collect_used_in_expr(arg, used)
        elif isinstance(expr, IREnumField):
            self._collect_used_in_expr(expr.value, used)
        elif isinstance(expr, IREnumIndex):
            self._collect_used_in_expr(expr.value, used)
        elif isinstance(expr, IRField):
            self._collect_used_in_expr(expr.target, used)
        elif isinstance(expr, IRNew):
            for arg in expr.constructor_args:
                self._collect_used_in_expr(arg, used)
        elif isinstance(expr, IRRef):
            self._collect_used_in_expr(expr.target, used)
        else:
            # Fall back to generic traversal for any expression type not
            # explicitly listed above (e.g. IRNativeArrayNew/IRNativeMapNew),
            # so a missing case here can't silently treat a real read as
            # absent and delete a still-needed assignment as dead.
            for child in expr.get_children():
                if isinstance(child, IRExpression):
                    self._collect_used_in_expr(child, used)

    def _remove_dead(
        self,
        block: IRBlock,
        user_names: Set[str],
        user_regs: Set[int],
        globally_used: Set[str],
        _visited: Optional[Set[int]] = None,
    ) -> None:
        # DAG-aware: prune already-processed shared blocks. Removing a dead temp
        # in a shared block once applies to every path that references it.
        if _visited is None:
            _visited = set()
        if id(block) in _visited:
            return
        _visited.add(id(block))
        new_stmts: List[IRStatement] = []
        for stmt in block.statements:
            if (
                isinstance(stmt, IRAssign)
                and isinstance(stmt.target, IRLocal)
                and not self._is_address_taken(stmt.target)
                and stmt.target.name not in globally_used
                and self._is_dead_removable(stmt.target, user_names, user_regs)
            ):
                dbg_print(f"Removing dead temp assignment '{stmt.target.name}'.")
                # Preserve the entire evaluation, including nested calls and
                # exceptions from reads/casts, even when its result is dead.
                # A numeric-representation cast (Int -> Float, ...) is pure —
                # `_has_observable_effects` only flags it because a checked
                # downcast can throw — so a dead one is dropped outright.
                if _has_observable_effects(stmt.expr) and not _is_pure_numeric_cast_tree(stmt.expr):
                    stmt.expr.adopt(stmt)  # opcode was tagged on the assign, not its expr
                    new_stmts.append(stmt.expr)
                continue
            new_stmts.append(stmt)
        block.statements = new_stmts
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self._remove_dead(child, user_names, user_regs, globally_used, _visited)


class IRDeadCodeEliminator(TraversingIROptimizer):
    """Removes statements after terminators (return, break, continue) within the same block."""

    def _body_has_break(self, block: IRBlock) -> bool:
        """Return True if the block (recursively) contains an IRBreak."""
        for stmt in block.statements:
            if isinstance(stmt, IRBreak):
                return True
            for child in stmt.get_children():
                if isinstance(child, IRBlock) and self._body_has_break(child):
                    return True
        return False

    def _is_infinite_loop(self, stmt: IRStatement) -> bool:
        if not isinstance(stmt, IRWhileLoop):
            return False
        cond = stmt.condition
        if isinstance(cond, IRBoolExpr):
            if cond.op == IRBoolExpr.CompareType.TRUE:
                return True
            if (
                cond.op == IRBoolExpr.CompareType.ISTRUE
                and isinstance(cond.left, IRConst)
                and cond.left.value is True
            ):
                return True
        return False

    def visit_block(self, block: IRBlock) -> None:
        new_stmts: List[IRStatement] = []
        terminated = False
        for stmt in block.statements:
            if terminated:
                continue
            if isinstance(stmt, IRConst):
                # A constant evaluated for nothing: the element-type marker HL
                # emits before an array allocation survives as one of these
                # once the allocation it annotated has been recovered.
                continue
            new_stmts.append(stmt)
            if isinstance(stmt, (IRReturn, IRBreak, IRContinue, IRThrow)):
                terminated = True
            elif (
                self._is_infinite_loop(stmt)
                and isinstance(stmt, IRPrimitiveLoop)
                and not self._body_has_break(stmt.body)
            ):
                terminated = True
        block.statements = new_stmts
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)


class IRDeadStoreEliminator(_ReferenceAwareOptimizer):
    """Removes local assignments that are overwritten before being read within a block."""

    def visit_block(self, block: IRBlock) -> None:
        def _locals_in_expr(expr: Optional[IRExpression]) -> Set[IRLocal]:
            found: Set[IRLocal] = set()
            if expr is None:
                return found
            if isinstance(expr, IRLocal):
                found.add(expr)
            elif isinstance(expr, (IRArithmetic, IRBoolExpr)):
                found.update(_locals_in_expr(expr.left))
                found.update(_locals_in_expr(expr.right))
            elif isinstance(expr, IRArrayAccess):
                found.update(_locals_in_expr(expr.array))
                found.update(_locals_in_expr(expr.index))
            elif isinstance(expr, (IRField, IRCast, IRNeg, IRNot, IRTypeOf, IRTypeKind, IREnumIndex)):
                target = getattr(expr, "target", getattr(expr, "expr", getattr(expr, "value", None)))
                found.update(_locals_in_expr(target))
            elif isinstance(expr, IRCall):
                if expr.target is not None:
                    found.update(_locals_in_expr(expr.target))
                for arg in expr.args:
                    found.update(_locals_in_expr(arg))
            elif isinstance(expr, IRNew):
                for arg in expr.constructor_args:
                    found.update(_locals_in_expr(arg))
            elif isinstance(expr, IRArrayLiteral):
                for element in expr.elements:
                    found.update(_locals_in_expr(element))
            elif isinstance(expr, IREnumConstruct):
                for arg in expr.args:
                    found.update(_locals_in_expr(arg))
            elif isinstance(expr, IREnumField):
                found.update(_locals_in_expr(expr.value))
            elif isinstance(expr, IRRef):
                found.update(_locals_in_expr(expr.target))
            else:
                # Fall back to generic traversal for any expression type not
                # explicitly listed above (e.g. IRNativeArrayNew/IRNativeMapNew)
                # so a missing case here can't silently treat a real read as
                # absent and prune a still-needed assignment as dead.
                for child in expr.get_children():
                    if isinstance(child, IRExpression):
                        found.update(_locals_in_expr(child))
            return found

        def _reads_in_stmt(stmt: IRStatement) -> Set[IRLocal]:
            reads: Set[IRLocal] = set()
            if isinstance(stmt, IRAssign):
                reads.update(_locals_in_expr(stmt.expr))
                if isinstance(stmt.target, IRArrayAccess):
                    reads.update(_locals_in_expr(stmt.target.array))
                    reads.update(_locals_in_expr(stmt.target.index))
                elif isinstance(stmt.target, IRField):
                    reads.update(_locals_in_expr(stmt.target.target))
            elif isinstance(stmt, (IRReturn, IRThrow)) and stmt.value is not None:
                reads.update(_locals_in_expr(stmt.value))
            elif isinstance(stmt, IRCall):
                if stmt.target is not None:
                    reads.update(_locals_in_expr(stmt.target))
                for arg in stmt.args:
                    reads.update(_locals_in_expr(arg))
            elif isinstance(stmt, IRTrace):
                reads.update(_locals_in_expr(stmt.msg))
            elif isinstance(stmt, IRConditional):
                reads.update(_locals_in_expr(stmt.condition))
            elif isinstance(stmt, IRWhileLoop):
                reads.update(_locals_in_expr(stmt.condition))
            elif isinstance(stmt, IRSwitch):
                reads.update(_locals_in_expr(stmt.value))
            return reads

        def _written_local(stmt: IRStatement) -> Optional[IRLocal]:
            if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
                return stmt.target
            return None

        # First use of `local` along every path through a statement:
        # "read" (value needed), "kill" (dead on all paths: overwritten before
        # any read, or the path terminates), or "none" (untouched).
        def _first_use(stmt: IRStatement, local: IRLocal, _visited: Optional[Set[int]] = None) -> str:
            if _visited is None:
                _visited = set()
            if id(stmt) in _visited:
                return "none"
            _visited.add(id(stmt))

            if isinstance(stmt, IRAssign):
                if _reads_in_stmt(stmt) & {local}:
                    return "read"
                if isinstance(stmt.target, IRLocal) and (
                    stmt.target == local or stmt.target.same_register(local)
                ):
                    return "kill"
                return "none"
            if isinstance(stmt, (IRBreak, IRContinue)):
                # jumps to a continuation this block-level scan can't see
                return "read"
            if isinstance(stmt, (IRReturn, IRThrow)):
                if _reads_in_stmt(stmt) & {local}:
                    return "read"
                return "kill"
            if isinstance(stmt, IRConditional):
                if _locals_in_expr(stmt.condition) & {local}:
                    return "read"
                branches = [stmt.true_block.statements]
                branches.append(stmt.false_block.statements if stmt.false_block else [])
                results = [_first_use_in_list(b, local, _visited) for b in branches]
                if "read" in results:
                    return "read"
                if all(r == "kill" for r in results):
                    return "kill"
                return "none"
            if isinstance(stmt, IRSwitch):
                if _locals_in_expr(stmt.value) & {local}:
                    return "read"
                branches = [c.statements for c in stmt.cases.values()]
                branches.append(stmt.default.statements if stmt.default else [])
                results = [_first_use_in_list(b, local, _visited) for b in branches]
                if "read" in results:
                    return "read"
                if all(r == "kill" for r in results):
                    return "kill"
                return "none"
            if isinstance(stmt, IRExpression):
                return "read" if local in _locals_in_expr(stmt) else "none"
            # Loops, try/catch and anything else with nested blocks: any
            # occurrence at all is conservatively a read.
            if _reads_in_stmt(stmt) & {local}:
                return "read"
            for child in stmt.get_children():
                child_stmts = child.statements if isinstance(child, IRBlock) else [child]
                for s in child_stmts:
                    if _first_use(s, local, set()) != "none":
                        return "read"
            return "none"

        def _first_use_in_list(stmts: List[IRStatement], local: IRLocal, _visited: Set[int]) -> str:
            for s in stmts:
                r = _first_use(s, local, _visited)
                if r != "none":
                    return r
            return "none"

        user_names = self._collect_user_names()
        user_regs = self._collect_user_reg_indices()

        new_stmts = []
        for i, stmt in enumerate(block.statements):
            target = _written_local(stmt)
            if (
                target is not None
                and not self._is_address_taken(target)
                and isinstance(stmt, IRAssign)
                and not _has_observable_effects(stmt.expr)
                and _first_use_in_list(block.statements[i + 1 :], target, set()) == "kill"
                and not self._is_user_local(target, user_names, user_regs)
            ):
                if DEBUG:
                    dbg_print(f"IRDeadStoreEliminator: removing dead store {stmt}")
                continue
            new_stmts.append(stmt)

        block.statements = new_stmts
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)

    def _collect_user_names(self) -> Set[str]:
        names: Set[str] = set()
        if self.func.func.has_debug and self.func.func.assigns:
            for name_ref, _ in self.func.func.assigns:
                names.add(name_ref.resolve(self.func.code))
        return names

    def _collect_user_reg_indices(self) -> Set[int]:
        indices: Set[int] = set()
        if self.func.func.has_debug and self.func.func.assigns:
            for _, op_idx in self.func.func.assigns:
                val = op_idx.value - 1
                if val >= 0 and val < len(self.func.ops):
                    op = self.func.ops[val]
                    try:
                        indices.add(op.df["dst"].value)
                    except KeyError:
                        pass
        return indices

    def _is_user_local(self, local: IRLocal, user_names: Set[str], user_regs: Set[int]) -> bool:
        if local.name in user_names:
            return True
        for name in user_names:
            if local.name.startswith(name) and local.name[len(name) :].isdigit():
                return True
        if local.name.startswith("var"):
            try:
                idx = int(local.name[3:])
                if idx in user_regs:
                    return True
            except ValueError:
                pass
        return False


class IRSequentialTempFolder(_ReferenceAwareOptimizer):
    """Folds a simple local assignment into the very next assignment to the same local.

    Patterns like `var1 = this.bytes; var1 = Native.f(var1, ...)` are simplified
    to `var1 = Native.f(this.bytes, ...)` and the first assignment is dropped.
    The source expression must be side-effect free and must not reference the
    target local.
    """

    def visit_block(self, block: IRBlock) -> None:
        changed = True
        while changed:
            changed = False
            i = 0
            while i < len(block.statements) - 1:
                stmt = block.statements[i]
                nxt = block.statements[i + 1]
                if not (
                    isinstance(stmt, IRAssign)
                    and isinstance(stmt.target, IRLocal)
                    and not self._is_address_taken(stmt.target)
                    and not self._reads_address_taken(stmt.expr)
                    and self._is_simple_expr(stmt.expr)
                    and not self._expr_uses_local(stmt.expr, stmt.target)
                    and isinstance(nxt, IRAssign)
                    and isinstance(nxt.target, IRLocal)
                    and nxt.target == stmt.target
                ):
                    i += 1
                    continue
                replaced = self._replace_local_in_expr(nxt.expr, stmt.target, stmt.expr)
                if not replaced:
                    # The next RHS may also use the local through its target (e.g. array index).
                    if isinstance(nxt.target, IRArrayAccess):
                        replaced |= self._replace_local_in_expr(nxt.target.array, stmt.target, stmt.expr)
                        replaced |= self._replace_local_in_expr(nxt.target.index, stmt.target, stmt.expr)
                    if not replaced:
                        i += 1
                        continue
                nxt.adopt(stmt)  # stmt is dropped, folded into nxt's RHS
                block.statements.pop(i)
                changed = True
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)

    def _is_simple_expr(self, expr: IRExpression) -> bool:
        return not _has_observable_effects(expr)

    def _expr_uses_local(self, expr: IRExpression, local: IRLocal) -> bool:
        if expr == local:
            return True
        return any(
            self._expr_uses_local(child, local)
            for child in expr.get_children()
            if isinstance(child, IRExpression)
        )

    def _replace_local_in_expr(self, expr: IRExpression, local: IRLocal, replacement: IRExpression) -> bool:
        if isinstance(expr, (IRRef, IRRefNew)):
            return False
        if expr == local:
            return True
        made_change = False
        # get_children returns a list of child statements/expressions.  We only
        # mutate expression children.
        children = expr.get_children()
        for i, child in enumerate(children):
            if not isinstance(child, IRExpression):
                continue
            if child == local:
                # Use the type-specific setter to keep the IR node intact.
                if self._set_child(expr, i, replacement):
                    made_change = True
                continue
            if self._replace_local_in_expr(child, local, replacement):
                made_change = True
        return made_change

    def _set_child(self, parent: IRExpression, index: int, value: IRExpression) -> bool:
        children = parent.get_children()
        if index >= len(children):
            return False
        child = children[index]
        if isinstance(parent, (IRArithmetic, IRBoolExpr)):
            if child is parent.left:
                parent.left = value
                return True
            if child is parent.right:
                parent.right = value
                return True
        elif isinstance(parent, IRCall):
            for j, arg in enumerate(parent.args):
                if arg is child:
                    parent.args[j] = value
                    return True
        elif isinstance(parent, IRField):
            if child is parent.target:
                parent.target = value
                return True
        elif isinstance(parent, IRCast):
            if child is parent.expr:
                parent.expr = value
                return True
        elif isinstance(parent, (IRNeg, IRNot, IRTypeOf, IRTypeKind, IREnumIndex)):
            attr = "expr" if hasattr(parent, "expr") else "value"
            if getattr(parent, attr) is child:
                setattr(parent, attr, value)
                return True
        elif isinstance(parent, IRArrayAccess):
            if child is parent.array:
                parent.array = value
                return True
            if child is parent.index:
                parent.index = value
                return True
        elif isinstance(parent, IREnumConstruct):
            for j, arg in enumerate(parent.args):
                if arg is child:
                    parent.args[j] = value
                    return True
        elif isinstance(parent, IREnumField):
            if child is parent.value:
                parent.value = value
                return True
        elif isinstance(parent, IRArrayLiteral):
            for j, element in enumerate(parent.elements):
                if element is child:
                    parent.elements[j] = value
                    return True
        elif isinstance(parent, IRNativeArrayNew):
            if child is parent.size:
                parent.size = value
                return True
        elif isinstance(parent, IRNew):
            for j, arg in enumerate(parent.constructor_args):
                if arg is child:
                    parent.constructor_args[j] = value
                    return True
        return False


class IRDeadAssignmentEliminator(_ReferenceAwareOptimizer):
    """Removes assignments to locals that are never read before being redefined.

    Performs a structured backward liveness sweep keyed by local *name* (HL IR
    may split a single local into several objects).  Each block is processed
    with a live-out set so that assignments feeding into later statements,
    sibling branches, loop conditions, or code after a loop are never dropped.
    """

    def optimize(self) -> None:
        if not hasattr(self.func, "block"):
            return
        self._block_live: Dict[int, Tuple[Set[str], Set[str]]] = {}
        self._process_block(self.func.block, set())

    def _local_name(self, local: IRLocal) -> str:
        return local.name

    def _process_block(self, block: IRBlock, live_out: Set[str], mutate: bool = True) -> Set[str]:
        block_id = id(block)
        if mutate:
            cached = self._block_live.get(block_id)
            if cached is not None:
                cached_out, cached_in = cached
                if live_out.issubset(cached_out):
                    return cached_in
                live_out = cached_out | live_out

        live: Set[str] = set(live_out)
        new_stmts: List[IRStatement] = []

        for stmt in reversed(block.statements):
            uses, defs = self._stmt_uses_and_defs(stmt, live, mutate=mutate)
            if (
                mutate
                and isinstance(stmt, IRAssign)
                and isinstance(stmt.target, IRLocal)
                and not self._is_address_taken(stmt.target)
                and self._local_name(stmt.target) not in live
            ):
                if self._is_user_local_name(self._local_name(stmt.target)):
                    # Preserve dead stores to user-named locals so the source
                    # round-trip stays faithful to the original bytecode.
                    new_stmts.append(stmt)
                elif _has_observable_effects(stmt.expr):
                    # Keep the side effects as a bare expression statement.
                    stmt.expr.adopt(stmt)  # opcode was tagged on the assign, not its expr
                    new_stmts.append(stmt.expr)
                # else: drop the dead assignment entirely for compiler temps.
                # For kept statements, still update liveness; dropped ones don't.
                live.difference_update(defs)
                live.update(uses)
                continue
            if mutate:
                new_stmts.append(stmt)
            live.difference_update(defs)
            live.update(uses)

        if mutate:
            block.statements = list(reversed(new_stmts))
            self._block_live[block_id] = (live_out, live)
        return live

    def _stmt_uses_and_defs(
        self, stmt: IRStatement, live_after_stmt: Set[str], mutate: bool = True
    ) -> Tuple[Set[str], Set[str]]:
        uses: Set[str] = set()
        defs: Set[str] = set()

        if isinstance(stmt, IRAssign):
            uses.update(self._locals_in_expr(stmt.expr))
            if isinstance(stmt.target, IRArrayAccess):
                uses.update(self._locals_in_expr(stmt.target.array))
                uses.update(self._locals_in_expr(stmt.target.index))
            elif isinstance(stmt.target, IRField):
                uses.update(self._locals_in_expr(stmt.target.target))
            elif isinstance(stmt.target, IRLocal):
                defs.add(self._local_name(stmt.target))
        elif isinstance(stmt, (IRReturn, IRThrow)) and stmt.value is not None:
            uses.update(self._locals_in_expr(stmt.value))
        elif isinstance(stmt, IRCall):
            if stmt.target is not None:
                uses.update(self._locals_in_expr(stmt.target))
            for arg in stmt.args:
                uses.update(self._locals_in_expr(arg))
        elif isinstance(stmt, IRTrace):
            uses.update(self._locals_in_expr(stmt.msg))
        elif isinstance(stmt, (IRConditional, IRWhileLoop)):
            uses.update(self._locals_in_expr(stmt.condition))
        elif isinstance(stmt, IRSwitch):
            uses.update(self._locals_in_expr(stmt.value))
        else:
            # Generic fallback (e.g. IRRefSet): expression children are reads.
            for child in stmt.get_children():
                if isinstance(child, IRExpression):
                    uses.update(self._locals_in_expr(child))

        # Recursively process nested blocks with the correct live-out sets.
        if isinstance(stmt, IRConditional):
            child_out = set(live_after_stmt)
            true_in = (
                self._process_block(stmt.true_block, child_out, mutate=mutate) if stmt.true_block else set()
            )
            false_in = (
                self._process_block(stmt.false_block, child_out, mutate=mutate) if stmt.false_block else set()
            )
            uses.update(true_in)
            uses.update(false_in)
        elif isinstance(stmt, IRWhileLoop):
            body_in = self._process_loop_body(
                stmt.body,
                live_after_stmt,
                self._locals_in_expr(stmt.condition),
                mutate=mutate,
            )
            uses.update(body_in)
        elif isinstance(stmt, IRPrimitiveLoop):
            cond_uses: Set[str] = set()
            body_in = self._process_loop_body(stmt.body, live_after_stmt, cond_uses, mutate=mutate)
            uses.update(body_in)
            uses.update(cond_uses)
        elif isinstance(stmt, IRForEachLoop):
            array_uses = self._locals_in_expr(stmt.array) if hasattr(stmt, "array") else set()
            body_in = self._process_loop_body(stmt.body, live_after_stmt, array_uses, mutate=mutate)
            uses.update(body_in)
            uses.update(array_uses)
        elif isinstance(stmt, IRIntRangeLoop):
            header_uses = self._locals_in_expr(stmt.start) | self._locals_in_expr(stmt.end)
            body_in = self._process_loop_body(stmt.body, live_after_stmt, header_uses, mutate=mutate)
            uses.update(body_in)
            uses.update(header_uses)
        elif isinstance(stmt, IRSwitch):
            child_out = set(live_after_stmt)
            for case_block in stmt.cases.values():
                uses.update(self._process_block(case_block, child_out, mutate=mutate))
            if stmt.default is not None:
                uses.update(self._process_block(stmt.default, child_out, mutate=mutate))
        elif isinstance(stmt, IRTryCatch):
            child_out = set(live_after_stmt)
            try_in = self._process_block(stmt.try_block, child_out, mutate=mutate)
            catch_in = self._process_block(stmt.catch_block, child_out, mutate=mutate)
            uses.update(try_in)
            uses.update(catch_in)
            for _, extra_block in stmt.extra_catches:
                uses.update(self._process_block(extra_block, child_out, mutate=mutate))

        return uses, defs

    def _process_loop_body(
        self,
        body: IRBlock,
        live_after: Set[str],
        header_uses: Set[str],
        mutate: bool = True,
    ) -> Set[str]:
        """Process a loop body to a fixed point so loop-carried assignments live.

        We must not mutate ``body`` until the live-in set stabilises, because the
        first backward pass would otherwise drop loop-carried assignments whose
        uses appear earlier in the source order (later in reverse).
        """
        if not mutate:
            return self._compute_block_live_in(body, live_after | header_uses)

        child_out = live_after | header_uses
        while True:
            body_in = self._compute_block_live_in(body, child_out)
            next_out = live_after | header_uses | body_in
            if next_out == child_out:
                break
            child_out = next_out
        return self._process_block(body, child_out)

    def _compute_block_live_in(self, block: IRBlock, live_out: Set[str]) -> Set[str]:
        """Return the live-in set for ``block`` without mutating it."""
        live: Set[str] = set(live_out)
        for stmt in reversed(block.statements):
            uses, defs = self._stmt_uses_and_defs(stmt, live, mutate=False)
            live.difference_update(defs)
            live.update(uses)
        return live

    def _is_user_local_name(self, name: str) -> bool:
        if not self.func.func.has_debug or not self.func.func.assigns:
            return False
        user_names = {name_ref.resolve(self.func.code) for name_ref, _ in self.func.func.assigns}
        if name in user_names:
            return True
        for un in user_names:
            if name.startswith(un) and name[len(un) :].isdigit():
                return True
        return False

    def _locals_in_expr(self, expr: Optional[IRExpression]) -> Set[str]:
        found: Set[str] = set()
        if expr is None:
            return found
        if isinstance(expr, IRLocal):
            found.add(self._local_name(expr))
        elif isinstance(expr, (IRArithmetic, IRBoolExpr)):
            found.update(self._locals_in_expr(expr.left))
            found.update(self._locals_in_expr(expr.right))
        elif isinstance(expr, IRArrayAccess):
            found.update(self._locals_in_expr(expr.array))
            found.update(self._locals_in_expr(expr.index))
        elif isinstance(expr, (IRField, IRCast, IRNeg, IRNot, IRTypeOf, IRTypeKind, IREnumIndex)):
            target = getattr(expr, "target", getattr(expr, "expr", getattr(expr, "value", None)))
            found.update(self._locals_in_expr(target))
        elif isinstance(expr, IRCall):
            if expr.target is not None:
                found.update(self._locals_in_expr(expr.target))
            for arg in expr.args:
                found.update(self._locals_in_expr(arg))
        elif isinstance(expr, IRNew):
            for arg in expr.constructor_args:
                found.update(self._locals_in_expr(arg))
        elif isinstance(expr, IRArrayLiteral):
            for element in expr.elements:
                found.update(self._locals_in_expr(element))
        elif isinstance(expr, IREnumConstruct):
            for arg in expr.args:
                found.update(self._locals_in_expr(arg))
        elif isinstance(expr, IREnumField):
            found.update(self._locals_in_expr(expr.value))
        elif isinstance(expr, IRRef):
            found.update(self._locals_in_expr(expr.target))
        elif isinstance(expr, IRRefNew):
            found.update(self._locals_in_expr(expr.target))
        else:
            # Generic fallback (e.g. IRNativeArrayNew, IRRefGet): a missing case
            # here must not hide a read and let a live assignment be dropped.
            for child in expr.get_children():
                if isinstance(child, IRExpression):
                    found.update(self._locals_in_expr(child))
        return found


class IRConstructorFolder(TraversingIROptimizer):
    """Folds `new X; __constructor__(x, args...)` into `new X(args...)`."""

    TARGET_OPCODES = {"New"}

    def visit_block(self, block: IRBlock) -> None:
        made_change = True
        while made_change:
            made_change = False
            new_statements: List[IRStatement] = []
            i = 0
            while i < len(block.statements):
                stmt = block.statements[i]
                if (
                    isinstance(stmt, IRAssign)
                    and isinstance(stmt.target, IRLocal)
                    and isinstance(stmt.expr, IRNew)
                    and not stmt.expr.constructor_args
                ):
                    folded = False
                    for j in range(i + 1, len(block.statements)):
                        next_stmt = block.statements[j]
                        ctor_args = self._match_constructor_call(next_stmt, stmt.target)
                        if ctor_args is not None:
                            # Keep any statements between the allocation and the
                            # constructor call (e.g. initializers for constructor
                            # arguments), and place the folded `new` after them.
                            stmt.expr.constructor_args = ctor_args
                            stmt.adopt(next_stmt)  # constructor-call opcode is dropped below
                            new_statements.extend(block.statements[i + 1 : j])
                            new_statements.append(stmt)
                            i = j + 1
                            made_change = True
                            folded = True
                            break
                        # We can only fold across statements that don't touch the
                        # freshly allocated instance.
                        if self._statement_uses_local(next_stmt, stmt.target):
                            break
                    if folded:
                        continue
                new_statements.append(stmt)
                i += 1
            block.statements = new_statements
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)

    def _match_constructor_call(
        self, stmt: IRStatement, instance_local: IRLocal
    ) -> Optional[List[IRExpression]]:
        if not isinstance(stmt, IRCall):
            return None
        if stmt.call_type != IRCall.CallType.FUNC:
            return None
        if not stmt.args:
            return None
        first_arg = stmt.args[0]
        if not (isinstance(first_arg, IRLocal) and first_arg == instance_local):
            return None
        fun_const = stmt.target
        if not isinstance(fun_const, IRConst):
            return None
        if not isinstance(fun_const.value, Function):
            return None
        func_name = self.func.code.partial_func_name(fun_const.value)
        if func_name and "__constructor__" in func_name:
            return list(stmt.args[1:])
        return None

    def _statement_uses_local(self, stmt: IRStatement, local: IRLocal) -> bool:
        """Return True if stmt reads or writes the given local."""
        if isinstance(stmt, IRAssign):
            if stmt.target == local:
                return True
            return self._expr_uses_local(stmt.expr, local)
        if isinstance(stmt, IRExpression):
            return self._expr_uses_local(stmt, local)
        if isinstance(stmt, IRReturn):
            return stmt.value is not None and self._expr_uses_local(stmt.value, local)
        return False

    def _expr_uses_local(self, expr: IRStatement, local: IRLocal) -> bool:
        if expr == local:
            return True
        return any(self._expr_uses_local(child, local) for child in expr.get_children())


class IREnumConstructorFolder(TraversingIROptimizer):
    """Folds `t = EnumAlloc; t.param0 = a; t.param1 = b; ...` into `t = Construct(a, b, ...)`.

    HL sometimes lowers an enum construction as a bare alloc followed by
    per-field SetEnumField writes instead of a single MakeEnum. Left
    unfolded, the empty-args IREnumConstruct renders as a bare constructor
    name (valid only for a truly argument-less case) — for a construct that
    actually has params, that's a bare type/case reference assigned as a
    value, which Haxe rejects.
    """

    def visit_block(self, block: IRBlock) -> None:
        new_statements: List[IRStatement] = []
        i = 0
        stmts = block.statements
        while i < len(stmts):
            stmt = stmts[i]
            if (
                isinstance(stmt, IRAssign)
                and isinstance(stmt.target, IRLocal)
                and isinstance(stmt.expr, IREnumConstruct)
                and not stmt.expr.args
            ):
                enum_def = stmt.expr.enum_type_idx.resolve(self.func.code).definition
                construct = None
                if isinstance(enum_def, Enum):
                    for c in enum_def.constructs:
                        if c.name.resolve(self.func.code) == stmt.expr.construct_name:
                            construct = c
                            break
                if construct is not None and construct.params:
                    field_names = [f"param{n}" for n in range(len(construct.params))]
                    collected: Dict[str, IRExpression] = {}
                    j = i + 1
                    while (
                        j < len(stmts)
                        and isinstance(stmts[j], IRAssign)
                        and isinstance(cast(IRAssign, stmts[j]).target, IREnumField)
                        and cast(IREnumField, cast(IRAssign, stmts[j]).target).value == stmt.target
                        and cast(IREnumField, cast(IRAssign, stmts[j]).target).field_name in field_names
                        and cast(IREnumField, cast(IRAssign, stmts[j]).target).field_name not in collected
                    ):
                        field_stmt = cast(IRAssign, stmts[j])
                        collected[cast(IREnumField, field_stmt.target).field_name] = field_stmt.expr
                        j += 1
                    if len(collected) == len(field_names):
                        stmt.expr.args = [collected[n] for n in field_names]
                        stmt.adopt(*stmts[i + 1 : j])
                        new_statements.append(stmt)
                        i = j
                        continue
            new_statements.append(stmt)
            i += 1
        block.statements = new_statements
        for s in block.statements:
            for child in s.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)


class IRAnonObjectLiteralOptimizer(TraversingIROptimizer):
    """
    Folds `temp = {}; temp.f1 = e1; temp.f2 = e2; ...; use(temp)` into
    `use({f1: e1, f2: e2, ...})`, wherever the anonymous object has exactly
    one further reference and it's the very next statement.

    HashLink lowers every Haxe anonymous-object literal to a `{}` allocation
    followed by one field-assignment per key. `IRTraceOptimizer` already
    special-cases this for `trace()`'s implicit position argument; this pass
    generalizes it to any consumer — most notably the same `?pos:haxe.
    PosInfos` argument the compiler silently attaches to any function that
    declares one (e.g. every `haxe.PosException` subclass constructor),
    which otherwise bloats a two-line `throw new SomeException();` into six
    lines of DynObj scaffolding.
    """

    TARGET_OPCODES = {"New"}

    def visit_block(self, block: IRBlock) -> None:
        made_change = True
        while made_change:
            made_change = False
            new_statements: List[IRStatement] = []
            i = 0
            while i < len(block.statements):
                match = self._try_fold(block.statements, i)
                if match is not None:
                    consumer, consumed = match
                    new_statements.append(consumer)
                    i += consumed
                    made_change = True
                    continue
                new_statements.append(block.statements[i])
                i += 1
            block.statements = new_statements
        for stmt in block.statements:
            for child in stmt.get_children():
                if isinstance(child, IRBlock):
                    self.visit_block(child)

    def _try_fold(self, stmts: List[IRStatement], start: int) -> Optional[Tuple[IRStatement, int]]:
        stmt = stmts[start]
        if not isinstance(stmt, IRAssign) or not isinstance(stmt.target, IRLocal):
            return None
        if not isinstance(stmt.expr, IRNew) or stmt.expr.constructor_args:
            return None
        # Anonymous-object allocations show up as either a generic DynObj or,
        # when the compiler can infer the exact field set statically (as it
        # always can for the fixed fileName/lineNumber/className/methodName
        # shape of `?pos:haxe.PosInfos`), a structural Virtual type. A real
        # `new SomeClass()` allocation is always an Obj, never either of these.
        alloc_defn = stmt.expr.get_type().definition
        if not isinstance(alloc_defn, (DynObj, Virtual)):
            return None
        temp = stmt.target

        fields: List[Tuple[str, IRExpression]] = []
        j = start + 1
        while j < len(stmts):
            s = stmts[j]
            if (
                isinstance(s, IRAssign)
                and isinstance(s.target, IRField)
                and s.target.target == temp
                and isinstance(s.expr, IRExpression)
                and not self._expr_uses_local(s.expr, temp)
            ):
                fields.append((s.target.field_name, s.expr))
                j += 1
                continue
            break

        if not fields or j >= len(stmts):
            return None

        use_stmt = stmts[j]
        if self._count_local_refs(use_stmt, temp) != 1:
            return None
        for later in stmts[j + 1 :]:
            if self._stmt_uses_local(later, temp):
                return None

        literal = IRObjectLiteral(self.func.code, fields)
        if not self._substitute_use(use_stmt, temp, literal):
            return None
        use_stmt.adopt(*stmts[start:j])  # the alloc + field-assign statements are dropped
        return use_stmt, j - start + 1

    def _substitute_use(self, stmt: IRStatement, local: IRLocal, replacement: IRExpression) -> bool:
        if isinstance(stmt, IRAssign):
            changed = False
            if stmt.expr == local:
                stmt.expr = replacement
                changed = True
            elif isinstance(stmt.expr, IRExpression) and self._replace_in_expr(stmt.expr, local, replacement):
                changed = True
            if isinstance(stmt.target, IRExpression) and stmt.target != local:
                if self._replace_in_expr(stmt.target, local, replacement):
                    changed = True
            return changed
        if isinstance(stmt, (IRReturn, IRThrow)):
            if stmt.value == local:
                stmt.value = replacement
                return True
            if stmt.value is not None:
                return self._replace_in_expr(stmt.value, local, replacement)
            return False
        if isinstance(stmt, IRExpression):
            return self._replace_in_expr(stmt, local, replacement)
        return False

    def _replace_in_expr(self, expr: IRExpression, local: IRLocal, replacement: IRExpression) -> bool:
        made_change = False
        for i, child in enumerate(expr.get_children()):
            if not isinstance(child, IRExpression):
                continue
            if child == local:
                if self._set_child(expr, i, replacement):
                    made_change = True
                continue
            if self._replace_in_expr(child, local, replacement):
                made_change = True
        return made_change

    def _set_child(self, parent: IRExpression, index: int, value: IRExpression) -> bool:
        children = parent.get_children()
        if index >= len(children):
            return False
        child = children[index]
        if isinstance(parent, (IRArithmetic, IRBoolExpr)):
            if child is parent.left:
                parent.left = value
                return True
            if child is parent.right:
                parent.right = value
                return True
        elif isinstance(parent, IRCall):
            if parent.target is child:
                parent.target = cast(Any, value)
                return True
            for j, arg in enumerate(parent.args):
                if arg is child:
                    parent.args[j] = value
                    return True
        elif isinstance(parent, IRField):
            if child is parent.target:
                parent.target = value
                return True
        elif isinstance(parent, IRCast):
            if child is parent.expr:
                parent.expr = value
                return True
        elif isinstance(parent, IRArrayAccess):
            if child is parent.array:
                parent.array = value
                return True
            if child is parent.index:
                parent.index = value
                return True
        elif isinstance(parent, IRNew):
            for j, arg in enumerate(parent.constructor_args):
                if arg is child:
                    parent.constructor_args[j] = value
                    return True
        elif isinstance(parent, IREnumConstruct):
            for j, arg in enumerate(parent.args):
                if arg is child:
                    parent.args[j] = value
                    return True
        elif isinstance(parent, IREnumField):
            if child is parent.value:
                parent.value = value
                return True
        elif isinstance(parent, IRArrayLiteral):
            for j, element in enumerate(parent.elements):
                if element is child:
                    parent.elements[j] = value
                    return True
        elif isinstance(parent, IRRef):
            if child is parent.target:
                parent.target = value
                return True
        return False

    def _count_local_refs(self, stmt: IRStatement, local: IRLocal) -> int:
        if stmt == local:
            return 1
        return sum(self._count_local_refs(child, local) for child in stmt.get_children())

    def _stmt_uses_local(self, stmt: IRStatement, local: IRLocal) -> bool:
        return self._count_local_refs(stmt, local) > 0

    def _expr_uses_local(self, expr: IRExpression, local: IRLocal) -> bool:
        return self._count_local_refs(expr, local) > 0


class IRShiftConstantOptimizer(TraversingIROptimizer):
    """
    Replaces shift-amount locals with their constant values when the local is
    assigned a constant and not yet redefined. This cleans up bytecode patterns
    like `var n = 1; x = y << n` without the broader risks of full copy
    propagation.
    """

    def _replace_shift_const(self, expr: IRExpression, const_map: Dict[IRLocal, IRConst]) -> bool:
        if isinstance(expr, IRArithmetic) and expr.op.value in ("<<", ">>", ">>>"):
            if isinstance(expr.right, IRLocal) and expr.right in const_map:
                expr.right = const_map[expr.right]
                return True
        made_change = False
        if isinstance(expr, (IRArithmetic, IRBoolExpr)):
            if expr.left is not None and self._replace_shift_const(expr.left, const_map):
                made_change = True
            if expr.right is not None and self._replace_shift_const(expr.right, const_map):
                made_change = True
        elif isinstance(expr, IRCall):
            if expr.target is not None and self._replace_shift_const(expr.target, const_map):
                made_change = True
            for arg in expr.args:
                if self._replace_shift_const(arg, const_map):
                    made_change = True
        elif isinstance(expr, IRCast):
            if self._replace_shift_const(expr.expr, const_map):
                made_change = True
        elif isinstance(expr, IRField):
            if self._replace_shift_const(expr.target, const_map):
                made_change = True
        elif isinstance(expr, IRArrayAccess):
            if self._replace_shift_const(expr.array, const_map):
                made_change = True
            if self._replace_shift_const(expr.index, const_map):
                made_change = True
        return made_change

    def _apply_to_statement(self, stmt: IRStatement, const_map: Dict[IRLocal, IRConst]) -> None:
        if isinstance(stmt, IRAssign):
            self._replace_shift_const(stmt.expr, const_map)
        elif isinstance(stmt, IRReturn):
            if stmt.value is not None:
                self._replace_shift_const(stmt.value, const_map)
        elif isinstance(stmt, IRConditional):
            self._replace_shift_const(stmt.condition, const_map)
        elif isinstance(stmt, IRPrimitiveJump):
            for attr in ("left", "right", "cond"):
                val = getattr(stmt, attr, None)
                if val is not None:
                    self._replace_shift_const(val, const_map)
        elif isinstance(stmt, IRSwitch):
            self._replace_shift_const(stmt.value, const_map)

    def visit_block(self, block: IRBlock) -> None:
        const_map: Dict[IRLocal, IRConst] = {}
        for stmt in block.statements:
            # Apply current constant mappings before updating them, so the
            # definition site itself is not rewritten.
            self._apply_to_statement(stmt, const_map)

            if isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal):
                target_local = stmt.target
                const_map.pop(target_local, None)
                # Only substitute compiler-generated temporaries (`varN`):
                # user-named shift-amount variables (e.g. `x << n`) are
                # meaningful source identifiers and substituting their value
                # in destroys the symbolic shift the user actually wrote,
                # even though the bytecode result is equivalent.
                if isinstance(stmt.expr, IRConst) and re.fullmatch(r"var\d+", target_local.name):
                    const_map[target_local] = stmt.expr


class IRGuardOrMerger(TraversingIROptimizer):
    """Merge `if (A) { T } else { if (B) { T } else { W } } }` into a single
    `if (A || B) { T } else { W }` when both `T` branches perform the exact
    same action.

    This is the inverse of how Haxe's `||`/`&&` short-circuiting lowers to
    bytecode: `if (A || B) X; else Y;` compiles to a nested guard where the
    "taken" branch is reachable from two jump targets. Without this merge,
    the decompiled source duplicates the action under two separate branches,
    which recompiles to different (larger) bytecode than the original.
    """

    def visit_block(self, block: IRBlock) -> None:
        new_statements: List[IRStatement] = []
        i = 0
        stmts = block.statements
        while i < len(stmts):
            stmt = stmts[i]
            if isinstance(stmt, IRConditional):
                # Re-attempt on a freshly merged conditional: a chain of N
                # nested `if`s with empty/matching elses (like
                # `if (a) { if (b) { if (c) { X } } }`) collapses fully in
                # one pass instead of one level per optimizer invocation,
                # since each merge's result can itself be the outer half of
                # the next one.
                merged_once = True
                while merged_once:
                    merged_once = False
                    for attempt in (
                        self._try_merge_else,
                        self._try_merge_true,
                        self._try_merge_and_else,
                        self._try_merge_and_no_else,
                        self._try_merge_and_empty_else,
                    ):
                        candidate = attempt(stmt)
                        if candidate is not None:
                            stmt = candidate
                            merged_once = True
                            break
                if stmt is not stmts[i]:
                    new_statements.append(stmt)
                    i += 1
                    continue
                merged2 = self._try_merge_sibling(stmt, stmts[i + 1 :])
                if merged2 is not None:
                    new_cond, consumed_siblings = merged2
                    new_statements.append(new_cond)
                    i += 1 + consumed_siblings
                    continue
                merged3 = self._try_merge_sibling_and(stmt, stmts[i + 1 :])
                if merged3 is not None:
                    new_cond, consumed_siblings = merged3
                    new_statements.append(new_cond)
                    i += 1 + consumed_siblings
                    continue
            new_statements.append(stmt)
            i += 1
        block.statements = new_statements

    def _try_merge_else(self, stmt: IRConditional) -> Optional[IRConditional]:
        """if (A) { T } else { if (B) { T } else { W } } -> if (A || B) { T } else { W }"""
        outer_true = stmt.true_block.statements
        false_stmts = stmt.false_block.statements
        if not outer_true or len(false_stmts) != 1:
            return None
        inner = false_stmts[0]
        if not isinstance(inner, IRConditional):
            return None
        if _stmt_lists_structurally_equal(outer_true, inner.true_block.statements):
            or_cond = IRBoolExpr(
                self.func.code,
                IRBoolExpr.CompareType.OR,
                stmt.condition,
                inner.condition,
            )
            merged = IRConditional(self.func.code, or_cond, inner.true_block, inner.false_block)
            merged.adopt(stmt, inner)
            return merged
        return None

    def _try_merge_true(self, stmt: IRConditional) -> Optional[IRConditional]:
        """if (A) { if (B) { T } } else { T } -> if (!A || B) { T } { inner's else }

        Mirror of _try_merge_else with the nested conditional in the TRUE branch
        instead of the FALSE branch — the shape HL's short-circuit-OR lowering
        produces when the "taken" (throwing/returning) action is reached via the
        *first* condition being true, and the second check sits inside the
        "first condition false" arm instead of the other way around.

        Also handles the common staged-RHS shape where Haxe evaluates the second
        condition into a temp first::

            if (A) { t = B(); if (t) { T } } else { T }
                -> if (!A || B()) { T }

        The temp is moved (it is single-use), not duplicated, so B() runs once
        either way — only when A is false, exactly as the short-circuit requires.
        """
        outer_true = stmt.true_block.statements
        false_stmts = stmt.false_block.statements
        if not false_stmts:
            return None
        resolved = self._resolve_or_inner(outer_true)
        if resolved is None:
            return None
        inner, rhs_cond, temp_assign = resolved
        if _stmt_lists_structurally_equal(false_stmts, inner.true_block.statements):
            not_a = self._invert(stmt.condition)
            or_cond = IRBoolExpr(self.func.code, IRBoolExpr.CompareType.OR, not_a, rhs_cond)
            merged = IRConditional(self.func.code, or_cond, inner.true_block, inner.false_block)
            if temp_assign is not None:
                merged.adopt(stmt, inner, temp_assign)
            else:
                merged.adopt(stmt, inner)
            return merged
        return None

    def _resolve_or_inner(
        self, outer_true: List[IRStatement]
    ) -> Optional[Tuple[IRConditional, IRExpression, Optional[IRStatement]]]:
        """Extract the inner conditional and the expression to use as the OR
        right-hand side from a short-circuit-OR true branch.

        Returns (inner_conditional, rhs_expression, temp_definition_or_None).
        The temp_definition is the staged `t = B()` assignment, when present,
        so the caller can drop it (the RHS is folded into the merged condition).
        """
        if not outer_true:
            return None
        # Bare shape: [if (B) { T }] — RHS is the inner condition itself.
        if len(outer_true) == 1:
            inner = outer_true[0]
            if isinstance(inner, IRConditional):
                return inner, inner.condition, None
            return None
        # Staged shape: [t = B(); if (t) { T }] — fold B() into the condition.
        if len(outer_true) == 2:
            temp_stmt, inner = outer_true
            if not (isinstance(temp_stmt, IRAssign) and isinstance(temp_stmt.target, IRLocal)):
                return None
            if not isinstance(inner, IRConditional):
                return None
            temp = temp_stmt.target
            cond = inner.condition
            if not self._condition_is_temp(cond, temp):
                return None
            # The temp must be read only here (single-use) so folding is a move.
            if self._count_reads(outer_true, temp) != 1:
                return None
            return inner, temp_stmt.expr, temp_stmt
        return None

    def _condition_is_temp(self, cond: IRExpression, temp: IRLocal) -> bool:
        """True if `cond` is `temp is true` / `temp` (the staged temp being tested."""
        if cond == temp:
            return True
        return isinstance(cond, IRBoolExpr) and cond.op == IRBoolExpr.CompareType.ISTRUE and cond.left == temp

    def _count_reads(self, stmts: List[IRStatement], local: IRLocal) -> int:
        """Count reads of `local` across `stmts`, ignoring a bare write to it."""
        count = 0

        def walk(e: Optional[IRExpression]) -> None:
            nonlocal count
            if e is None:
                return
            if e == local:
                count += 1
                return
            for c in e.get_children():
                if isinstance(c, IRExpression):
                    walk(c)

        for s in stmts:
            if isinstance(s, IRAssign):
                tgt = s.target
                if isinstance(tgt, IRArrayAccess):
                    walk(tgt.index)
                    walk(tgt.array)
                elif tgt == local:
                    walk(s.expr)
                    continue
                walk(s.expr)
            else:
                for c in s.get_children():
                    if isinstance(c, IRExpression):
                        walk(c)
        return count

    def _try_merge_and_else(self, stmt: IRConditional) -> Optional[IRConditional]:
        """if (A) { if (B) { X } else { Y } } else { Y } -> if (A && B) { X } else { Y }

        The shape Haxe's short-circuit-&& lowering produces when both arms of
        the inner conditional have real bodies and the outer else duplicates
        the inner else. Without this merge the decompiled source duplicates Y
        under two separate branches, recompiling to a second copy of Y.
        """
        outer_true = stmt.true_block.statements
        false_stmts = stmt.false_block.statements
        if len(outer_true) != 1 or not false_stmts:
            return None
        inner = outer_true[0]
        if not isinstance(inner, IRConditional) or not inner.false_block.statements:
            return None
        if _stmt_lists_structurally_equal(false_stmts, inner.false_block.statements):
            and_cond = IRBoolExpr(self.func.code, IRBoolExpr.CompareType.AND, stmt.condition, inner.condition)
            merged = IRConditional(self.func.code, and_cond, inner.true_block, inner.false_block)
            merged.adopt(stmt, inner)
            return merged
        return None

    def _try_merge_and_no_else(self, stmt: IRConditional) -> Optional[IRConditional]:
        """if (A) { if (B) { X } } (no else anywhere) -> if (A && B) { X }

        The plain shape Haxe's flat `A && B` lowers to when neither operand
        needs inverting: unlike `_try_merge_and_else`, there's no else body on
        either side to prove equal before merging - an empty else can't
        diverge, so there's nothing to duplicate or drop by combining them.
        """
        if stmt.false_block.statements:
            return None
        outer_true = stmt.true_block.statements
        if len(outer_true) != 1:
            return None
        inner = outer_true[0]
        if not isinstance(inner, IRConditional) or inner.false_block.statements:
            return None
        and_cond = IRBoolExpr(self.func.code, IRBoolExpr.CompareType.AND, stmt.condition, inner.condition)
        merged = IRConditional(self.func.code, and_cond, inner.true_block, inner.false_block)
        merged.adopt(stmt, inner)
        return merged

    def _try_merge_and_empty_else(self, stmt: IRConditional) -> Optional[IRConditional]:
        """if (A) { if (B') { } else { X } } (empty else on both) -> if (A && B) { X }

        Haxe's `A && B` can lower with the second comparison inverted and the
        real body in its *false* arm (the empty true arm is the fall-through):
        the inner `if (code <= MAX) {} else { return ...; }` is `code > MAX`'s
        complement guarding X. Inverting B' back and AND-ing it onto A recovers
        the flat `A && B` the source wrote. Both outers must have empty else —
        if !A does something, X isn't simply gated by `A && B`."""
        if stmt.false_block.statements:
            return None
        outer_true = stmt.true_block.statements
        if len(outer_true) != 1:
            return None
        inner = outer_true[0]
        if not isinstance(inner, IRConditional):
            return None
        # Real body lives in the inner FALSE arm; inner true arm must be empty.
        if inner.true_block.statements or not inner.false_block.statements:
            return None
        if not isinstance(inner.condition, IRBoolExpr):
            return None
        inner_cond = self._invert(inner.condition)
        and_cond = IRBoolExpr(self.func.code, IRBoolExpr.CompareType.AND, stmt.condition, inner_cond)
        merged = IRConditional(self.func.code, and_cond, inner.false_block, stmt.false_block)
        merged.adopt(stmt, inner)
        return merged

    def _try_merge_sibling(
        self, stmt: IRConditional, following: List[IRStatement]
    ) -> Optional[Tuple[IRConditional, int]]:
        """if (A) { if (B) { T } REST } (empty else), followed in the parent
        block by T as the fallthrough-when-!A path -> if (!A || B) { T } { REST },
        consuming T's statements from the parent block."""
        outer_true = stmt.true_block.statements
        if stmt.false_block.statements or not outer_true:
            return None
        inner = outer_true[0]
        if not isinstance(inner, IRConditional) or inner.false_block.statements:
            return None
        inner_true = inner.true_block.statements
        if not inner_true or len(following) < len(inner_true):
            return None
        if not _stmt_lists_structurally_equal(inner_true, following[: len(inner_true)]):
            return None
        not_a = self._invert(stmt.condition)
        or_cond = IRBoolExpr(self.func.code, IRBoolExpr.CompareType.OR, not_a, inner.condition)
        rest_block = IRBlock(self.func.code)
        rest_block.statements = outer_true[1:]
        merged = IRConditional(self.func.code, or_cond, inner.true_block, rest_block)
        # The consumed parent-block siblings duplicate inner_true's *content*
        # (that's the merge precondition) but are distinct compiled copies with
        # their own opcodes, same as stmt/inner themselves being replaced.
        merged.adopt(stmt, inner, *following[: len(inner_true)])
        return merged, len(inner_true)

    def _try_merge_sibling_and(
        self, stmt: IRConditional, following: List[IRStatement]
    ) -> Optional[Tuple[IRConditional, int]]:
        """if (A) { if (B) { X } else { Y } TAIL } (empty else), followed in
        the parent block by Y then TAIL again (the fallthrough-when-!A path
        repeats the else-action and shared tail-code) -> if (A && B) { X }
        else { Y } TAIL, consuming Y+TAIL's statements from the parent block.

        Also handles B's else being empty with Y living in TAIL instead, when
        X is terminal (continue/break/return/throw): since X never falls
        through, TAIL is only reachable via B-false, so it plays the same
        role as an inline else -- if (A) { if (B) { X } TAIL } (empty else),
        followed by TAIL again -> if (A && B) { X } else { TAIL }, consuming
        all of TAIL's duplicate from the parent block (there's no separate
        shared-tail remainder left over, unlike the inline-else case above).
        """
        outer_true = stmt.true_block.statements
        if stmt.false_block.statements or not outer_true:
            return None
        inner = outer_true[0]
        if not isinstance(inner, IRConditional):
            return None
        tail = outer_true[1:]
        inner_false = inner.false_block.statements
        if inner_false:
            wanted = inner_false + tail
            false_block = inner.false_block
            consumed = len(inner_false)
        elif (
            tail
            and inner.true_block.statements
            and isinstance(inner.true_block.statements[-1], (IRContinue, IRBreak, IRReturn, IRThrow))
        ):
            wanted = tail
            false_block = IRBlock(self.func.code)
            false_block.statements = tail
            consumed = len(wanted)
        else:
            return None
        if not wanted or len(following) < len(wanted):
            return None
        if not _stmt_lists_structurally_equal(wanted, following[: len(wanted)]):
            return None
        and_cond = IRBoolExpr(self.func.code, IRBoolExpr.CompareType.AND, stmt.condition, inner.condition)
        merged = IRConditional(self.func.code, and_cond, inner.true_block, false_block)
        merged.adopt(stmt, inner, *following[: len(wanted)])
        return merged, consumed

    def _invert(self, cond: IRExpression) -> IRExpression:
        """Return a negated copy of a boolean expression. Flips simple
        comparisons (>= becomes <, etc.) in place on a shallow copy rather
        than wrapping with a unary NOT, which existing code doesn't expect
        to need parenthesizing."""
        if isinstance(cond, IRBoolExpr) and cond.op not in (
            IRBoolExpr.CompareType.OR,
            IRBoolExpr.CompareType.AND,
            IRBoolExpr.CompareType.NOT,
        ):
            inverted = copy.copy(cond)
            try:
                inverted.invert()
                return inverted
            except DecompError:
                pass
        return IRBoolExpr(self.func.code, IRBoolExpr.CompareType.NOT, cond)


class IRTypedCatchOptimizer(IROptimizer):
    """
    Restores typed catch clauses from HL's dynamic dispatch lowering.

    Haxe lowers `try T catch (e:X1) C1 ... catch (e:Xn) Cn` into a single
    dynamic trap whose catch block is a dispatch chain:

        t = X1.check(e); if (t) C1 else { ... t = Xn.check(e); if (t) Cn else {
        t = haxe.ValueException.check(e); if (t) { ve = cast(e, haxe.ValueException);
            t = Std.isOfType(ve.value, Xj); if (t) Cj ... else throw ve }
        else throw e }}

    (the ValueException arm unwraps values thrown via `throw value`). When
    every arm transfers control (throw/return/continue), restructuring flattens
    the chain into sequential `if (t) {...}` guards with empty else-blocks and
    the terminal throw at the same level; the walkers below accept the nested,
    flat, and mixed shapes.

    The native `Xi.check` arms and the unwrap arm's `isOfType` sub-arms are two
    copies of the same clause bodies; the unwrap copies keep the cleanest
    binding shape, so clauses are restored from them (the native arms only
    contribute the type list, cross-checked against the unwrap sub-arms).

    Further handled: clause bodies that use the caught value start with
    `v = cast(ve.value, Xi)` (or `v = ve.value`) and may reuse the catch
    register as scratch — the restored clause binds `v`; statements after the
    terminal `throw e` (the trap region's continuation, lifted into the catch
    block when the try side never falls through) are spliced back out after
    the restored try/catch.
    """

    TARGET_OPCODES = {"Trap"}

    def optimize(self) -> None:
        self._process_block(self.func.block)

    def _process_block(self, block: IRBlock) -> None:
        new_stmts: List[IRStatement] = []
        for stmt in list(block.statements):
            new_stmts.extend(self._process_stmt(stmt))
        block.statements = new_stmts

    def _process_stmt(self, stmt: IRStatement) -> List[IRStatement]:
        """Restore children first, then splice any continuation after this statement.

        A non-fallthrough try can absorb later try/catches into its continuation.
        Their dispatch registers may reuse this catch's type aliases; restoring
        them first prevents those independent definitions from looking like
        escaped aliases when restoring the enclosing catch.
        """
        if isinstance(stmt, IRTryCatch):
            self._process_block(stmt.try_block)
            self._process_block(stmt.catch_block)
            for _, extra_block in stmt.extra_catches:
                self._process_block(extra_block)
            trail = self._restore(stmt)
            return [stmt, *trail]
        if isinstance(stmt, IRConditional):
            self._process_block(stmt.true_block)
            if stmt.false_block is not None:
                self._process_block(stmt.false_block)
        elif isinstance(stmt, (IRWhileLoop, IRPrimitiveLoop, IRForEachLoop, IRIntRangeLoop)):
            self._process_block(stmt.body)
        elif isinstance(stmt, IRSwitch):
            for case_block in stmt.cases.values():
                self._process_block(case_block)
            if stmt.default is not None:
                self._process_block(stmt.default)
        return [stmt]

    def _restore(self, tc: IRTryCatch) -> List[IRStatement]:
        """Restore typed catches on `tc`. Returns continuation statements to
        splice after the try/catch (empty on no match)."""
        e = tc.catch_local
        if e is None or tc.extra_catches:
            return []
        stmts = tc.catch_block.statements
        self._dispatch_aliases: Set[IRLocal] = set()
        arms: List[Tuple[Type, IRBlock]] = []
        unwrap_arms: List[Tuple[Type, IRBlock]] = []
        consumed = self._parse_check_chain(stmts, 0, e, arms, unwrap_arms)
        if consumed is None or not arms:
            return []
        # haxe.Exception-subclass catch types never arrive wrapped in a
        # ValueException, so HL emits no isOfType sub-arm for them: the unwrap
        # arm re-dispatches exactly the non-exception caught types (and is
        # absent entirely when every caught type is an exception subclass).
        non_exc_arms = [(t, b) for t, b in arms if not self._is_exception_type(t)]
        if sorted(self._type_name(t) for t, _ in unwrap_arms) != sorted(
            self._type_name(t) for t, _ in non_exc_arms
        ):
            return []
        bodies_by_name = {self._type_name(t): b for t, b in unwrap_arms}
        clauses = []
        for typ, native_body in arms:
            if self._is_exception_type(typ):
                # No unwrap copy exists; the native arm body is the clause body.
                clause = self._make_clause(typ, native_body, e, native=True)
            else:
                clause = self._make_clause(typ, bodies_by_name[self._type_name(typ)], e)
            clauses.append(clause)
        if any(clause is None for clause in clauses):
            return []
        if any(
            self._references_local(body, alias)
            for alias in self._dispatch_aliases
            for _, body in (clause for clause in clauses if clause is not None)
        ) or any(
            self._references_local(stmt, alias)
            for alias in self._dispatch_aliases
            for stmt in stmts[consumed:]
        ):
            return []
        assert clauses[0] is not None
        first_local, first_body = clauses[0]
        tc.catch_local = first_local
        tc.catch_block = first_body
        tc.extra_catches = [clause for clause in clauses[1:] if clause is not None]
        return list(stmts[consumed:])

    # --- dispatch-chain walkers -------------------------------------------
    #
    # Both chains are sequences of `t = <call>; if (t) ARM else NEXT` pairs
    # terminated by `throw <local>`. NEXT is one of:
    #   - [throw local]            -> nested terminal
    #   - []                       -> flat continuation (next pair or the
    #                                 terminal throw follows at this level)
    #   - more pairs               -> nested continuation (must consume all)

    def _parse_check_chain(
        self,
        stmts: List[IRStatement],
        i: int,
        e: IRLocal,
        arms: List[Tuple[Type, IRBlock]],
        unwrap_arms: List[Tuple[Type, IRBlock]],
    ) -> Optional[int]:
        """Walk native `X.check(e)` arms. Returns the index just past the
        terminal `throw e`, or None if the shape breaks."""
        while True:
            if i >= len(stmts):
                return None
            stmt = stmts[i]
            if isinstance(stmt, IRThrow) and stmt.value is e:
                return i + 1
            type_alias, i = self._consume_type_alias(stmts, i)
            if i + 1 >= len(stmts):
                return None
            matched = self._match_check_pair(stmts[i], stmts[i + 1], e, type_alias)
            if matched is None:
                return None
            typ, tname, body, cond = matched
            if tname == "haxe.ValueException":
                if unwrap_arms:
                    return None
                if self._parse_unwrap(body, e, unwrap_arms) != len(body.statements):
                    return None
            else:
                arms.append((typ, body))
            else_stmts = cond.false_block.statements
            if len(else_stmts) == 1 and isinstance(else_stmts[0], IRThrow) and else_stmts[0].value is e:
                return i + 2
            if len(else_stmts) == 0:
                i += 2
                continue
            if self._parse_check_chain(else_stmts, 0, e, arms, unwrap_arms) != len(else_stmts):
                return None
            return i + 2

    def _parse_unwrap(self, body: IRBlock, e: IRLocal, sub_arms: List[Tuple[Type, IRBlock]]) -> Optional[int]:
        """Match the ValueException arm body: `ve = cast(e, haxe.ValueException)`,
        optional catch-register plumbing, then an isOfType chain. Returns the
        consumed statement count, or None."""
        stmts = body.statements
        if len(stmts) < 3:
            return None
        cast_assign = stmts[0]
        if not (
            isinstance(cast_assign, IRAssign)
            and isinstance(cast_assign.target, IRLocal)
            and isinstance(cast_assign.expr, IRCast)
            and cast_assign.expr.expr is e
            and self._type_name(cast_assign.expr.get_type()) == "haxe.ValueException"
        ):
            return None
        ve = cast_assign.target
        # Skip catch-register plumbing the wrapped path emits before the
        # isOfType chain (e.g. `e = ve.value`, kept inside loops).
        start = 1
        payload_local = None
        while start < len(stmts):
            plumbing = stmts[start]
            if (
                isinstance(plumbing, IRAssign)
                and plumbing.target is e
                and (
                    (
                        isinstance(plumbing.expr, IRField)
                        and plumbing.expr.target is ve
                        and plumbing.expr.field_name == "value"
                    )
                    or (isinstance(plumbing.expr, IRConst) and plumbing.expr.value is None)
                )
            ):
                payload_local = e if self._is_value_field(plumbing.expr) else None
                start += 1
                continue
            break
        return self._parse_isotype_chain(stmts, start, ve, sub_arms, payload_local)

    def _parse_isotype_chain(
        self,
        stmts: List[IRStatement],
        i: int,
        ve: IRLocal,
        sub_arms: List[Tuple[Type, IRBlock]],
        payload_local: Optional[IRLocal] = None,
    ) -> Optional[int]:
        """Walk `isOfType(ve.value, Xj)` sub-arms. Returns the index just past
        the terminal `throw ve` (or len(stmts) for the guard variant), or None."""
        while True:
            if i >= len(stmts):
                return None
            stmt = stmts[i]
            if isinstance(stmt, IRThrow) and stmt.value is ve:
                return i + 1
            type_alias, i = self._consume_type_alias(stmts, i)
            if i + 1 >= len(stmts):
                return None
            assign = stmts[i]
            call = self._std_call(assign, "isOfType")
            if (
                call is None
                or len(call.args) != 2
                or not isinstance(assign, IRAssign)
                or not isinstance(assign.target, IRLocal)
            ):
                return None
            field, type_const = call.args
            if type_alias is not None:
                if type_const is not type_alias.target:
                    return None
                type_const = type_alias.expr
            if not (
                (
                    (isinstance(field, IRField) and field.target is ve and field.field_name == "value")
                    or (payload_local is not None and field is payload_local)
                )
                and isinstance(type_const, IRConst)
                and isinstance(type_const.value, Type)
            ):
                return None
            cond = stmts[i + 1]
            if not isinstance(cond, IRConditional):
                return None
            typ = type_const.value
            cond_expr = cond.condition
            if self._is_true_cond(cond_expr, assign.target):
                sub_arms.append((typ, cond.true_block))
                else_stmts = cond.false_block.statements
                if len(else_stmts) == 1 and isinstance(else_stmts[0], IRThrow) and else_stmts[0].value is ve:
                    return i + 2
                if len(else_stmts) == 0:
                    i += 2
                    continue
                if self._parse_isotype_chain(else_stmts, 0, ve, sub_arms, payload_local) != len(else_stmts):
                    return None
                return i + 2
            if (
                isinstance(cond_expr, IRBoolExpr)
                and cond_expr.op == IRBoolExpr.CompareType.ISFALSE
                and cond_expr.left is assign.target
            ):
                # Final arm as a guard: `if (!t) throw ve;` with the arm body
                # inline after it.
                then_stmts = cond.true_block.statements
                if not (
                    len(then_stmts) == 1 and isinstance(then_stmts[0], IRThrow) and then_stmts[0].value is ve
                ):
                    return None
                tail = IRBlock(self.func.code)
                tail.statements = list(stmts[i + 2 :])
                sub_arms.append((typ, tail))
                return len(stmts)
            return None

    # --- arm-pair and clause helpers ---------------------------------------

    def _consume_type_alias(self, stmts: List[IRStatement], i: int) -> Tuple[Optional[IRAssign], int]:
        """Recognize the class reference load immediately preceding a dispatch test."""
        stmt = stmts[i]
        if (
            isinstance(stmt, IRAssign)
            and isinstance(stmt.target, IRLocal)
            and isinstance(stmt.expr, IRConst)
            and stmt.expr.const_type == IRConst.ConstType.GLOBAL_OBJ
            and isinstance(stmt.expr.value, Type)
            and isinstance(stmt.expr.value.definition, Obj)
            and "$" in stmt.expr.value.definition.name.resolve(self.func.code)
        ):
            self._dispatch_aliases.add(stmt.target)
            return stmt, i + 1
        return None, i

    def _match_check_pair(
        self, assign: IRStatement, cond: IRStatement, e: IRLocal, type_alias: Optional[IRAssign] = None
    ) -> Optional[Tuple[Type, str, IRBlock, IRConditional]]:
        """Match `t = X.check(e); if (t) ...`."""
        call = self._std_call(assign, "check")
        if (
            call is None
            or len(call.args) != 2
            or not isinstance(assign, IRAssign)
            or not isinstance(assign.target, IRLocal)
        ):
            return None
        type_const, arg1 = call.args
        if type_alias is not None:
            if type_const is not type_alias.target:
                return None
            type_const = type_alias.expr
        if not (isinstance(type_const, IRConst) and isinstance(type_const.value, Type)):
            return None
        if arg1 is not e:
            return None
        if not (isinstance(cond, IRConditional) and self._is_true_cond(cond.condition, assign.target)):
            return None
        typ = type_const.value
        return typ, self._type_name(typ), cond.true_block, cond

    def _make_clause(
        self, typ: Type, body: IRBlock, e: IRLocal, native: bool = False
    ) -> Optional[Tuple[IRLocal, IRBlock]]:
        """Return (binding_local, body) for one restored clause, or None if the
        body uses the caught value in a shape we don't recognize."""
        if isinstance(typ.definition, Obj) and typ.definition.is_static:
            typ = typ.definition.dynamic.get_containing_type(self.func.code)
        stmts = body.statements
        # Wrapped-value clauses can retain the explicit payload-register load
        # followed by a typed cast. Bind the typed result, not the dynamic
        # exception scratch register.
        if len(stmts) >= 2:
            payload, binding = stmts[:2]
            if (
                isinstance(payload, IRAssign)
                and payload.target is e
                and self._is_value_field(payload.expr)
                and isinstance(binding, IRAssign)
                and isinstance(binding.expr, IRCast)
                and binding.expr.expr is e
            ):
                stmts = stmts[1:]
        first = stmts[0] if stmts else None
        if isinstance(first, IRAssign) and isinstance(first.target, IRLocal):
            expr = first.expr
            cast_inner = expr.expr if isinstance(expr, IRCast) else None
            bound = (
                cast_inner is not None and (self._is_value_field(cast_inner) or cast_inner is e)
            ) or self._is_value_field(expr)
            if bound:
                # `v = cast(ve.value, T)` / `v = ve.value` (unwrap bodies) or
                # `v = cast(e, T)` (native bodies of exception-subclass arms)
                # binds the caught value; the clause binds `v`. Any later use
                # of the dispatch registers in the body is scratch reuse.
                return self._bind_clause(typ, first.target, stmts[1:])
        try:
            idx = self.func.code.types.index(typ)
        except ValueError:
            return None
        if native:
            # Exception arms have no unwrap copy; when the body reads the catch
            # register inline (no binding assignment), the clause binds `e`
            # itself — but only if the body never writes it (scratch reuse).
            if self._assigns_local(body, e) or self._references_plumbing(body):
                return None
            if self._references_local(body, e):
                return self._bind_clause(typ, e, body.statements)
            return IRLocal("e", tIndex(idx), self.func.code), body
        if self._references_dispatch(body, e):
            return None
        return IRLocal("e", tIndex(idx), self.func.code), body

    def _bind_clause(
        self, typ: Type, source: IRLocal, statements: List[IRStatement]
    ) -> Tuple[IRLocal, IRBlock]:
        """A catch binding is scoped storage, not a rename of a reused HL register."""
        names = {local.name for local in self.func.all_locals}
        base = source.name if not source.name.startswith("var") else "caught"
        name, suffix = base, 1
        while name in names:
            name = f"{base}{suffix}"
            suffix += 1
        binding = IRLocal(name, tIndex(self.func.code.types.index(typ)), self.func.code)
        memo = {
            id(value): value
            for value in [
                self.func.code,
                *self.func.code.types,
                *self.func.code.functions,
                *self.func.code.natives,
                *self.func.all_locals,
            ]
        }
        memo[id(source)] = binding
        body = IRBlock(self.func.code)
        body.statements = self.func._clone_value(statements, memo)
        self.func.all_locals.append(binding)
        return binding, body

    def _is_value_field(self, expr: IRStatement) -> bool:
        """True for `<something>.value` field reads (the ValueException payload)."""
        return isinstance(expr, IRField) and expr.field_name == "value"

    def _references_dispatch(self, stmt: IRStatement, e: IRLocal) -> bool:
        """True if stmt still reads/writes the dispatch plumbing: the catch
        register `e`, any `_.value` unwrap field, or a ValueException local."""
        return self._references_local(stmt, e) or self._references_plumbing(stmt)

    def _references_plumbing(self, stmt: IRStatement) -> bool:
        """Dispatch plumbing other than the catch register itself."""
        if self._is_value_field(stmt):
            return True
        if isinstance(stmt, IRLocal) and self._type_name(stmt.get_type()) in (
            "haxe.ValueException",
            "haxe.Exception",
        ):
            return True
        return any(self._references_plumbing(child) for child in stmt.get_children())

    def _assigns_local(self, stmt: IRStatement, local: IRLocal) -> bool:
        if isinstance(stmt, IRAssign) and stmt.target is local:
            return True
        return any(self._assigns_local(child, local) for child in stmt.get_children())

    def _references_local(self, stmt: IRStatement, local: IRLocal) -> bool:
        if stmt is local:
            return True
        return any(self._references_local(child, local) for child in stmt.get_children())

    def _is_exception_type(self, typ: Type) -> bool:
        """True if typ is or subclasses haxe.Exception/haxe.ValueException;
        such caught values are exceptions themselves and never arrive wrapped
        in a ValueException, so HL emits no unwrap sub-arm for them."""
        defn = typ.definition
        for _ in range(32):
            if not isinstance(defn, Obj):
                return False
            # Type constants often carry the static counterpart ($Foo), whose
            # super chain is the metaclass chain; walk the instance class chain.
            try:
                dyn = defn.dynamic
                if isinstance(dyn, Obj):
                    defn = dyn
            except (ValueError, AttributeError):
                pass
            if destaticify(defn.name.resolve(self.func.code)) in ("haxe.Exception", "haxe.ValueException"):
                return True
            if defn.super.value <= 0:
                return False
            try:
                defn = defn.super.resolve(self.func.code).definition
            except Exception:
                return False
        return False

    def _type_name(self, typ: Type) -> str:
        return destaticify(disasm.type_name(self.func.code, typ))

    def _std_call(self, stmt: IRStatement, want_name: str) -> Optional[IRCall]:
        """If stmt is `t = <std fn named want_name>(...)`, return the call."""
        if not (isinstance(stmt, IRAssign) and isinstance(stmt.target, IRLocal)):
            return None
        call = stmt.expr
        if not isinstance(call, IRCall):
            return None
        target = call.target
        if not (isinstance(target, IRConst) and isinstance(target.value, Function)):
            return None
        fname = self.func.code.partial_func_name(target.value)
        if not (fname == want_name or fname.endswith("." + want_name)):
            return None
        try:
            path = target.value.resolve_file(self.func.code).replace("\\", "/")
        except Exception:
            return None
        if "/std/" not in path:
            return None
        return call

    def _is_true_cond(self, cond: IRStatement, local: IRLocal) -> bool:
        return (
            isinstance(cond, IRBoolExpr) and cond.op == IRBoolExpr.CompareType.ISTRUE and cond.left is local
        )

"""
IRFunction and IRClass — the top-level decompilation orchestrators.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from enum import Enum as _Enum
from typing import Any, Deque, Dict, List, Optional, Set, Tuple, cast

from ..core import (
    Bytecode,
    Enum,
    destaticify,
    Fun,
    Function,
    Native,
    Obj,
    Opcode,
    Reg,
    Struct,
    Regs,
    Type,
    Virtual,
    Void,
    tIndex,
)
from ..errors import DecompError
from ..globals import DEBUG, dbg_print
from .. import disasm
from ..opcodes import arithmetic, conditionals, simple_calls
from .ir import (
    IRExpression,
    IRBlock,
    IRLocal,
    IRArithmetic,
    IRNeg,
    IRNot,
    IRTypeOf,
    IRTypeKind,
    IRAssign,
    IRCall,
    IRBoolExpr,
    IRConst,
    IRConditional,
    IRPrimitiveLoop,
    IRBreak,
    IRContinue,
    IRReturn,
    IRThrow,
    IRTryCatch,
    IRSwitch,
    IRPrimitiveJump,
    IRWhileLoop,
    IRField,
    IRBoundClosure,
    IRNew,
    IRCast,
    IRArrayAccess,
    IRRefNew,
    IRRefGet,
    IRRefSet,
    IREnumConstruct,
    IREnumIndex,
    IREnumField,
    IRUnliftedOpcode,
    IRNativeStub,
    _strip_ansi,
)
from .cfg import CFNode, CFGraph
from .opt import (
    IROptimizer,
    _bytes_mem_kind,
)
from .opt.inliner import (
    IRPrimitiveJumpLifter,
    IRConditionInliner,
    IRTempAssignmentInliner,
    IRCopyPropOptimizer,
    IRTerminalValueInliner,
)
from .opt.clean import (
    IRLoopConditionOptimizer,
    IRSelfAssignOptimizer,
    IRBoolMaterializationCollapser,
    IRArrayGrowGuardEliminator,
    IRArrayObjBoundsCheckCollapser,
    IRArrayGuardResidueEliminator,
    IRRedundantRecomputeEliminator,
    IRBlockFlattener,
    IREmptyConditionalNormalizer,
    IRTypedCatchOptimizer,
    IRElseFlattener,
    IRRedundantContinueEliminator,
    IRVoidAssignOptimizer,
    IRDeadTempEliminator,
    IRDeadCodeEliminator,
    IRDeadStoreEliminator,
    IRSequentialTempFolder,
    IRDeadAssignmentEliminator,
    IRConstructorFolder,
    IREnumConstructorFolder,
    IRAnonObjectLiteralOptimizer,
    IRShiftConstantOptimizer,
    IRGuardOrMerger,
    IRTernaryRecovery,
)
from .opt.strings import (
    IRGlobalStringOptimizer,
    IRStringIntConcatOptimizer,
    IRStringAllocOptimizer,
    IRTraceOptimizer,
    IRStringConcatFolder,
)
from .opt.stringalloc import IRStringAllocInliner
from .opt.arrays import (
    IRNativeArrayAllocOptimizer,
    IRArrayObjWrapperOptimizer,
    IRNativeMapAllocOptimizer,
    IRBytesAllocOptimizer,
    IRArrayPatternOptimizer,
)
from .opt.loops import (
    IRLoopRerollOptimizer,
    IRUnrolledLoopRerollOptimizer,
    IRForEachLoopOptimizer,
    IRIntRangeLoopOptimizer,
)
from .opt.switches import (
    IRIntSwitchOptimizer,
    IREnumSwitchOptimizer,
)


def _obj_field_name(field_core: Any, field_index: int, code: Bytecode) -> str:
    """Resolve an Obj field's debug name, falling back to a synthesized name
    when it's empty (e.g. HL's per-interface Virtual-typed dispatch cache
    slot, which has no source-level name)."""
    name = field_core.name.resolve(code)
    return name if name else f"__hidden{field_index}"


def _build_enum_global_map(code: Bytecode) -> Dict[int, Tuple[str, tIndex]]:
    """
    HashLink stores parameterless enum constants as globals whose type is the
    enum type. Build a map from global index to the constructor name and enum
    type index so that `GetGlobal` can be lifted to `Red`/`Green`/... instead
    of an opaque enum-typed global object.

    The static initializer that populates these globals reads them out of the
    enum's own `__evalues__` array by construct index (`GetArray(evalues,
    Int(N))` then `SetGlobal(g, ...)`), so trace that pattern directly to
    recover the exact (global -> construct index) mapping. The order globals
    are *allocated* in (their numeric index) does not necessarily match
    declaration order — it depends on which construct is first referenced
    during compilation — so guessing via sorted-globals-zip-constructs is
    unreliable and silently mismatches names when an enum has more than one
    construct referenced across the program (see e.g. haxe.io.Error, where
    `OutsideBounds`, not `Blocked`, ends up at the lowest global index).
    """
    enum_globals: Dict[int, List[int]] = {}
    for gi, gt in enumerate(code.global_types):
        typ = gt.resolve(code)
        if isinstance(typ.definition, Enum):
            enum_globals.setdefault(gt.value, []).append(gi)

    result: Dict[int, Tuple[str, tIndex]] = {}
    resolved_globals: Set[int] = set()
    all_enum_globals: Set[int] = set()
    for globals_for_type in enum_globals.values():
        all_enum_globals.update(globals_for_type)

    # Pass 1: trace the actual `__evalues__[N]` initializer pattern.
    for func in code.functions:
        if isinstance(func, Native):
            continue
        reg_int_value: Dict[int, int] = {}
        reg_array_index: Dict[int, int] = {}  # GetArray dst -> construct index
        for op in func.ops:
            if op.op == "Int":
                try:
                    resolved = op.df["ptr"].resolve(code)
                    reg_int_value[op.df["dst"].value] = int(getattr(resolved, "value", resolved))
                except Exception:
                    pass
            elif op.op == "GetArray":
                idx_reg = op.df["index"].value
                if idx_reg in reg_int_value:
                    reg_array_index[op.df["dst"].value] = reg_int_value[idx_reg]
            elif op.op in ("SafeCast", "UnsafeCast", "Mov"):
                src_reg = op.df["src"].value
                if src_reg in reg_array_index:
                    reg_array_index[op.df["dst"].value] = reg_array_index[src_reg]
            elif op.op == "SetGlobal":
                gi = op.df["global"].value
                src_reg = op.df["src"].value
                if gi in all_enum_globals and src_reg in reg_array_index:
                    type_idx = code.global_types[gi].value
                    enum_def = code.types[type_idx].definition
                    if isinstance(enum_def, Enum):
                        construct_idx = reg_array_index[src_reg]
                        if 0 <= construct_idx < len(enum_def.constructs):
                            construct = enum_def.constructs[construct_idx]
                            result[gi] = (
                                construct.name.resolve(code),
                                code.global_types[gi],
                            )
                            resolved_globals.add(gi)

    # Pass 2: fall back to the declaration-order guess for anything the
    # initializer trace didn't cover (e.g. an enum with only one referenced
    # parameterless construct, where ordering can't be ambiguous anyway).
    for type_idx, globals_for_type in enum_globals.items():
        enum_def = code.types[type_idx].definition
        if not isinstance(enum_def, Enum):
            continue
        remaining = sorted(gi for gi in globals_for_type if gi not in resolved_globals)
        if not remaining:
            continue
        parameterless = [c for c in enum_def.constructs if c.nparams.value == 0]
        used_names = {result[gi][0] for gi in globals_for_type if gi in result}
        remaining_constructs = [c for c in parameterless if c.name.resolve(code) not in used_names]
        for gi, construct in zip(remaining, remaining_constructs):
            result[gi] = (construct.name.resolve(code), code.global_types[gi])
    return result


def _cached_enum_global_map(code: Bytecode) -> Dict[int, Tuple[str, tIndex]]:
    """Cached `_build_enum_global_map`.

    The map is a property of the whole image (it traces every static
    initializer's opcodes), but it is needed by every lifted function. Building
    it per `IRFunction` made constructing one function O(all opcodes in the
    image), so decompiling N functions cost O(N * image) - minutes of pure
    rescanning on a 37k-function image. `Bytecode.invalidate_findex_cache`
    drops it when functions are mutated.
    """
    cached = code._enum_global_map
    if cached is None:
        cached = _build_enum_global_map(code)
        code._enum_global_map = cached
    return cached


class IRFunction:
    """
    Intermediate representation of a function.
    """

    def __init__(
        self,
        code: Bytecode,
        func: Function,
        do_optimize: bool = True,
        no_lift: bool = False,
        capture_layers: bool = False,
    ) -> None:
        code.require_executable("construct decompiler IR")
        self.func = func
        self.code = code
        # Declare all instance attributes with types upfront so mypy can track them.
        self.cfg: Optional[CFGraph] = None
        self.block: IRBlock = IRBlock(code)
        self.locals: List[IRLocal] = []
        self.all_locals: List[IRLocal] = []  # all created locals including superseded splits
        self.opcodes: str = ""
        self.cfg_data: Dict[str, Any] = {"nodes": [], "edges": []}
        self.layer_snapshots: List[Tuple[str, str, bool]] = []
        self._lift_cache: Dict[
            Tuple[Optional[CFNode], Optional[CFNode], int, Tuple[int, ...], frozenset[int]],
            Tuple[IRBlock, List[IRLocal], Set[int]],
        ] = {}
        self._enum_global_map: Dict[int, Tuple[str, tIndex]] = {}
        self.capture_layers: bool = capture_layers
        self._render_subs: Optional[Any] = None
        self._containing_class: Optional[Any] = None
        if isinstance(func, Native):
            # Native entries have no HL bytecode; represent them as a stub block.
            self.block.statements.append(IRNativeStub(code, func))
            self._enum_global_map = _cached_enum_global_map(code)
            return
        self.cfg = CFGraph(func)
        self.cfg.build()
        self._enum_global_map = _cached_enum_global_map(code)
        self.ops = func.ops
        # Depth of Trap regions currently being lifted; a backedge jump to the
        # enclosing loop header inside a trap is an explicit `continue` in the
        # source (Haxe's HL codegen is sensitive to it: without the continue a
        # constant-bounds loop with a catch can be unrolled by the compiler).
        self._trap_depth = 0
        self._lift(no_lift=no_lift)
        if do_optimize:
            self.optimizers: List[IROptimizer] = [
                IRBlockFlattener(self),
                IRConstructorFolder(self),
                IREnumConstructorFolder(self),
                IRPrimitiveJumpLifter(self),
                IRGlobalStringOptimizer(self),
                IRStringIntConcatOptimizer(self),
                IRConditionInliner(self),
                IRArrayGrowGuardEliminator(self),
                IRLoopConditionOptimizer(self),
                IRSelfAssignOptimizer(self),
                IRRedundantContinueEliminator(self),
                IRCopyPropOptimizer(self),
                IRBoolMaterializationCollapser(self),
                IRShiftConstantOptimizer(self),
                IRElseFlattener(self),
                IRTempAssignmentInliner(self, aggressive=False),
                IRTempAssignmentInliner(self, aggressive=True),
                IRStringAllocOptimizer(self),
                IRStringAllocInliner(self),
                IRSequentialTempFolder(self),
                IRDeadTempEliminator(self),
                IRDeadCodeEliminator(self),
                IRArrayPatternOptimizer(self),
                IRNativeArrayAllocOptimizer(self),
                IRArrayObjWrapperOptimizer(self),
                IRNativeMapAllocOptimizer(self),
                IRBytesAllocOptimizer(self),
                IRTempAssignmentInliner(self, aggressive=True, past_kills=True),
                IRTempAssignmentInliner(self, aggressive=False, move_into_reads=True),
                IRArrayObjBoundsCheckCollapser(self),
                IRLoopConditionOptimizer(self, retry=True),
                IRVoidAssignOptimizer(self),
                IRDeadCodeEliminator(self),
                IRSelfAssignOptimizer(self),
                IRTraceOptimizer(self),
                IRTempAssignmentInliner(self, aggressive=False, move_into_reads=True),
                IRConditionInliner(self),
                IRAnonObjectLiteralOptimizer(self),
                IRStringConcatFolder(self),
                IRIntSwitchOptimizer(self),
                IRTerminalValueInliner(self),
                IRDeadTempEliminator(self),
                IRDeadCodeEliminator(self),
                IRBlockFlattener(self),
                IRLoopRerollOptimizer(self),
                IRUnrolledLoopRerollOptimizer(self),
                IRForEachLoopOptimizer(self),
                IRIntRangeLoopOptimizer(self),
                IRTempAssignmentInliner(self, aggressive=False, move_into_reads=True),
                IRDeadTempEliminator(self),
                IRDeadCodeEliminator(self),
                IRBoolMaterializationCollapser(self),
                IRDeadStoreEliminator(self),
                IRDeadAssignmentEliminator(self),
                IRGuardOrMerger(self),
                IRRedundantRecomputeEliminator(self),
                IRTernaryRecovery(self),
                IREmptyConditionalNormalizer(self),
                IRTerminalValueInliner(self),
                IRArrayObjBoundsCheckCollapser(self),
                IRArrayGuardResidueEliminator(self),
                IRTypedCatchOptimizer(self),
                IREnumSwitchOptimizer(self),
            ]
            # Splice in plugin optimizers gated to this bytecode (see
            # crashlink.plugins). Which classes apply is a property of the image,
            # so resolve it once per Bytecode and cache it on the code object.
            plugin_classes = self.code._plugin_optimizer_classes
            if plugin_classes is None:
                from ..plugins import optimizers_for

                plugin_classes = (
                    optimizers_for(self.code, "start"),
                    optimizers_for(self.code, "end"),
                )
                self.code._plugin_optimizer_classes = plugin_classes
            starts, ends = plugin_classes
            self.optimizers = [cls(self) for cls in starts] + self.optimizers + [cls(self) for cls in ends]
            self._optimize()
            self.apply_annotations()

    def _lift(self, no_lift: bool = False) -> None:
        """Lift function to IR"""
        assert self.cfg is not None
        for i, reg in enumerate(self.func.regs):
            local = IRLocal(f"var{i}", reg, code=self.code, reg_idx=i, defining_op_idx=None)
            self.locals.append(local)
            self.all_locals.append(local)
        self._build_assign_map()
        self._new_defined_regs: Set[int] = set()
        self._name_locals()
        if not no_lift:
            if self.cfg.entry:
                self.block = self._lift_block(self.cfg.entry, set())
            elif not self.func.ops:
                # Opcode-less functions (e.g. de-HL/C reconstructions) keep the
                # initial empty block - surrounding structure is still useful.
                pass
            else:
                raise DecompError("Function CFG has no entry node, cannot lift to IR")
        else:
            dbg_print("Skipping lift.")

    def _is_instance_method(self) -> bool:
        """Return True if this function is bound as a prototype on a class."""
        findex = self.func.findex.value
        owner = self.code.get_proto_owner(findex)
        # `Struct` is an `Obj` subclass for struct-kind types, which don't count as classes here.
        return (
            owner is not None
            and not isinstance(owner, Struct)
            and self.code.get_findex_map().get(findex) is self.func
        )

    def _build_assign_map(self) -> None:
        """Build a mapping from op index to (register, name) for SSA-esque splitting."""
        self._op_assigns: Dict[int, Dict[int, str]] = {}
        self._op_aliases: Dict[int, List[Tuple[int, str]]] = {}
        self._user_reg_indices: Set[int] = set()
        self._reg_first_assign: Dict[int, int] = {}
        self._op_id_to_idx: Dict[int, int] = {id(op): i for i, op in enumerate(self.ops)}
        if not (self.func.has_debug and self.func.assigns):
            return
        # Assigns with op index 0 name function parameters rather than pointing at
        # a `dst`-producing op, so they need the same register offset as in
        # _name_locals (register 0 is `this` in instance methods/constructors).
        is_instance = self._is_instance_method()
        has_this_ops = any(op.op in ("SetThis", "GetThis") for op in self.func.ops)
        param_start = 1 if (is_instance or has_this_ops) else 0
        param_idx = 0
        for assign in self.func.assigns:
            val = assign[1].value - 1
            if val < 0:
                reg = param_start + param_idx
                param_idx += 1
                if reg < len(self.func.regs):
                    self._user_reg_indices.add(reg)
                continue
            op = self.ops[val]
            try:
                reg = op.df["dst"].value
            except KeyError:
                continue
            name = assign[0].resolve(self.code)
            self._user_reg_indices.add(reg)
            if val not in self._op_assigns:
                self._op_assigns[val] = {}
            # Keep the first debug name for a given op+reg: later names at the
            # same op are aliases (e.g. `var b = a` compiled to the same
            # register), and the earlier name is the one used by subsequent
            # expressions.
            if reg not in self._op_assigns[val]:
                self._op_assigns[val][reg] = name
            elif name != self._op_assigns[val][reg]:
                # `var b = a;` compiled away to the same register: keep the alias
                # so lifting can re-emit it as an explicit copy.
                self._op_aliases.setdefault(val, []).append((reg, name))
            if reg not in self._reg_first_assign or val < self._reg_first_assign[reg]:
                self._reg_first_assign[reg] = val

    def is_scoped_user_temp(self, local: "IRLocal") -> bool:
        """Whether an anonymous `varN` temp actually is a user-named variable.

        The function-wide `_user_reg_indices` set marks a register as user-named
        if *any* debug assign anywhere in the function names it — including
        assigns confined to an inner block. A compiler temp that reuses such a
        register after (or before) that block inherits the protection purely
        because `int(name[3:])` matches, even though the temp's own defining op
        has no debug name. That is the scope leak: the temp is not a real
        variable. A `varN` temp is only genuinely user-named when its register
        carries a debug name *at the temp's own defining op*.
        """
        if not (local.name.startswith("var") and local.name[3:].isdigit()):
            return False
        if local.defining_op_idx is None:
            return False
        return local.reg_idx in self._op_assigns.get(local.defining_op_idx, {})

    def _get_local(self, reg_idx: int) -> IRLocal:
        """Get the current IRLocal for a register, respecting SSA-esque name transitions."""
        return self.locals[reg_idx]

    def _split_local(
        self, reg_idx: int, name: str, defining_op_idx: Optional[int] = None, avoid_same_reg: bool = False
    ) -> IRLocal:
        """Create a new IRLocal for a register with a specific name (SSA-esque split).
        avoid_same_reg also forces a name distinct from the register's current local."""
        reg_type = self.func.regs[reg_idx]
        new_type = reg_type.resolve(self.code)
        # Avoid name collisions only with a different register of a different
        # type. Same-type duplicates are usually the same source variable split
        # across registers -- unless that other register is later recycled as
        # an anonymous compiler temp (self._has_untracked_reuse), in which case
        # its debug name isn't reliably "the same variable" and must not be
        # allowed to silently collide with a genuinely different one that
        # happens to share both the name and the type.
        base_name = name
        suffix = 1
        existing_names = {
            loc.name
            for i, loc in enumerate(self.locals)
            if i != reg_idx and (loc.get_type() != new_type or self._has_untracked_reuse(i))
        }
        if avoid_same_reg:
            existing_names.add(self.locals[reg_idx].name)
        while name in existing_names:
            name = f"{base_name}{suffix}"
            suffix += 1
        new_local = IRLocal(
            name,
            reg_type,
            code=self.code,
            reg_idx=reg_idx,
            defining_op_idx=defining_op_idx,
        )
        self.locals[reg_idx] = new_local
        self.all_locals.append(new_local)
        # Cached blocks may still reference the old local object; force them to
        # be re-lifted so they pick up the new name.
        self._lift_cache.clear()
        return new_local

    def _has_untracked_reuse(self, reg: int) -> bool:
        """True if register `reg` is written again, after its own first debug-named
        definition, by an op that isn't itself a debug-named assignment for `reg` —
        i.e. the register gets recycled as an anonymous compiler temp somewhere in
        its remaining lifetime, rather than staying the same named source variable
        for every subsequent write."""
        first_assign = self._reg_first_assign.get(reg)
        if first_assign is None or first_assign < 0:
            return False
        for op_idx in range(first_assign + 1, len(self.ops)):
            op = self.ops[op_idx]
            if op.op == "Setref":
                continue  # "dst" is a read (the ref being written through), not a write
            if not (op.df and "dst" in op.df) or op.df["dst"].value != reg:
                continue
            named_here = self._op_assigns.get(op_idx, {})
            if reg not in named_here:
                # A self-referential write (b++, b = b + 1, b += 5) continues
                # the same source variable rather than recycling the register
                # as an anonymous temp. Counting it as reuse would make
                # _split_local disambiguate an unrelated register that shares
                # the name (e.g. `b += 5` lifted into a fresh reg rendering as
                # `var b1` instead of `b = b + 5`).
                if self._is_continuation_write(op):
                    continue
                return True
        return False

    def _is_continuation_write(self, op: Opcode) -> bool:
        """True if `op`'s dst-write plausibly continues the register's current named
        variable (e.g. `i++`, `i = i + 1`) rather than starting an unrelated value."""
        if op.op in ("Incr", "Decr"):
            return True
        if op.op in arithmetic and op.df and "dst" in op.df:
            dst_val = op.df["dst"].value
            a, b = op.df.get("a"), op.df.get("b")
            if (a is not None and a.value == dst_val) or (b is not None and b.value == dst_val):
                return True
        return False

    def _check_assign(self, op_idx: int) -> None:
        """Check if this op index has an assign entry and split the local if needed."""
        op = self.ops[op_idx]
        new_reg_idx: Optional[int] = None
        prior_name: Optional[str] = None
        if op.op == "New" and op.df and "dst" in op.df:
            new_reg_idx = op.df["dst"].value
            prior_name = self.locals[new_reg_idx].name
        self._check_assign_inner(op_idx, op)
        if new_reg_idx is not None:
            # Two `New`s reusing one register must not share an IRLocal, or a stored reference aliases the later alloc.
            if new_reg_idx in self._new_defined_regs and self.locals[new_reg_idx].name == prior_name:
                self._split_local(
                    new_reg_idx, self.locals[new_reg_idx].name, defining_op_idx=op_idx, avoid_same_reg=True
                )
            self._new_defined_regs.add(new_reg_idx)

    def _check_assign_inner(self, op_idx: int, op: Opcode) -> None:
        if op_idx in self._op_assigns:
            for reg_idx, name in self._op_assigns[op_idx].items():
                current = self.locals[reg_idx]
                if current.name != name:
                    self._split_local(reg_idx, name, defining_op_idx=op_idx)
            return
        # No debug name at this op. If it still writes a register that currently
        # holds a real (debug-sourced) name, and the write clearly doesn't derive
        # from that register's own prior value, the register is being recycled as
        # an anonymous compiler temp — split it back to a synthetic name so later
        # reads of it aren't mistaken for reads of the earlier named variable
        # (e.g. a loop counter's register reused afterward to hold an unrelated
        # `.length` value, which would otherwise still render as the loop
        # variable's name and get protected from inlining as if it were real).
        if not (op.df and "dst" in op.df):
            return
        if op.op == "Setref":
            # Setref's "dst" is the ref pointer being written *through*, not a
            # register receiving a fresh value -- it's a read of the register
            # holding the ref, same as any other operand.
            return
        reg_idx = op.df["dst"].value
        current = self.locals[reg_idx]
        default_name = f"var{reg_idx}"
        if current.name != default_name and not self._is_continuation_write(op):
            self._split_local(reg_idx, default_name, defining_op_idx=op_idx)

    def apply_annotations(self) -> None:
        """Apply renames and comments from code.annotations to this IR function in-place."""
        store = self.code.annotations
        findex = self.func.findex.value
        for local in self.all_locals:
            if local.reg_idx is not None:
                rename = store.get_rename(findex, local.reg_idx, local.defining_op_idx)
                if rename is not None:
                    local.name = rename

        def _walk(block: IRBlock) -> None:
            for stmt in block.statements:
                # A statement folded from several opcodes (see IRStatement.adopt)
                # should surface a comment placed on any one of them.
                for op_idx in sorted(stmt.src_op_idxs):
                    comment = store.get_comment(findex, op_idx)
                    if comment is not None:
                        stmt.comment = comment
                        break
                for child in stmt.get_children():
                    if isinstance(child, IRBlock):
                        _walk(child)

        _walk(self.block)

    def _optimize(self) -> None:
        """Optimize the IR"""

        if DEBUG:
            dbg_print("----- Disasm -----")
            dbg_print(disasm.func(self.code, self.func))
            dbg_print("----- LLIL -----")
            dbg_print(self.block.pprint())
        if self.capture_layers:
            self.opcodes = disasm.func(self.code, self.func)
            self.cfg_data = self._cfg_to_dict()
            self.layer_snapshots.append(("LLIR", _strip_ansi(self.block.pprint()), True))
        for o in self.optimizers:
            ran = o.should_run()
            if DEBUG:
                dbg_print(f"----- {o.__class__.__name__} ({'ran' if ran else 'skipped'}) -----")
            if ran:
                o.optimize()
            if DEBUG:
                dbg_print(self.block.pprint())
            if self.capture_layers:
                self.layer_snapshots.append((o.__class__.__name__, _strip_ansi(self.block.pprint()), ran))

    def _cfg_to_dict(self) -> Dict[str, Any]:
        """Serialize the control-flow graph to a JSON-friendly structure."""
        assert self.cfg is not None
        cfg = self.cfg
        node_ids = {id(node): i for i, node in enumerate(cfg.nodes)}
        nodes: List[Dict[str, Any]] = []
        for i, node in enumerate(cfg.nodes):
            label_lines = []
            for op in node.ops:
                parts = [op.op or "?"] + [str(v) for v in op.df.values()]
                label_lines.append(". ".join(parts))
            nodes.append(
                {
                    "id": i,
                    "label": f"BB{i}",
                    "ops": label_lines,
                    "base_offset": node.base_offset,
                    "is_entry": node is cfg.entry,
                }
            )
        edges: List[Dict[str, Any]] = []
        for node in cfg.nodes:
            src = node_ids[id(node)]
            for target, edge_type in node.branches:
                dst = node_ids.get(id(target))
                if dst is not None:
                    edges.append({"from": src, "to": dst, "type": edge_type})
        return {"nodes": nodes, "edges": edges, "dot": self._cfg_to_dot(node_ids)}

    def to_dot(self) -> Optional[str]:
        """Render this function's CFG as Graphviz DOT source, or None for natives
        (which have no bytecode/CFG). `self.cfg` is built unconditionally for
        non-natives in `__init__`, so this works regardless of `capture_layers`."""
        if self.cfg is None:
            return None
        node_ids = {id(node): i for i, node in enumerate(self.cfg.nodes)}
        return self._cfg_to_dot(node_ids)

    def _cfg_to_dot(self, node_ids: Dict[int, int]) -> str:
        """Produce a Graphviz DOT representation of the CFG.

        Mirrors the entry/return node coloring and per-branch-type edge
        coloring conventions of CFGraph.graph()/style_node(), just remapped
        onto the Catppuccin Mocha palette used by the crashtest site.
        """
        assert self.cfg is not None
        cfg = self.cfg

        def _escape(s: str) -> str:
            return s.replace("\\", "\\\\").replace('"', '\\"')

        def _node_fill(node: CFNode) -> str:
            if node is cfg.entry:
                return '"#a6e3a1", fontcolor="#11111b"'  # green, like style_node's entry
            if any(op.op == "Ret" for op in node.ops):
                return '"#94e2d5", fontcolor="#11111b"'  # teal, like style_node's return blocks
            return '"#313244", fontcolor="#cdd6f4"'

        def _edge_style(edge_type: str) -> str:
            if edge_type == "true":
                return 'color="#a6e3a1", fontcolor="#a6e3a1", label="true"'
            if edge_type == "false":
                return 'color="#f38ba8", fontcolor="#f38ba8", label="false"'
            if edge_type.startswith("switch: "):
                case = edge_type.split("switch: ")[1].strip()
                color = "#f38ba8" if case == "default" else "#cba6f7"
                return f'color="{color}", fontcolor="{color}", label="{_escape(case)}"'
            if edge_type == "trap":
                return 'color="#f9e2af", fontcolor="#f9e2af", label="trap"'
            return 'color="#89b4fa"'

        lines = [
            "digraph CFG {",
            "  rankdir=TB;",
            "  nodesep=0.4;",
            "  ranksep=0.5;",
            '  node [shape=box, fontname="monospace", fontsize=11, margin="0.15,0.1", style="rounded,filled", fillcolor="#313244", fontcolor="#cdd6f4", color="#585b70"];',
            '  edge [fontname="monospace", fontsize=9, color="#6c7086", fontcolor="#a6adc8"];',
        ]
        for i, node in enumerate(cfg.nodes):
            op_lines = []
            for op in node.ops:
                parts = [op.op or "?"] + [str(v) for v in op.df.values()]
                op_lines.append(_escape(". ".join(parts)))
            label = _escape(f"BB{i}") + "\\l" + "\\l".join(op_lines) + "\\l"
            lines.append(f'  {i} [label="{label}", fillcolor={_node_fill(node)}];')
        for node in cfg.nodes:
            src = node_ids[id(node)]
            for target, edge_type in node.branches:
                dst = node_ids.get(id(target))
                if dst is not None:
                    lines.append(f"  {src} -> {dst} [{_edge_style(edge_type)}];")
        lines.append("}")
        return "\n".join(lines)

    def _name_locals(self) -> None:
        """Name locals based on debug info"""
        reg_assigns: List[List[str]] = [[] for _ in self.func.regs]
        # Register 0 is `this` in instance methods and constructors. Detect by
        # either: the function is bound as a prototype on a class, or the
        # function contains SetThis/GetThis opcodes (constructor).
        is_instance = self._is_instance_method()
        has_this_ops = any(op.op in ("SetThis", "GetThis") for op in self.func.ops)
        # A constructor that only delegates to `super(...)` (no field writes of
        # its own) has neither SetThis/GetThis ops nor a vtable proto entry
        # (constructors aren't virtual), so it would otherwise be misdetected
        # as a plain static function and have all its parameter names shifted
        # by one onto the wrong registers.
        is_ctor_wrapper = self.code.partial_func_name(self.func) == "__constructor__"
        has_this = is_instance or has_this_ops or is_ctor_wrapper
        if self.func.has_debug and self.func.assigns:
            for assign in self.func.assigns:
                # assign: Tuple[strRef (name), VarInt (op index)]
                val = assign[1].value - 1
                if val < 0:
                    continue
                reg: Optional[int] = None
                op = self.ops[val]
                try:
                    op.df["dst"]
                    reg = op.df["dst"].value
                except KeyError:
                    pass
                if reg is not None:
                    name = assign[0].resolve(self.code)
                    if name not in reg_assigns[reg]:
                        reg_assigns[reg].append(name)
        if self.func.assigns and self.func.has_debug:
            # Assigns with op index 0 (val == -1 above) name function parameters,
            # in order — not necessarily register 0: that's `this` for instance
            # methods/constructors, so parameters start at register 1 there.
            param_start = 1 if has_this else 0
            param_candidates = [assign for assign in self.func.assigns if assign[1].value <= 0]
            param_count: Optional[int] = None
            fun_def = self.func.type.resolve(self.code).definition
            if isinstance(fun_def, Fun):
                param_count = max(0, len(fun_def.args) - (1 if has_this else 0))
            seen_param_names: Set[str] = set()
            param_idx = 0
            for assign in param_candidates:
                if param_count is not None and param_idx >= param_count:
                    break
                name = assign[0].resolve(self.code)
                # A body local can shadow a parameter with the same debug name
                # (e.g. ArrayBytes.getDyn's `pos`). Keep only the first parameter
                # use of a name and continue with the next parameter slot.
                if name in seen_param_names:
                    continue
                reg = param_start + param_idx
                if reg >= len(reg_assigns):
                    break
                if name not in reg_assigns[reg]:
                    reg_assigns[reg].append(name)
                # A parameter name applies from the start of the function, even if
                # the same register is later reassigned with the same debug name.
                self._reg_first_assign[reg] = -1
                seen_param_names.add(name)
                param_idx += 1
        for i, _reg in enumerate(self.func.regs):
            if _reg.resolve(self.code).definition and isinstance(_reg.resolve(self.code).definition, Void):
                if "voidReg" not in reg_assigns[i]:
                    reg_assigns[i].append("voidReg")

        # A register may be used as an anonymous temporary before the first
        # debug-named assignment that names it. Naming the whole register after
        # that later debug name makes the earlier uses look like the named
        # variable (e.g. String.split's empty-delimiter loop bound becomes
        # `dlen` because reg6 is later named for delimiter.length). In that
        # case keep the pre-name segment as a temp; _check_assign will split
        # off the named segment at the debug assignment.
        first_def: Dict[int, int] = {}
        for op_idx, op in enumerate(self.ops):
            if op.df and "dst" in op.df:
                reg = op.df["dst"].value
                if reg not in first_def:
                    first_def[reg] = op_idx

        for i, local in enumerate(self.locals):
            if reg_assigns[i]:
                named_op = self._reg_first_assign.get(i)
                if named_op is not None and named_op > 0 and first_def.get(i, float("inf")) < named_op:
                    continue
                local.name = reg_assigns[i][0]

        # If the same debug name is assigned to two different registers with
        # different types, suffix the later one so Haxe sees two distinct
        # variables instead of a single Dynamic variable.
        name_to_regs: Dict[str, List[int]] = {}
        for i, local in enumerate(self.locals):
            name_to_regs.setdefault(local.name, []).append(i)
        for name, regs in name_to_regs.items():
            if len(regs) <= 1:
                continue
            typed_regs: Dict[int, List[int]] = {}
            for r in regs:
                typ = self.func.regs[r]
                typ_key = id(typ.resolve(self.code))
                typed_regs.setdefault(typ_key, []).append(r)
            # Only rename when the same debug name is used for variables with
            # different types.  Same-type duplicates are usually just different
            # registers for a single source variable — UNLESS one of them gets
            # reused as an anonymous compiler temp somewhere in between its own
            # debug-named point and the end of the function (e.g. a register
            # named "i" for one `for` loop, later recycled as a scratch temp
            # for an unrelated computation, with no debug name at that reuse
            # site to trigger `_check_assign`'s split). That register would
            # otherwise keep the stale debug name for its entire remaining
            # lifetime, corrupting every later use of it.
            if len(typed_regs) <= 1 and not any(self._has_untracked_reuse(r) for r in regs):
                # Exception: a parameter shadowed by a body local with the same
                # name must be disambiguated (e.g. ArrayBytes.getDyn's `pos`).
                ordered = sorted(regs, key=lambda r: self._reg_first_assign.get(r, float("inf")))
                param_regs = [r for r in ordered if self._reg_first_assign.get(r, float("inf")) == -1]
                if param_regs:
                    suffix = 1
                    for r in ordered:
                        if r == param_regs[0]:
                            continue
                        self.locals[r].name = f"{name}{suffix}"
                        suffix += 1
                continue
            ordered = sorted(regs, key=lambda r: self._reg_first_assign.get(r, float("inf")))
            # Keep earliest reg's type as base name; suffix any other-typed regs sharing this name.
            first_type = id(self.func.regs[ordered[0]].resolve(self.code))
            suffix = 1
            for r in ordered[1:]:
                typ_key = id(self.func.regs[r].resolve(self.code))
                if typ_key != first_type:
                    self.locals[r].name = f"{name}{suffix}"
                    suffix += 1

        if self.locals and self.locals[0].name == "var0" and has_this:
            self.locals[0].name = "this"
        dbg_print("Named locals:", self.locals)

    def _find_convergence(
        self, true_node: CFNode, false_node: CFNode, visited: Set[CFNode]
    ) -> Optional[CFNode]:
        """Find where two branches of a conditional converge by following their control flow"""
        true_visited = set()
        false_visited = set()
        true_queue = [true_node]
        false_queue = [false_node]

        while true_queue or false_queue:
            if true_queue:
                node = true_queue.pop(0)
                if node in false_visited:
                    return node
                true_visited.add(node)
                for next_node, _ in node.branches:
                    if next_node not in true_visited:
                        true_queue.append(next_node)

            if false_queue:
                node = false_queue.pop(0)
                if node in true_visited:
                    return node
                false_visited.add(node)
                for next_node, _ in node.branches:
                    if next_node not in false_visited:
                        false_queue.append(next_node)

        return None  # No convergence found

    @dataclass
    class _LoopContext:
        header: CFNode
        nodes: Set[CFNode]
        exit_node: Optional[CFNode]

    @dataclass
    class _StringSwitch:
        """A string-switch lowering found in the CFG by `_match_string_switch`."""

        value_reg: int
        #: (case literal, body node) in chain order; a body may appear under several literals.
        cases: List[Tuple[str, CFNode]]
        #: Where the chain continues when no case matched: the default body, or the end.
        default: CFNode
        #: Chain nodes after the head, and every chain opcode (head's `JNull` included).
        nodes: List[CFNode]
        ops: List[Opcode]

    def _string_field(self, obj_reg: int, op: Opcode) -> Optional[str]:
        """Name of the `String` field read by `op` (a `Field` on `obj_reg`), else None."""
        if op.op != "Field" or op.df["obj"].value != obj_reg:
            return None
        definition = self.func.regs[obj_reg].resolve(self.code).definition
        if not isinstance(definition, Obj) or definition.name.resolve(self.code) != "String":
            return None
        fields = definition.resolve_fields(self.code)
        index = op.df["field"].value
        return fields[index].name.resolve(self.code) if 0 <= index < len(fields) else None

    def _match_string_case(
        self, node: CFNode, value_reg: int, is_head: bool
    ) -> Optional[Tuple[str, CFNode, CFNode, List[CFNode], List[Opcode]]]:
        """Match one case of the string-switch chain starting at `node` (see
        `_match_string_switch`). Returns (literal, body, next, case nodes after `node`,
        case opcodes)."""
        assert self.cfg is not None
        ops = node.ops
        if not ops or ops[-1].op != "JNull" or ops[-1].df["reg"].value != value_reg:
            return None
        if not is_head and len(ops) != 1:
            return None
        edges = {edge: target for target, edge in node.branches}
        miss, length_node = edges.get("true"), edges.get("false")
        if miss is None or length_node is None:
            return None
        edges = {edge: target for target, edge in length_node.branches}
        compare_node = edges.get("false")
        if edges.get("true") is not miss or compare_node is None:
            return None
        edges = {edge: target for target, edge in compare_node.branches}
        body = edges.get("true")
        if edges.get("false") is not miss or body is None:
            return None
        preds = self.cfg.predecessors
        if preds.get(length_node) != [node] or preds.get(compare_node) != [length_node]:
            return None

        # len = s.length; n = <int>; JNotEq len, n
        length_ops = length_node.ops
        if [op.op for op in length_ops] != ["Field", "Int", "JNotEq"]:
            return None
        if self._string_field(value_reg, length_ops[0]) != "length":
            return None
        length_reg = length_ops[0].df["dst"].value
        jump = length_ops[2].df
        if {jump["a"].value, jump["b"].value} != {length_reg, length_ops[1].df["dst"].value}:
            return None

        # b = s.bytes; lit = "<literal>"; r = string_compare(b, lit, len); z = 0; JEq r, z
        compare_ops = compare_node.ops
        if [op.op for op in compare_ops] != ["Field", "String", "Call3", "Int", "JEq"]:
            return None
        bytes_op, literal_op, call_op, zero_op, jump_op = compare_ops
        if self._string_field(value_reg, bytes_op) != "bytes":
            return None
        call = call_op.df
        native = call["fun"].resolve(self.code)
        if not isinstance(native, Native) or native.name.resolve(self.code) != "string_compare":
            return None
        if (call["arg0"].value, call["arg1"].value, call["arg2"].value) != (
            bytes_op.df["dst"].value,
            literal_op.df["dst"].value,
            length_reg,
        ):
            return None
        if zero_op.df["ptr"].resolve(self.code).value != 0:
            return None
        jump = jump_op.df
        if {jump["a"].value, jump["b"].value} != {call["dst"].value, zero_op.df["dst"].value}:
            return None
        # The scrutinee must survive the chain; its scratch registers are rechecked by the caller.
        if any("dst" in op.df and op.df["dst"].value == value_reg for op in [*length_ops, *compare_ops]):
            return None
        literal = literal_op.df["ptr"].resolve(self.code)
        chain_ops = [ops[-1], *length_ops, *compare_ops]
        return literal, body, miss, [length_node, compare_node], chain_ops

    def _match_string_switch(self, head: CFNode) -> Optional[_StringSwitch]:
        """
        Recognise HashLink's lowering of `switch (s) { case "lit": ... }`. Each case is three
        CFG nodes whose failure edges all lead to the next case:

            JNull s -> next                               (ends `head`; later cases hold only this)
            len = s.length; n = <int>; JNotEq len, n -> next
            b = s.bytes; lit = "<literal>"; r = string_compare(b, lit, len); z = 0; JEq r, z -> body
                                                          (falls through to next)

        The chain ends at the first `next` that is not another case on `s`: the default body, or
        the end of the switch when there is none. Lifting the three failure edges as ordinary
        conditionals copies the rest of the chain into each of them, 3^n IR for n cases when the
        case bodies fall through to a shared end; matching the chain lifts it as one switch.
        """
        assert self.cfg is not None
        last = head.ops[-1]
        value_reg = last.df["reg"].value
        cases: List[Tuple[str, CFNode]] = []
        nodes: List[CFNode] = []
        chain_ops: List[Opcode] = []
        node = head
        previous_case: Set[CFNode] = set()
        while True:
            # Only the previous case's chain may jump into a later case.
            if node is not head and not set(self.cfg.predecessors.get(node, [])) <= previous_case:
                break
            matched = self._match_string_case(node, value_reg, node is head)
            if matched is None:
                break
            literal, body, miss, case_nodes, case_ops = matched
            if node is not head:
                nodes.append(node)
            nodes.extend(case_nodes)
            chain_ops.extend(case_ops)
            cases.append((literal, body))
            previous_case = {node, *case_nodes}
            node = miss
        if not cases:
            return None
        # The scratch registers are compiler temporaries: lifting the chain as a switch drops
        # their writes, which is only sound if nothing reads them afterwards.
        scratch = {
            op.df["dst"].value for op in chain_ops if "dst" in op.df and op.df["dst"].value != value_reg
        }
        for target in {body for _, body in cases} | {node}:
            if any(self._register_live_at(target, reg) for reg in scratch):
                return None
        return self._StringSwitch(value_reg, cases, node, nodes, chain_ops)

    def _lift_string_switch(
        self,
        block: IRBlock,
        head: CFNode,
        switch: _StringSwitch,
        visited: Set[CFNode],
        stop_at: Optional[CFNode],
        loop_ctx: Optional[_LoopContext],
    ) -> None:
        """Lift a `_match_string_switch` chain as one `IRSwitch`, each body lifted once."""
        assert self.cfg is not None
        cfg = self.cfg
        visited.update(switch.nodes)
        targets = [body for _, body in switch.cases] + [switch.default]
        allowed_nodes = loop_ctx.nodes if loop_ctx else None
        convergence = cfg.immediate_post_dominators.get(head)
        if convergence is None:
            # Some cases return or throw, so nothing post-dominates the head. Merge where the
            # cases that do fall through all meet, as a conditional does for its live arm; a
            # case body itself never qualifies, or it would be hoisted out of the switch.
            live = [target for target in targets if not self._is_terminal_branch_node(target, loop_ctx)]
            bodies = {body for _, body in switch.cases}
            common = (
                set.intersection(*(cfg.post_dominators.get(target, set()) for target in live)) - bodies
                if live
                else set()
            )
            convergence = (
                max(common, key=lambda n: len(cfg.post_dominators.get(n, ()))) if common else stop_at
            )
        # Same boundary rules as a conditional: never merge past the enclosing boundary, and
        # keep a loop's cases from converging outside it when one of them loops back.
        if (
            stop_at is not None
            and convergence is not None
            and convergence != stop_at
            and self._reaches_bypassing(tuple(targets), stop_at, convergence, allowed_nodes)
        ):
            convergence = stop_at
        if (
            loop_ctx
            and convergence is not None
            and convergence not in loop_ctx.nodes
            and convergence != loop_ctx.header
            and any(target in loop_ctx.nodes for target in targets)
        ):
            convergence = loop_ctx.header

        entry_locals = self.locals.copy()
        entry_new_regs = self._new_defined_regs.copy()
        new_regs = set(entry_new_regs)
        arms: List[Tuple[IRBlock, List[IRLocal]]] = []

        def lift_arm(target: CFNode) -> IRBlock:
            self.locals = entry_locals.copy()
            self._new_defined_regs = entry_new_regs.copy()
            arm = self._lift_loop_edge(target, visited, loop_ctx)
            if arm is None:
                arm = self._lift_block(target, visited.copy(), stop_at=convergence, loop_ctx=loop_ctx)
            arms.append((arm, self.locals.copy()))
            new_regs.update(self._new_defined_regs)
            return arm

        cases: Dict[IRConst, IRBlock] = {}
        aliases: Dict[IRConst, List[IRConst]] = {}
        keys: Dict[CFNode, IRConst] = {}
        for literal, target in switch.cases:
            value = IRConst(self.code, IRConst.ConstType.GLOBAL_STRING, value=literal)
            key = keys.get(target)
            if key is not None:
                aliases.setdefault(key, []).append(value)
                continue
            keys[target] = value
            cases[value] = lift_arm(target)
        default = lift_arm(switch.default)
        self._new_defined_regs = new_regs
        self._join_branch_locals(entry_locals, arms, convergence)

        ir_switch = IRSwitch(self.code, entry_locals[switch.value_reg], cases, default, aliases)
        ir_switch.src_op_idxs = {
            self._op_id_to_idx[id(op)] for op in switch.ops if id(op) in self._op_id_to_idx
        }
        block.statements.append(ir_switch)
        next_block_ir = self._lift_block(convergence, visited, stop_at=stop_at, loop_ctx=loop_ctx)
        block.statements.extend(next_block_ir.statements)

    def _catch_has_explicit_type(self, catch_branch_node: "CFNode") -> bool:
        """Detect whether the original source wrote an explicit type on the
        catch clause (`catch (e: Dynamic)`) rather than leaving it untyped
        (`catch (e)`).

        Both infer to the same Haxe type, but Haxe's codegen differs subtly:
        an explicit annotation emits a dead `Null` store to a scratch register
        that's never read again, used here purely as a bytecode fingerprint to
        reproduce the same choice when recompiling decompiled source.
        """

        def _read_regs(o: Opcode) -> Set[int]:
            regs: Set[int] = set()
            for key, val in o.df.items():
                if key == "dst":
                    continue
                if isinstance(val, Reg):
                    regs.add(val.value)
                elif isinstance(val, Regs):
                    regs.update(r.value for r in val.value)
            return regs

        for op in catch_branch_node.ops:
            if op.op != "Null":
                continue
            dst = op.df["dst"].value
            if not any(dst in _read_regs(o) for o in self.func.ops if o is not op):
                return True
        return False

    def _resolve_method_field(
        self, obj_local: "IRLocal", obj_type: Type, field_idx: int
    ) -> Optional["IRField"]:
        """Build the `obj.method` IRField targeted by a CallMethod/CallThis/
        InstanceClosure `field` operand.

        For an ``Obj`` the operand indexes the virtual method table, so the
        proto is looked up by ``pindex`` across the class hierarchy. For a
        ``Virtual`` it indexes the (method-typed) data fields directly. Returns
        ``None`` when the target cannot be resolved.
        """
        defn = obj_type.definition
        if isinstance(defn, Obj):
            proto = self.code.proto_by_pindex(defn, field_idx)
            if proto is None:
                return None
            fun = proto.findex.resolve(self.code)
            return IRField(self.code, obj_local, proto.name.resolve(self.code), fun.type)
        if isinstance(defn, Virtual):
            if field_idx >= len(defn.fields):
                return None
            field_core = defn.fields[field_idx]
            return IRField(
                self.code,
                obj_local,
                field_core.name.resolve(self.code),
                field_core.type,
            )
        return None

    def _lift_ops_into_block(self, block: IRBlock, ops: List[Opcode]) -> None:
        _debuginfo = self.func.debuginfo.value if (self.func.has_debug and self.func.debuginfo) else None
        for op in ops:
            op_idx = self._op_id_to_idx.get(id(op))
            # Capture the register-to-local mapping before any debug-name split.
            # HashLink frequently reuses a register as both a source and the
            # destination for the same opcode (e.g. `reg0 = String.__add__(reg0,
            # reg1)`).  If we split the local for the destination first, the
            # source operand incorrectly picks up the new, empty local.  Source
            # operands below therefore read from this pre-opcode snapshot, while
            # destinations read from `self.locals` after the split.
            source_locals = self.locals.copy()
            if op_idx is not None:
                self._check_assign(op_idx)
            if op.op == "Label":
                continue
            _prev_len = len(block.statements)

            if op.op == "Nop":
                continue

            if op.op in arithmetic:
                dst = self.locals[op.df["dst"].value]
                lhs = source_locals[op.df["a"].value]
                rhs = source_locals[op.df["b"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst,
                        IRArithmetic(
                            self.code,
                            lhs,
                            rhs,
                            IRArithmetic.ArithmeticType[op.op.upper()],
                        ),
                    )
                )
            elif op.op in ["Int", "Float", "Bool", "Bytes", "String", "Null"]:
                dst = self.locals[op.df["dst"].value]
                const_type = IRConst.ConstType[op.op.upper()]
                value = op.df["value"].value if op.op == "Bool" else None
                if op.op not in ["Bool", "Null"]:
                    const = IRConst(self.code, const_type, op.df["ptr"], value)
                else:
                    const = IRConst(self.code, const_type, value=value)
                block.statements.append(IRAssign(self.code, dst, const))
            elif op.op in simple_calls:
                n = int(op.op[-1]) if op.op != "CallN" else len(op.df["args"].value)
                dst = self.locals[op.df["dst"].value]
                fun = IRConst(self.code, IRConst.ConstType.FUN, op.df["fun"])
                args = (
                    [source_locals[op.df[f"arg{i}"].value] for i in range(n)]
                    if op.op != "CallN"
                    else [source_locals[arg.value] for arg in op.df["args"].value]
                )
                call_expr = IRCall(self.code, IRCall.CallType.FUNC, fun, args)

                if dst.get_type().kind.value == Type.Kind.VOID.value:
                    block.statements.append(call_expr)
                else:
                    block.statements.append(IRAssign(self.code, dst, call_expr))
            elif op.op == "CallClosure":
                dst = self.locals[op.df["dst"].value]
                fun = source_locals[op.df["fun"].value]
                args = [source_locals[arg.value] for arg in op.df["args"].value]
                call_expr = IRCall(self.code, IRCall.CallType.CLOSURE, fun, args)

                if dst.get_type().kind.value == Type.Kind.VOID.value:
                    block.statements.append(call_expr)
                else:
                    block.statements.append(IRAssign(self.code, dst, call_expr))
            elif op.op in ("CallMethod", "CallThis"):
                dst = self.locals[op.df["dst"].value]
                arg_regs = op.df["args"].value
                if op.op == "CallThis":
                    obj_local = source_locals[0]
                    obj_type = self.code.types[self.func.regs[0].value]
                    method_args = [source_locals[arg.value] for arg in arg_regs]
                elif arg_regs:
                    obj_local = source_locals[arg_regs[0].value]
                    obj_type = obj_local.get_type()
                    method_args = [source_locals[arg.value] for arg in arg_regs[1:]]
                else:
                    # A receiver-less CallMethod is malformed; keep it opaque
                    # rather than indexing off the end of an empty arg list.
                    block.statements.append(IRUnliftedOpcode(self.code, op))
                    continue
                field_expr = self._resolve_method_field(obj_local, obj_type, op.df["field"].value)
                if field_expr is not None:
                    call_expr = IRCall(self.code, IRCall.CallType.METHOD, field_expr, method_args)
                    if dst.get_type().kind.value == Type.Kind.VOID.value:
                        block.statements.append(call_expr)
                    else:
                        block.statements.append(IRAssign(self.code, dst, call_expr))
                elif dst.get_type().kind.value == Type.Kind.VOID.value:
                    block.statements.append(IRUnliftedOpcode(self.code, op))
                else:
                    block.statements.append(IRAssign(self.code, dst, IRUnliftedOpcode(self.code, op)))
            elif op.op == "Mov":
                block.statements.append(
                    IRAssign(
                        self.code,
                        self.locals[op.df["dst"].value],
                        source_locals[op.df["src"].value],
                    )
                )
            elif op.op == "GetGlobal":
                global_idx = op.df["global"].value
                enum_const = self._enum_global_map.get(global_idx)
                expr: IRExpression
                if enum_const is not None:
                    construct_name, enum_type_idx = enum_const
                    expr = IREnumConstruct(self.code, construct_name, [], enum_type_idx)
                else:
                    expr = IRConst(self.code, IRConst.ConstType.GLOBAL_OBJ, idx=op.df["global"])
                block.statements.append(
                    IRAssign(
                        self.code,
                        self.locals[op.df["dst"].value],
                        expr,
                    )
                )
            elif op.op == "SetGlobal":
                global_idx = op.df["global"].value
                # Enum singletons are reconstructed inline at each read (see
                # GetGlobal above), so the write that populates the cache has
                # no separate effect to preserve.
                if global_idx in self._enum_global_map:
                    continue
                src_local = source_locals[op.df["src"].value]
                global_target = IRConst(self.code, IRConst.ConstType.GLOBAL_OBJ, idx=op.df["global"])
                block.statements.append(IRAssign(self.code, global_target, src_local))
            elif op.op == "Field":
                dst_local = self.locals[op.df["dst"].value]
                obj_local = source_locals[op.df["obj"].value]
                obj_type = obj_local.get_type()
                if not isinstance(obj_type.definition, (Obj, Virtual)):
                    # Machine-code-lifted streams carry placeholder register
                    # types, so the object's type is not known here. Degrade to
                    # an opaque opcode - the same fallback GetThis takes below -
                    # rather than aborting the whole function's decompile.
                    block.statements.append(IRUnliftedOpcode(self.code, op))
                    continue
                field_core = op.df["field"].resolve_obj(self.code, obj_type.definition)
                field_expr = IRField(
                    self.code,
                    obj_local,
                    _obj_field_name(field_core, op.df["field"].value, self.code),
                    field_core.type,
                )
                block.statements.append(IRAssign(self.code, dst_local, field_expr))
            elif op.op == "GetThis":
                dst_local = self.locals[op.df["dst"].value]
                this_local = source_locals[0]
                this_type_def = self.code.types[self.func.regs[0].value]
                if isinstance(this_type_def.definition, (Obj, Virtual)):
                    field_core = op.df["field"].resolve_obj(self.code, this_type_def.definition)
                    field_expr = IRField(
                        self.code,
                        this_local,
                        _obj_field_name(field_core, op.df["field"].value, self.code),
                        field_core.type,
                    )
                    block.statements.append(IRAssign(self.code, dst_local, field_expr))
                else:
                    block.statements.append(IRUnliftedOpcode(self.code, op))
            elif op.op == "SetThis":
                src_local = source_locals[op.df["src"].value]
                this_local = source_locals[0]
                this_type_def = self.code.types[self.func.regs[0].value]
                if isinstance(this_type_def.definition, (Obj, Virtual)):
                    field_core = op.df["field"].resolve_obj(self.code, this_type_def.definition)
                    field_expr = IRField(
                        self.code,
                        this_local,
                        _obj_field_name(field_core, op.df["field"].value, self.code),
                        field_core.type,
                    )
                    block.statements.append(IRAssign(self.code, field_expr, src_local))
                else:
                    block.statements.append(IRUnliftedOpcode(self.code, op))
            elif op.op == "New":
                dst_local = self.locals[op.df["dst"].value]
                alloc_type_idx = self.func.regs[op.df["dst"].value]
                new_expr = IRNew(self.code, alloc_type_idx)
                block.statements.append(IRAssign(self.code, dst_local, new_expr))
            elif op.op in ("ToSFloat", "ToUFloat"):
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                if op.op == "ToUFloat" and isinstance(src_local, IRLocal):
                    src_local.is_unsigned = True

                f64_idx = self.code.find_prim_type(Type.Kind.F64)

                cast_expr = IRCast(self.code, f64_idx, src_local)
                block.statements.append(IRAssign(self.code, dst_local, cast_expr))
            elif op.op == "ToDyn" or op.op == "ToVirtual":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                cast_expr = IRCast(self.code, self.func.regs[op.df["dst"].value], src_local)
                block.statements.append(IRAssign(self.code, dst_local, cast_expr))
            elif op.op == "ToInt":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                cast_expr = IRCast(self.code, self.func.regs[op.df["dst"].value], src_local)
                block.statements.append(IRAssign(self.code, dst_local, cast_expr))
            elif op.op in ("SafeCast", "UnsafeCast"):
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                cast_expr = IRCast(self.code, self.func.regs[op.df["dst"].value], src_local)
                block.statements.append(IRAssign(self.code, dst_local, cast_expr))
            elif op.op == "GetArray":
                dst_local = self.locals[op.df["dst"].value]
                arr_local = source_locals[op.df["array"].value]
                idx_local = source_locals[op.df["index"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst_local,
                        IRArrayAccess(
                            self.code,
                            arr_local,
                            idx_local,
                            self.func.regs[op.df["dst"].value],
                        ),
                    )
                )
            elif op.op == "ArraySize":
                dst_local = self.locals[op.df["dst"].value]
                arr_local = source_locals[op.df["array"].value]
                i32_idx = self.code.find_prim_type(Type.Kind.I32)
                length_expr = IRField(self.code, arr_local, "length", i32_idx)
                block.statements.append(IRAssign(self.code, dst_local, length_expr))
            elif op.op == "GetType":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst_local,
                        IRTypeOf(self.code, src_local, self.func.regs[op.df["dst"].value]),
                    )
                )
            elif op.op == "GetTID":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst_local,
                        IRTypeKind(self.code, src_local, self.func.regs[op.df["dst"].value]),
                    )
                )
            elif op.op == "Incr":
                dst_local = self.locals[op.df["dst"].value]
                old_local = source_locals[op.df["dst"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst_local,
                        IRArithmetic(
                            self.code,
                            old_local,
                            IRConst(self.code, IRConst.ConstType.INT, value=1),
                            IRArithmetic.ArithmeticType.ADD,
                        ),
                    )
                )
            elif op.op == "Decr":
                dst_local = self.locals[op.df["dst"].value]
                old_local = source_locals[op.df["dst"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst_local,
                        IRArithmetic(
                            self.code,
                            old_local,
                            IRConst(self.code, IRConst.ConstType.INT, value=1),
                            IRArithmetic.ArithmeticType.SUB,
                        ),
                    )
                )
            elif op.op == "Neg":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                block.statements.append(IRAssign(self.code, dst_local, IRNeg(self.code, src_local)))
            elif op.op == "Not":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                block.statements.append(IRAssign(self.code, dst_local, IRNot(self.code, src_local)))
            elif op.op == "GetMem":
                dst_local = self.locals[op.df["dst"].value]
                arr_local = source_locals[op.df["bytes"].value]
                idx_local = source_locals[op.df["index"].value]
                access = IRArrayAccess(self.code, arr_local, idx_local, self.func.regs[op.df["dst"].value])
                access.bytes_access_kind = _bytes_mem_kind(self.code, self.func.regs[op.df["dst"].value])
                block.statements.append(IRAssign(self.code, dst_local, access))
            elif op.op in ("GetI16", "GetI8"):
                dst_local = self.locals[op.df["dst"].value]
                arr_local = source_locals[op.df["bytes"].value]
                idx_local = source_locals[op.df["index"].value]
                access = IRArrayAccess(self.code, arr_local, idx_local, self.func.regs[op.df["dst"].value])
                access.bytes_access_kind = "UI16" if op.op == "GetI16" else "UI8"
                block.statements.append(IRAssign(self.code, dst_local, access))
            elif op.op == "SetMem":
                arr_local = source_locals[op.df["bytes"].value]
                idx_local = source_locals[op.df["index"].value]
                src_local = source_locals[op.df["src"].value]
                src_reg = op.df["src"].value
                access = IRArrayAccess(self.code, arr_local, idx_local, self.func.regs[src_reg])
                access.bytes_access_kind = _bytes_mem_kind(self.code, self.func.regs[src_reg])
                block.statements.append(IRAssign(self.code, access, src_local))
            elif op.op in ("SetI16", "SetI8"):
                arr_local = source_locals[op.df["bytes"].value]
                idx_local = source_locals[op.df["index"].value]
                src_local = source_locals[op.df["src"].value]
                access = IRArrayAccess(self.code, arr_local, idx_local, self.func.regs[op.df["src"].value])
                access.bytes_access_kind = "UI16" if op.op == "SetI16" else "UI8"
                block.statements.append(IRAssign(self.code, access, src_local))
            elif op.op == "SetArray":
                arr_local = source_locals[op.df["array"].value]
                idx_local = source_locals[op.df["index"].value]
                src_local = source_locals[op.df["src"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        IRArrayAccess(self.code, arr_local, idx_local, src_local.get_type()),
                        src_local,
                    )
                )
            elif op.op == "DynSet":
                obj_local = source_locals[op.df["obj"].value]
                src_local = source_locals[op.df["src"].value]
                field_name = op.df["field"].resolve(self.code)
                field_expr = IRField(self.code, obj_local, field_name, self.func.regs[op.df["src"].value])
                block.statements.append(IRAssign(self.code, field_expr, src_local))
            elif op.op == "DynGet":
                dst_local = self.locals[op.df["dst"].value]
                obj_local = source_locals[op.df["obj"].value]
                field_name = op.df["field"].resolve(self.code)
                field_expr = IRField(self.code, obj_local, field_name, self.func.regs[op.df["dst"].value])
                block.statements.append(IRAssign(self.code, dst_local, field_expr))
            elif op.op == "SetField":
                obj_local = source_locals[op.df["obj"].value]
                src_local = source_locals[op.df["src"].value]
                obj_type = obj_local.get_type()
                if isinstance(obj_type.definition, (Obj, Virtual)):
                    field_core = op.df["field"].resolve_obj(self.code, obj_type.definition)
                    field_expr = IRField(
                        self.code,
                        obj_local,
                        _obj_field_name(field_core, op.df["field"].value, self.code),
                        field_core.type,
                    )
                    block.statements.append(IRAssign(self.code, field_expr, src_local))
                else:
                    block.statements.append(IRUnliftedOpcode(self.code, op))
            elif op.op == "Type":
                dst_local = self.locals[op.df["dst"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst_local,
                        IRConst(self.code, IRConst.ConstType.GLOBAL_OBJ, idx=op.df["ty"]),
                    )
                )
            elif op.op == "Ref":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                ref_new = IRRefNew(self.code, src_local)
                ref_new.src_op_idx = op_idx
                block.statements.append(IRAssign(self.code, dst_local, ref_new))
            elif op.op == "Unref":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["src"].value]
                ref_get = IRRefGet(self.code, src_local)
                ref_get.src_op_idx = op_idx
                block.statements.append(IRAssign(self.code, dst_local, ref_get))
            elif op.op == "Setref":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["value"].value]
                ref_set = IRRefSet(self.code, dst_local, src_local)
                ref_set.src_op_idx = op_idx
                block.statements.append(ref_set)
            elif op.op == "StaticClosure":
                dst_local = self.locals[op.df["dst"].value]
                fun_const = IRConst(self.code, IRConst.ConstType.FUN, idx=op.df["fun"])
                block.statements.append(IRAssign(self.code, dst_local, fun_const))
            elif op.op == "InstanceClosure":
                dst_local = self.locals[op.df["dst"].value]
                obj_local = source_locals[op.df["obj"].value]
                fun = op.df["fun"].resolve(self.code)
                method_name = self.code.partial_func_name(fun)
                if method_name in (None, "<none>") and isinstance(fun, Function):
                    # Anonymous InstanceClosure binds a function to a captured
                    # value, including enum environments and callable adapters.
                    # The capture's type does not identify the function's body:
                    # casting it to the result type would discard that body.
                    bound_expr = IRBoundClosure(self.code, fun, obj_local)
                    block.statements.append(IRAssign(self.code, dst_local, bound_expr))
                else:
                    field_expr = IRField(
                        self.code,
                        obj_local,
                        method_name,
                        self.func.regs[op.df["dst"].value],
                    )
                    block.statements.append(IRAssign(self.code, dst_local, field_expr))
            elif op.op == "VirtualClosure":
                dst_local = self.locals[op.df["dst"].value]
                obj_local = source_locals[op.df["obj"].value]
                obj_type = obj_local.get_type()
                field_expr = self._resolve_method_field(obj_local, obj_type, op.df["field"].value)
                if field_expr is not None:
                    # Unlike InstanceClosure, this opcode means the original Haxe
                    # source resolved the closure through a statically-typed
                    # receiver that required virtual dispatch (e.g. the receiver
                    # was typed as a base class). The lifted local's type is the
                    # concrete allocated type, which would make the recompiled
                    # closure bind directly instead of virtually — record the
                    # declaring function so pseudo-rendering can widen the
                    # receiver's declared type back to where dispatch is virtual.
                    defn = obj_type.definition
                    if isinstance(defn, Obj):
                        proto = self.code.proto_by_pindex(defn, op.df["field"].value)
                        if proto is not None:
                            resolved_fun = proto.findex.resolve(self.code)
                            if isinstance(resolved_fun, Function):
                                field_expr.virtual_dispatch_fun = resolved_fun
                    block.statements.append(IRAssign(self.code, dst_local, field_expr))
                else:
                    block.statements.append(IRAssign(self.code, dst_local, IRUnliftedOpcode(self.code, op)))
            elif op.op == "NullCheck":
                continue
            elif op.op == "EnumIndex":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["value"].value]
                block.statements.append(IRAssign(self.code, dst_local, IREnumIndex(self.code, src_local)))
            elif op.op == "MakeEnum":
                dst_local = self.locals[op.df["dst"].value]
                enum_type = self.func.regs[op.df["dst"].value]
                enum_def = enum_type.resolve(self.code).definition
                cid = op.df["construct"].value
                construct_name = (
                    enum_def.constructs[cid].name.resolve(self.code)
                    if cid < len(enum_def.constructs)
                    else f"construct_{cid}"
                )
                args = [source_locals[arg.value] for arg in op.df["args"].value]
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst_local,
                        IREnumConstruct(self.code, construct_name, args, enum_type),
                    )
                )
            elif op.op == "EnumAlloc":
                dst_local = self.locals[op.df["dst"].value]
                enum_type = self.func.regs[op.df["dst"].value]
                enum_def = enum_type.resolve(self.code).definition
                cid = op.df["construct"].value
                construct_name = (
                    enum_def.constructs[cid].name.resolve(self.code)
                    if cid < len(enum_def.constructs)
                    else f"construct_{cid}"
                )
                block.statements.append(
                    IRAssign(
                        self.code,
                        dst_local,
                        IREnumConstruct(self.code, construct_name, [], enum_type),
                    )
                )
            elif op.op == "EnumField":
                dst_local = self.locals[op.df["dst"].value]
                src_local = source_locals[op.df["value"].value]
                enum_type = self.func.regs[op.df["value"].value]
                enum_def = enum_type.resolve(self.code).definition
                cid = op.df["construct"].value
                fid = op.df["field"].value
                if 0 <= cid < len(enum_def.constructs) and 0 <= fid < len(enum_def.constructs[cid].params):
                    field_name = f"param{fid}"
                    construct = enum_def.constructs[cid]
                    field_type = construct.params[fid]
                    block.statements.append(
                        IRAssign(
                            self.code,
                            dst_local,
                            IREnumField(self.code, src_local, field_name, field_type, cid),
                        )
                    )
                else:
                    block.statements.append(IRAssign(self.code, dst_local, IRUnliftedOpcode(self.code, op)))
            elif op.op == "SetEnumField":
                value_local = source_locals[op.df["value"].value]
                src_local = source_locals[op.df["src"].value]
                enum_type = self.func.regs[op.df["value"].value]
                enum_def = enum_type.resolve(self.code).definition
                fid = op.df["field"].value
                # SetEnumField has no explicit construct operand; use the only
                # construct when the enum is a singleton, otherwise pick the first
                # construct that has a parameter at this index.
                construct = None
                if len(enum_def.constructs) == 1:
                    construct = enum_def.constructs[0]
                else:
                    for c in enum_def.constructs:
                        if fid < len(c.params):
                            construct = c
                            break
                if construct is not None and fid < len(construct.params):
                    field_name = f"param{fid}"
                    field_type = construct.params[fid]
                    block.statements.append(
                        IRAssign(
                            self.code,
                            IREnumField(self.code, value_local, field_name, field_type),
                            src_local,
                        )
                    )
                else:
                    block.statements.append(IRUnliftedOpcode(self.code, op))
            else:
                if "dst" in op.df:
                    block.statements.append(
                        IRAssign(
                            self.code,
                            self.locals[op.df["dst"].value],
                            IRUnliftedOpcode(self.code, op),
                        )
                    )
                else:
                    block.statements.append(IRUnliftedOpcode(self.code, op))

            # Tag the newly-appended statement with source location and opcode index
            if op_idx is not None and len(block.statements) > _prev_len:
                stmt = block.statements[-1]
                stmt.src_op_idx = op_idx
                if _debuginfo is not None:
                    try:
                        ref = _debuginfo[op_idx]
                        stmt.src_line = ref.line
                        stmt.src_file_idx = ref.value
                    except IndexError:
                        pass
            # Re-emit register aliases (`var b = a;` folded into one register).
            if op_idx is not None:
                for reg, alias in self._op_aliases.get(op_idx, ()):
                    src_local = self.locals[reg]
                    alias_local = IRLocal(alias, self.func.regs[reg], code=self.code)
                    self.all_locals.append(alias_local)
                    block.statements.append(IRAssign(self.code, alias_local, src_local))

    def _shortest_distances(
        self,
        start: CFNode,
        allowed_nodes: Optional[Set[CFNode]] = None,
        stop_nodes: Optional[Set[CFNode]] = None,
    ) -> Dict[CFNode, int]:
        stop_nodes = stop_nodes or set()
        # deque: this BFS runs several times per conditional while lifting, and a
        # list frontier makes each pop O(len(queue)).
        queue: Deque[Tuple[CFNode, int]] = deque([(start, 0)])
        distances: Dict[CFNode, int] = {}

        while queue:
            current, dist = queue.popleft()
            if current in distances:
                continue
            if allowed_nodes is not None and current not in allowed_nodes:
                continue
            if current in stop_nodes:
                continue

            distances[current] = dist
            for next_node, _ in current.branches:
                if next_node not in distances:
                    queue.append((next_node, dist + 1))

        return distances

    def _find_convergence_node(
        self,
        left: Optional[CFNode],
        right: Optional[CFNode],
        allowed_nodes: Optional[Set[CFNode]] = None,
        stop_nodes: Optional[Set[CFNode]] = None,
    ) -> Optional[CFNode]:
        if left is None or right is None:
            return None

        left_distances = self._shortest_distances(left, allowed_nodes, stop_nodes)
        right_distances = self._shortest_distances(right, allowed_nodes, stop_nodes)
        common_nodes = set(left_distances).intersection(right_distances)
        if not common_nodes:
            return None

        return min(
            common_nodes,
            key=lambda node: (
                left_distances[node] + right_distances[node],
                node.base_offset,
            ),
        )

    def _reaches_bypassing(
        self,
        starts: Tuple[Optional[CFNode], ...],
        goal: CFNode,
        barrier: CFNode,
        allowed_nodes: Optional[Set[CFNode]] = None,
    ) -> bool:
        """Whether `goal` is reachable from any of `starts` without passing `barrier`.

        Used to reject a convergence candidate that the enclosing merge point can
        sidestep: such a candidate does not post-dominate the arms, so lifting an
        arm up to it would run past the enclosing boundary instead of stopping.
        """
        for start in starts:
            if start is None:
                continue
            if goal in self._shortest_distances(start, allowed_nodes, {barrier}):
                return True
        return False

    def _is_terminal_branch_node(self, node: Optional[CFNode], loop_ctx: Optional[_LoopContext]) -> bool:
        """Return True if a branch target has no live successors within the current region."""
        if node is None:
            return True
        if loop_ctx is not None and node == loop_ctx.header:
            return False
        if not node.branches:
            return True
        # A node that only leaves the current region is also terminal for our purposes.
        if loop_ctx is not None:
            return all(successor not in loop_ctx.nodes for successor, _ in node.branches)
        return False

    def _loop_exit_nodes(self, loop_nodes: Set[CFNode]) -> List[CFNode]:
        exit_nodes: Set[CFNode] = set()
        for loop_node in loop_nodes:
            for target, _ in loop_node.branches:
                if target not in loop_nodes:
                    exit_nodes.add(target)
        return sorted(exit_nodes, key=lambda n: n.base_offset)

    def _lift_loop(
        self,
        header: CFNode,
        visited: Set[CFNode],
        stop_at: Optional[CFNode],
        parent_loop: Optional[_LoopContext],
    ) -> IRBlock:
        assert self.cfg is not None
        visited.add(header)
        block = IRBlock(self.code)
        loop_nodes = self.cfg.loops[header]
        # Prefer the header's own outside successor as the loop exit when the header
        # is a conditional. This correctly identifies post-loop code even when the
        # loop body contains internal returns that would otherwise look like extra
        # exits (e.g. String.lastIndexOf).
        exit_node: Optional[CFNode] = None
        header_last_op = header.ops[-1] if header.ops else None
        outside_header_successors = (
            [target for target, _ in header.branches if target not in loop_nodes] if header_last_op else []
        )
        # Non-exit successors: everything the conditional can fall into that stays in
        # the loop, including a direct self-edge back to the header (a body folded
        # entirely into the condition block, e.g. `while(true) { x *= 2; if (x > n) break; }`).
        non_exit_successors = (
            [target for target, _ in header.branches if target not in outside_header_successors]
            if header_last_op
            else []
        )
        # The header only *is* the loop's condition when its branch cleanly gates the
        # loop: exactly one edge stays inside (continue) and exactly one leaves (exit).
        # A header that ends in a conditional for other reasons (e.g. an inline bounds
        # check while computing an array index) can have both edges land inside the
        # loop without either being the exit; treating that conditional as the loop
        # condition then drops the real body.
        header_is_loop_gate = (
            header_last_op is not None
            and header_last_op.op in conditionals
            and len(outside_header_successors) == 1
            and len(non_exit_successors) == 1
        )
        if header_is_loop_gate:
            exit_node = outside_header_successors[0]
        if exit_node is None:
            exit_nodes = self._loop_exit_nodes(loop_nodes)
            exit_node = exit_nodes[0] if len(exit_nodes) == 1 else None
        loop_ctx = self._LoopContext(header, loop_nodes, exit_node)

        if header_is_loop_gate:
            assert header_last_op is not None
            cond_block = IRBlock(self.code)
            self._lift_ops_into_block(cond_block, header.ops[:-1])

            def _jump_operand(key: str) -> Optional[IRExpression]:
                if key not in header_last_op.df:
                    return None
                return cast(IRExpression, self.locals[header_last_op.df[key].value])

            pj_left = _jump_operand("a")
            pj_right = _jump_operand("b")
            pj_cond = _jump_operand("cond") if "cond" in header_last_op.df else _jump_operand("reg")

            pj_exit_on_true = any(target == exit_node and edge == "true" for target, edge in header.branches)
            cond_block.statements.append(
                IRPrimitiveJump(self.code, header_last_op, pj_left, pj_right, pj_cond, pj_exit_on_true)
            )

            body_start = non_exit_successors[0]
            body_block = (
                self._lift_block(body_start, visited.copy(), stop_at=header, loop_ctx=loop_ctx)
                if body_start != header
                else IRBlock(self.code)
            )

            block.statements.append(IRPrimitiveLoop(self.code, cond_block, body_block))
        else:
            # `header` was marked visited above so the outer caller won't re-descend into
            # it, but the body traversal genuinely starts at the header's own content
            # here (no separate condition block was carved out of it) - excluding it from
            # this copy lets `_lift_block` actually process it instead of immediately
            # bailing out on the "already visited" check.
            body_visited = visited.copy()
            body_visited.discard(header)
            body_block = self._lift_block(
                header, body_visited, stop_at=header, loop_ctx=loop_ctx, is_loop_entry=True
            )
            block.statements.append(
                IRWhileLoop(
                    self.code,
                    IRBoolExpr(self.code, IRBoolExpr.CompareType.TRUE),
                    body_block,
                )
            )

        next_block_ir = self._lift_block(exit_node, visited, stop_at, loop_ctx=parent_loop)
        block.statements.extend(next_block_ir.statements)
        return block

    def _build_bool_expr_from_op(self, op: Opcode) -> IRBoolExpr:
        """Helper to create an IRBoolExpr from a conditional jump opcode."""
        cond_map = {
            "JTrue": IRBoolExpr.CompareType.ISTRUE,
            "JFalse": IRBoolExpr.CompareType.ISFALSE,
            "JNull": IRBoolExpr.CompareType.NULL,
            "JNotNull": IRBoolExpr.CompareType.NOT_NULL,
            "JSLt": IRBoolExpr.CompareType.LT,
            "JSGte": IRBoolExpr.CompareType.GTE,
            "JSGt": IRBoolExpr.CompareType.GT,
            "JSLte": IRBoolExpr.CompareType.LTE,
            "JULt": IRBoolExpr.CompareType.ULT,
            "JUGte": IRBoolExpr.CompareType.UGTE,
            "JNotLt": IRBoolExpr.CompareType.NOT_LT,
            "JNotGte": IRBoolExpr.CompareType.NOT_GTE,
            "JEq": IRBoolExpr.CompareType.EQ,
            "JNotEq": IRBoolExpr.CompareType.NEQ,
        }
        assert op.op is not None, "WTF??"
        cond = cond_map[op.op]
        left, right = None, None
        if "a" in op.df and "b" in op.df:
            left = self.locals[op.df["a"].value]
            right = self.locals[op.df["b"].value]
        else:
            reg_key = "cond" if "cond" in op.df else "reg"
            left = self.locals[op.df[reg_key].value]
        return IRBoolExpr(self.code, cond, left, right)

    def _clone_ir(self, block: IRBlock) -> IRBlock:
        """
        Clones a cached IRBlock so a memoized `_lift_block` result can be reused without
        making the same object reachable from multiple parents. `self.code` (the whole
        Bytecode) and `self.locals` (the register->IRLocal identities used throughout
        the function) are shared rather than duplicated; everything else in the
        statement/expression tree is copied. Hand-rolled instead of `copy.deepcopy`:
        deepcopy's generic `__reduce_ex__`/pickling-protocol dispatch is much slower
        than just walking `__dict__`, and this runs once per cache hit.
        """
        memo: Dict[int, Any] = {id(self.code): self.code}
        for local in self.locals:
            memo[id(local)] = local
        return cast(IRBlock, self._clone_value(block, memo))

    def _clone_value(self, value: Any, memo: Dict[int, Any]) -> Any:
        if value is None or isinstance(value, (int, float, str, bool, bytes, _Enum)):
            return value
        vid = id(value)
        if vid in memo:
            return memo[vid]
        if isinstance(value, IRLocal):
            return value
        if isinstance(value, list):
            new_list: List[Any] = []
            memo[vid] = new_list
            new_list.extend(self._clone_value(v, memo) for v in value)
            return new_list
        if isinstance(value, tuple):
            return tuple(self._clone_value(v, memo) for v in value)
        if isinstance(value, dict):
            new_dict: Dict[Any, Any] = {}
            memo[vid] = new_dict
            for k, v in value.items():
                new_dict[self._clone_value(k, memo)] = self._clone_value(v, memo)
            return new_dict
        if isinstance(value, set):
            new_set: Set[Any] = set()
            memo[vid] = new_set
            new_set.update(self._clone_value(v, memo) for v in value)
            return new_set
        if not hasattr(value, "__dict__"):
            # Unknown leaf type (e.g. a Bytecode/Function/Type reference) - share it.
            return value
        new_obj = object.__new__(type(value))
        memo[vid] = new_obj
        for k, v in vars(value).items():
            setattr(new_obj, k, self._clone_value(v, memo))
        return new_obj

    def _register_live_at(self, node: Optional[CFNode], reg: int) -> bool:
        """Whether any path reads the incoming register value before overwriting it.

        Void-typed registers carry no value, so an incoming Void can never be
        a meaningful merge operand; treating it as live would join branch
        aliases for it and keep grow-guard patterns from folding.
        """
        reg_type = self.func.regs[reg].resolve(self.code)
        if isinstance(reg_type.definition, Void):
            return False
        pending = [node] if node is not None else []
        seen: Set[CFNode] = set()
        while pending:
            current = pending.pop()
            if current in seen:
                continue
            seen.add(current)
            for op in current.ops:
                for key, operand in op.df.items():
                    if key == "dst" and op.op not in ("Setref", "Incr", "Decr"):
                        continue
                    if isinstance(operand, Reg) and operand.value == reg:
                        return True
                    if isinstance(operand, Regs) and any(r.value == reg for r in operand.value):
                        return True
                if op.op != "Setref" and "dst" in op.df and op.df["dst"].value == reg:
                    break
            else:
                pending.extend(target for target, _ in current.branches)
        return False

    def _branch_falls_through(self, block: IRBlock) -> bool:
        if not block.statements:
            return True
        last = block.statements[-1]
        if isinstance(last, (IRReturn, IRThrow, IRBreak, IRContinue)):
            return False
        if isinstance(last, IRBlock):
            return self._branch_falls_through(last)
        if isinstance(last, IRConditional):
            return self._branch_falls_through(last.true_block) or self._branch_falls_through(last.false_block)
        return True

    def _join_branch_locals(
        self,
        entry: List[IRLocal],
        branches: List[Tuple[IRBlock, List[IRLocal]]],
        convergence: Optional[CFNode],
    ) -> None:
        """Materialize register merges on live branch edges, not on sibling reads."""
        live = [(block, locals_) for block, locals_ in branches if self._branch_falls_through(block)]
        self.locals = entry.copy()
        if not live:
            return
        for reg in range(len(entry)):
            incoming = [locals_[reg] for _, locals_ in live]
            first = incoming[0]
            if all(local == first for local in incoming[1:]):
                self.locals[reg] = first
                continue
            if not self._register_live_at(convergence, reg):
                continue
            # A fresh name avoids overwriting a still-live source local in another
            # register. Copies belong at the outgoing edges, after all branch reads.
            used_names = {local.name for local in self.all_locals}
            base = f"var{reg}"
            name = base
            suffix = 1
            while name in used_names:
                name = f"{base}{suffix}"
                suffix += 1
            merged = self._split_local(reg, name)
            for (branch, _), local in zip(live, incoming):
                branch.statements.append(IRAssign(self.code, merged, local))

    def _lift_loop_edge(
        self, target: Optional[CFNode], visited: Set[CFNode], loop_ctx: Optional[_LoopContext]
    ) -> Optional[IRBlock]:
        """Lift a branch edge that leaves the ordinary flow of the enclosing loop.

        Returns the IR for an edge that continues, breaks out of, or is absent from the
        loop, or None when `target` should be lifted as a regular branch.
        """
        assert self.cfg is not None
        if target is None:
            return IRBlock(self.code)
        if loop_ctx and target == loop_ctx.header:
            branch_block = IRBlock(self.code)
            branch_block.statements.append(IRContinue(self.code))
            return branch_block
        if loop_ctx and target not in loop_ctx.nodes:
            # A return inside a loop is not a loop break; let the normal
            # Ret handler lift it as an IRReturn.  The exception is the
            # loop's own exit node, which post-dominates the header and
            # therefore represents leaving the loop normally.
            if (
                not target.branches
                and target.ops
                and target.ops[-1].op == "Ret"
                and target != loop_ctx.exit_node
                and loop_ctx.header not in self.cfg.post_dominators.get(target, set())
            ):
                return None
            # Branches that leave the loop may contain side effects before the
            # exit (e.g. a final push before breaking out of while(true)). Lift
            # them up to the loop's normal exit node and append a break only if
            # the branch does not already terminate on its own.
            if loop_ctx.exit_node is not None:
                # Lift the exiting branch outside the current loop context so
                # its statements are preserved; stop at the loop's normal exit
                # node so post-loop code is not duplicated here.
                branch_block = self._lift_block(
                    target,
                    visited.copy(),
                    stop_at=loop_ctx.exit_node,
                    loop_ctx=None,
                )
                if branch_block.statements and isinstance(branch_block.statements[-1], (IRReturn, IRThrow)):
                    return branch_block
                branch_block.statements.append(IRBreak(self.code))
                return branch_block
            branch_block = IRBlock(self.code)
            branch_block.statements.append(IRBreak(self.code))
            return branch_block
        return None

    def _lift_block(
        self,
        node: Optional[CFNode],
        visited: Set[CFNode],
        stop_at: Optional[CFNode] = None,
        loop_ctx: Optional[_LoopContext] = None,
        is_loop_entry: bool = False,
    ) -> IRBlock:
        """
        Recursively lifts a CFNode and its successors into an IRBlock.

        Args:
            node: The current CFNode to process.
            visited: A set of nodes already processed in the current traversal path to prevent infinite loops.
            stop_at: A CFNode that signals the end of the current branch (the convergence point).
                     When this node is reached, the recursive call terminates.
            is_loop_entry: True for the one call that starts lifting a loop body at its own
                header node (stop_at == node); skips the immediate self-stop so the header's
                content is actually processed instead of yielding an empty block.

        Returns:
            An IRBlock containing the lifted IR statements.
        """
        # --- Base Cases for Recursion Termination ---
        assert self.cfg is not None
        cfg = self.cfg
        if node is None or (node == stop_at and not is_loop_entry) or node in visited:
            return IRBlock(self.code)
        if loop_ctx and node not in loop_ctx.nodes and node.branches:
            block = IRBlock(self.code)
            block.statements.append(IRBreak(self.code))
            return block
        if node in cfg.loops and (loop_ctx is None or node != loop_ctx.header):
            return self._lift_loop(node, visited, stop_at, loop_ctx)

        # The same CFG region can be reached with different register lifetimes.
        # Cache both its incoming identity state and its outgoing state; restoring
        # only the IR would leak the preceding sibling's names into its successor.
        cache_key = (
            node,
            stop_at,
            id(loop_ctx),
            tuple(id(local) for local in self.locals),
            frozenset(self._new_defined_regs),
        )
        cached = self._lift_cache.get(cache_key)
        if cached is not None:
            visited.add(node)
            cached_block, outgoing_locals, outgoing_new_regs = cached
            self.locals = outgoing_locals.copy()
            self._new_defined_regs = outgoing_new_regs.copy()
            return self._clone_ir(cached_block)

        visited.add(node)

        block = IRBlock(self.code)
        last_op = node.ops[-1] if node.ops else None

        # --- 1. Process the Content of the Current Node ---
        # Determine which opcodes are for content vs. control flow.
        # If the last op is a branch/return, we don't lift it as a regular statement.
        is_last_op_control_flow = last_op and last_op.op in (
            conditionals + ["Switch", "Ret", "JAlways", "Throw", "Rethrow", "Trap", "EndTrap"]
        )
        ops_to_process = node.ops[:-1] if is_last_op_control_flow else node.ops

        self._lift_ops_into_block(block, ops_to_process)

        # --- 2. Handle the Control Flow based on the Last Opcode ---
        string_switch = self._match_string_switch(node) if last_op and last_op.op == "JNull" else None
        if string_switch is not None:
            self._lift_string_switch(block, node, string_switch, visited, stop_at, loop_ctx)
        elif last_op and last_op.op in conditionals:
            # HL conditional jumps: JXxx jumps to the target when condition is TRUE.
            # Compilers emit "JXxx(negated_if_condition) → else_block" so fall-through = then.
            jump_target, fall_through = None, None
            for branch_node, edge_type in node.branches:
                if edge_type == "true":
                    jump_target = branch_node  # jump target = else block in source
                elif edge_type == "false":
                    fall_through = branch_node  # fall-through = then block in source

            # Invert the jump condition to get the actual "if" condition.
            cond_expr = self._build_bool_expr_from_op(last_op)
            cond_expr.invert()

            stop_nodes = {loop_ctx.header} if loop_ctx else set()
            allowed_nodes = loop_ctx.nodes if loop_ctx else None
            convergence_node = self._find_convergence_node(
                jump_target,
                fall_through,
                allowed_nodes=allowed_nodes,
                stop_nodes=stop_nodes,
            )

            if convergence_node is None and node in cfg.immediate_post_dominators:
                convergence_node = cfg.immediate_post_dominators[node]

            # `_find_convergence_node`'s shortest-combined-distance heuristic can pick
            # one of the branch targets itself as the "convergence" when that target is
            # *also* reachable from the other branch — but only via one of that other
            # branch's own internal sub-paths, not every path (e.g. an inner
            # `if (a) sharedCall(); else skip;` nested in one arm of this outer `if`,
            # where sharedCall()'s node gets picked as the outer merge point instead of
            # the node both arms actually always reach afterward). Detect that precisely
            # with real post-dominance (every path, not just the shortest one) rather than
            # overriding every self-referential pick: the simple "if with no else" shape
            # legitimately wants the branch target itself as convergence (that *is* its
            # only continuation), and forcing the post-dominator there would wrongly pull
            # the tail inside the conditional instead of leaving it as the fall-through.
            if (
                loop_ctx is None
                and convergence_node is not None
                and convergence_node in (jump_target, fall_through)
            ):
                other_branch = fall_through if convergence_node == jump_target else jump_target
                dominates_other = other_branch is None or convergence_node in cfg.post_dominators.get(
                    other_branch, set()
                )
                if not dominates_other and node in cfg.immediate_post_dominators:
                    pd = cfg.immediate_post_dominators[node]
                    if pd is not None and pd != convergence_node:
                        convergence_node = pd

            # If the branches do not share a real convergence point because one of
            # them terminates (e.g. returns), use the post-dominator of the live
            # branch as the convergence.  This keeps the code after the terminating
            # branch outside the conditional instead of inlining it into the other
            # branch.
            if convergence_node is None:
                terminal_left = self._is_terminal_branch_node(jump_target, loop_ctx)
                terminal_right = self._is_terminal_branch_node(fall_through, loop_ctx)
                if terminal_left and not terminal_right and fall_through in cfg.immediate_post_dominators:
                    convergence_node = cfg.immediate_post_dominators[fall_through]
                elif terminal_right and not terminal_left and jump_target in cfg.immediate_post_dominators:
                    convergence_node = cfg.immediate_post_dominators[jump_target]

            # If no convergence point could be determined at all, never let a branch
            # explore past the boundary the *enclosing* call already established. Without
            # this, a live branch recurses with stop_at=None and re-walks the entire rest
            # of the function independently of the outer continuation, which re-walks the
            # same nodes again - doubling work at every such conditional and blowing up
            # exponentially for long chains of terminal-vs-live branches.
            if convergence_node is None:
                convergence_node = stop_at

            # `_find_convergence_node` returns the node with the smallest combined
            # distance from both arms, which for a short-circuit condition chain
            # (`if (a || b || c)`, where every link jumps to the same tail) is one
            # arm's own target rather than a real post-dominator. Lifting that arm
            # bounded by such a pick walks straight past the merge point the
            # *enclosing* call established and re-lifts the caller's continuation,
            # so every nested link in the chain duplicates the tail: 2^k copies for
            # a k-link chain. A candidate that the enclosing boundary can bypass is
            # not a merge point at all, so merge at the boundary instead - the
            # caller lifts it (once) after this conditional either way.
            if (
                stop_at is not None
                and convergence_node is not None
                and convergence_node != stop_at
                and self._reaches_bypassing(
                    (fall_through, jump_target), stop_at, convergence_node, allowed_nodes
                )
            ):
                convergence_node = stop_at

            # When one branch leaves the loop and the other loops back, do not let the
            # convergence point be outside the loop. Lifting the exit node here would
            # pull post-loop code into the body and emit a spurious trailing break.
            if (
                loop_ctx
                and convergence_node is not None
                and convergence_node not in loop_ctx.nodes
                and convergence_node != loop_ctx.header
            ):
                loops_back = (fall_through is not None and fall_through in loop_ctx.nodes) or (
                    jump_target is not None and jump_target in loop_ctx.nodes
                )
                if loops_back:
                    convergence_node = loop_ctx.header

            entry_locals = self.locals.copy()
            entry_new_regs = self._new_defined_regs.copy()

            def lift_branch(target: Optional[CFNode]) -> IRBlock:
                self.locals = entry_locals.copy()
                self._new_defined_regs = entry_new_regs.copy()
                branch = self._lift_loop_edge(target, visited, loop_ctx)
                if branch is None:
                    branch = self._lift_block(
                        target, visited.copy(), stop_at=convergence_node, loop_ctx=loop_ctx
                    )
                return branch

            then_block_ir = lift_branch(fall_through)
            then_locals = self.locals.copy()
            then_new_regs = self._new_defined_regs.copy()
            else_block_ir = lift_branch(jump_target)
            else_locals = self.locals.copy()
            self._new_defined_regs.update(then_new_regs)
            self._join_branch_locals(
                entry_locals, [(then_block_ir, then_locals), (else_block_ir, else_locals)], convergence_node
            )

            conditional_stmt = IRConditional(self.code, cond_expr, then_block_ir, else_block_ir)
            block.statements.append(conditional_stmt)

            # Continue lifting from the convergence point, but stop at the outer boundary.
            # This prevents the convergence node from being consumed here when it equals
            # the outer stop_at, which would leave the outer caller with nothing to lift.
            next_block_ir = self._lift_block(convergence_node, visited, stop_at=stop_at, loop_ctx=loop_ctx)
            block.statements.extend(next_block_ir.statements)

        elif last_op and last_op.op == "Switch":
            convergence_node = self._find_convergence_node(
                node.branches[0][0] if node.branches else None,
                node.branches[1][0] if len(node.branches) > 1 else None,
                allowed_nodes=loop_ctx.nodes if loop_ctx else None,
                stop_nodes={loop_ctx.header} if loop_ctx else None,
            )
            val_reg = self.locals[last_op.df["reg"].value]
            cases: Dict[IRConst, IRBlock] = {}
            aliases: Dict[IRConst, List[IRConst]] = {}
            default_block = IRBlock(self.code)
            # Values whose jump-table entries share a target are one `case a, b:` body.
            case_keys: Dict[CFNode, IRConst] = {}

            for target_node, edge_type in node.branches:
                if edge_type.startswith("switch: case:"):
                    case_val = IRConst(
                        self.code, IRConst.ConstType.INT, value=int(edge_type.split(":")[-1].strip())
                    )
                    key = case_keys.get(target_node)
                    if key is not None:
                        aliases.setdefault(key, []).append(case_val)
                        continue
                    case_keys[target_node] = case_val
                case_block_ir = self._lift_block(
                    target_node,
                    visited.copy(),
                    stop_at=convergence_node,
                    loop_ctx=loop_ctx,
                )
                if edge_type.startswith("switch: case:"):
                    cases[case_keys[target_node]] = case_block_ir
                elif edge_type == "switch: default":
                    default_block = case_block_ir

            block.statements.append(IRSwitch(self.code, val_reg, cases, default_block, aliases))
            # See the Trap case below for why stop_at must be threaded through here.
            next_block_ir = self._lift_block(convergence_node, visited, stop_at=stop_at, loop_ctx=loop_ctx)
            block.statements.extend(next_block_ir.statements)

        elif last_op and last_op.op == "Trap":
            try_branch_node, catch_branch_node = None, None
            for branch_node, edge_type in node.branches:
                if edge_type == "fall-through":
                    try_branch_node = branch_node
                elif edge_type == "trap":
                    catch_branch_node = branch_node

            stop_nodes = {loop_ctx.header} if loop_ctx else set()
            allowed_nodes = loop_ctx.nodes if loop_ctx else None
            convergence_node = self._find_convergence_node(
                try_branch_node,
                catch_branch_node,
                allowed_nodes=allowed_nodes,
                stop_nodes=stop_nodes,
            )

            self._trap_depth += 1
            try_block_ir = self._lift_block(
                try_branch_node,
                visited.copy(),
                stop_at=convergence_node,
                loop_ctx=loop_ctx,
            )
            # Trap rebinds this register fresh -- split it before lifting the catch block.
            exc_reg = last_op.df["exc"].value
            catch_local = self._split_local(exc_reg, f"var{exc_reg}", defining_op_idx=None)
            catch_block_ir = self._lift_block(
                catch_branch_node,
                visited.copy(),
                stop_at=convergence_node,
                loop_ctx=loop_ctx,
            )
            self._trap_depth -= 1
            # Split again after the catch so later code can't inherit catch_local's identity.
            self._split_local(exc_reg, f"var{exc_reg}", defining_op_idx=None)
            explicit_catch_type = (
                self._catch_has_explicit_type(catch_branch_node) if catch_branch_node is not None else False
            )
            block.statements.append(
                IRTryCatch(
                    self.code,
                    try_block_ir,
                    catch_block_ir,
                    catch_local,
                    explicit_catch_type,
                )
            )

            # Must bound this by the enclosing stop_at, like the conditional case
            # below does: when this Trap is itself inside a branch that was lifted
            # with stop_at == convergence_node (e.g. an enclosing if/else where one
            # side returns early and the other falls through into this try/catch),
            # omitting it would re-lift the shared tail past the try/catch here, and
            # the enclosing branch's own caller would *also* lift it as the
            # conditional's post-merge continuation — duplicating it.
            next_block_ir = self._lift_block(convergence_node, visited, stop_at=stop_at, loop_ctx=loop_ctx)
            block.statements.extend(next_block_ir.statements)

        elif last_op and last_op.op == "Ret":
            ret_type = self.func.regs[last_op.df["ret"].value].resolve(self.code)
            ret_val = (
                self.locals[last_op.df["ret"].value] if not isinstance(ret_type.definition, Void) else None
            )
            block.statements.append(IRReturn(self.code, ret_val))

        elif last_op and last_op.op in ("Throw", "Rethrow"):
            exc_local = self.locals[last_op.df["exc"].value]
            block.statements.append(IRThrow(self.code, exc_local))

        elif last_op and (last_op.op in ("JAlways", "EndTrap") or not is_last_op_control_flow):
            # EndTrap's successor may be a loop header/exit after jump threading,
            # so it needs the same continue/break handling as an unconditional jump.
            # Recursing directly would discard a visited header and lose the continue.
            if node.branches:
                successor_node, _ = node.branches[0]
                if loop_ctx and successor_node == loop_ctx.header:
                    if self._trap_depth:
                        block.statements.append(IRContinue(self.code))
                    return block
                if loop_ctx and successor_node not in loop_ctx.nodes:
                    block.statements.append(IRBreak(self.code))
                else:
                    next_block_ir = self._lift_block(successor_node, visited, stop_at, loop_ctx=loop_ctx)
                    block.statements.extend(next_block_ir.statements)

        self._lift_cache[cache_key] = (block, self.locals.copy(), self._new_defined_regs.copy())
        return block

    def print(self) -> None:
        print(self.block.pprint())


STATIC_INIT_UNRECOVERABLE = "<unrecoverable static initializer>"


def _static_call_name_parts(func: Function, code: Bytecode) -> Optional[Tuple[str, str]]:
    """Return (class_name, method_name) for a static function, e.g. for rendering `Class.method(...)` call text."""
    name = code.partial_func_name(func)
    if not name or name == "<none>":
        name = None
    if name and "." in name:
        class_name, method_name = name.rsplit(".", 1)
        return class_name, method_name
    full = code.full_func_name(func)
    if full and full != "<none>.<none>" and "." in full:
        class_name, method_name = full.rsplit(".", 1)
        return destaticify(class_name), method_name
    return None


def _static_default_value(code: Bytecode, t: "tIndex") -> str:
    """Zero/default value HL gives a static field read before its own initializer has run."""
    try:
        kind = t.resolve(code).kind.value
    except Exception:
        return "null"
    if kind in (Type.Kind.I32.value, Type.Kind.U8.value, Type.Kind.U16.value, Type.Kind.I64.value):
        return "0"
    if kind in (Type.Kind.F32.value, Type.Kind.F64.value):
        return "0.0"
    if kind == Type.Kind.BOOL.value:
        return "false"
    return "null"


def _collect_static_field_inits(code: Bytecode) -> Dict[int, Dict[str, str]]:
    """Scan the entrypoint for SetField writes to class statics with simple constant/arith/enum initializers, keyed by the static Obj's id() then field name."""
    cache: Optional[Dict[int, Dict[str, str]]] = getattr(code, "_static_field_inits_cache", None)
    if cache is not None:
        return cache
    result: Dict[int, Dict[str, str]] = {}
    field_refs: Dict[int, Dict[str, Set[str]]] = {}
    arith_syms = {"Add": "+", "Sub": "-", "Mul": "*", "Div": "/"}
    # preset string-literal globals (from the bytecode constants table) resolve to a value
    # even though they're loaded via GetGlobal rather than the String opcode
    const_strings: Dict[int, str] = {}
    try:
        for const in code.constants:
            gi = const._global.value
            if const.fields:
                gtype = code.global_types[gi].resolve(code)
                if isinstance(gtype.definition, Obj) and gtype.definition.name.resolve(code) == "String":
                    const_strings[gi] = (
                        '"' + code.strings.value[const.fields[0].value].replace('"', '\\"') + '"'
                    )
    except Exception:
        pass
    try:
        entry = code.entrypoint.resolve(code)
        if not isinstance(entry, Function):
            raise ValueError
        reg_value: Dict[int, str] = {}
        reg_refs: Dict[int, Set[str]] = {}
        reg_global: Dict[int, int] = {}
        pending_new: Dict[int, str] = {}
        empty_array_regs: Set[int] = set()
        # in-progress array-literal builds: alloc reg -> (declared length, {index: (value, refs)})
        array_builds: Dict[int, Tuple[int, Dict[int, Tuple[str, Set[str]]]]] = {}
        # Packed numeric literals use alloc_bytes + byte-offset stores + ArrayBase.alloc*.
        # Keep store kinds as well as offsets so reinterpreted buffers are not mistaken
        # for source literals of a different element type.
        bytes_builds: Dict[int, Tuple[int, Dict[int, Tuple[str, str, Set[str]]]]] = {}
        for op in entry.ops:
            dst: Any = op.df.get("dst")
            if dst is not None:
                bytes_builds.pop(dst.value, None)
                pending_new.pop(dst.value, None)
            if (op.op or "").startswith("J") or op.op in ("Switch", "Label", "Trap"):
                # branchy control flow (e.g. switch-computed initializers): can't safely
                # track a single value across merge points with a flat linear scan
                reg_value.clear()
                reg_refs.clear()
                empty_array_regs.clear()
                array_builds.clear()
                bytes_builds.clear()
                pending_new.clear()
                continue
            if op.op in ("Int", "Float"):
                try:
                    resolved = op.df["ptr"].resolve(code)
                    reg_value[dst.value] = str(getattr(resolved, "value", resolved))
                    reg_refs.pop(dst.value, None)
                except Exception:
                    reg_value.pop(dst.value, None)
            elif op.op == "Bool":
                reg_value[dst.value] = "true" if op.df["value"].value else "false"
                reg_refs.pop(dst.value, None)
            elif op.op == "Null":
                reg_value[dst.value] = "null"
                reg_refs.pop(dst.value, None)
            elif op.op == "String":
                try:
                    s = op.df["ptr"].resolve(code)
                    reg_value[dst.value] = '"' + str(s).replace('"', '\\"') + '"'
                    reg_refs.pop(dst.value, None)
                except Exception:
                    reg_value.pop(dst.value, None)
            elif op.op in ("Shl", "Incr", "Decr"):
                # The compiler advances a literal's cursor and shifts it to a byte
                # offset. Only evaluate integer constants, never source expressions.
                try:
                    if op.op == "Shl":
                        value = int(reg_value[op.df["a"].value]) << (int(reg_value[op.df["b"].value]) & 31)
                        value = (value + 0x80000000) % 0x100000000 - 0x80000000
                    else:
                        value = int(reg_value[dst.value]) + (1 if op.op == "Incr" else -1)
                    reg_value[dst.value] = str(value)
                except (KeyError, ValueError):
                    reg_value.pop(dst.value, None)
                reg_refs.pop(dst.value, None)
            elif op.op in arith_syms:
                a, b = op.df["a"].value, op.df["b"].value
                if a in reg_value and b in reg_value:
                    reg_value[dst.value] = f"({reg_value[a]} {arith_syms[op.op]} {reg_value[b]})"
                    reg_refs[dst.value] = reg_refs.get(a, set()) | reg_refs.get(b, set())
                else:
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
            elif op.op in ("MakeEnum", "EnumAlloc"):
                try:
                    enum_type = entry.regs[dst.value].resolve(code)
                    enum_def = enum_type.definition
                    cid = op.df["construct"].value
                    cname = (
                        enum_def.constructs[cid].name.resolve(code)
                        if cid < len(enum_def.constructs)
                        else f"construct_{cid}"
                    )
                    if op.op == "MakeEnum":
                        arg_regs = [a.value for a in op.df["args"].value]
                        if all(a in reg_value for a in arg_regs):
                            reg_value[dst.value] = f"{cname}({', '.join(reg_value[a] for a in arg_regs)})"
                        else:
                            reg_value[dst.value] = STATIC_INIT_UNRECOVERABLE
                    else:
                        reg_value[dst.value] = cname
                except Exception:
                    reg_value.pop(dst.value, None)
            elif op.op == "New":
                try:
                    typ = entry.regs[dst.value].resolve(code)
                    if isinstance(typ.definition, Obj):
                        pending_new[dst.value] = destaticify(typ.definition.name.resolve(code))
                except Exception:
                    pass
                reg_value.pop(dst.value, None)
                reg_refs.pop(dst.value, None)
            elif (
                op.op == "CallMethod" and op.df["args"].value and op.df["args"].value[0].value in pending_new
            ):
                obj_reg = op.df["args"].value[0].value
                cname = pending_new.pop(obj_reg)
                is_ctor = False
                try:
                    obj_type = entry.regs[obj_reg].resolve(code)
                    if isinstance(obj_type.definition, Obj):
                        proto = code.proto_by_pindex(obj_type.definition, op.df["field"].value)
                        is_ctor = proto is not None and proto.name.resolve(code) in ("new", "__constructor__")
                except Exception:
                    is_ctor = False
                call_args = [a.value for a in op.df["args"].value[1:]]
                if is_ctor and all(a in reg_value for a in call_args):
                    reg_value[obj_reg] = f"new {cname}({', '.join(reg_value[a] for a in call_args)})"
                    reg_refs[obj_reg] = {cname}
                    for a in call_args:
                        reg_refs[obj_reg] |= reg_refs.get(a, set())
                else:
                    reg_value[obj_reg] = STATIC_INIT_UNRECOVERABLE
                    reg_refs.pop(obj_reg, None)
                if dst is not None:
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
            elif op.op in simple_calls:
                fname_parts = None
                fun = None
                try:
                    fun = op.df["fun"].resolve(code)
                    fname_parts = _static_call_name_parts(fun, code) if isinstance(fun, Function) else None
                except Exception:
                    fname_parts = None
                call_arg_regs = (
                    [op.df["args"].value[i].value for i in range(len(op.df["args"].value))]
                    if op.op == "CallN"
                    else [op.df[f"arg{i}"].value for i in range(int(op.op[-1]))]
                )
                # new Array<T>() uses an anonymous ArrayObj constructor rather
                # than a named `new` proto. Match the same stdlib wrapper shape
                # as IRArrayObjWrapperOptimizer, with a fresh receiver and Void
                # result to distinguish it from the native-array alloc factory.
                if (
                    isinstance(fun, Function)
                    and fname_parts is None
                    and len(call_arg_regs) == 1
                    and pending_new.get(call_arg_regs[0]) == "hl.types.ArrayObj"
                    and isinstance(fun.resolve_fun(code).ret.resolve(code).definition, Void)
                ):
                    try:
                        wrapper_path = fun.resolve_file(code).replace("\\", "/")
                    except Exception:
                        wrapper_path = ""
                    if "hl/types/ArrayObj.hx" in wrapper_path:
                        obj_reg = call_arg_regs[0]
                        pending_new.pop(obj_reg)
                        reg_value[obj_reg] = "[]"
                        reg_refs.pop(obj_reg, None)
                        reg_value.pop(dst.value, None)
                        reg_refs.pop(dst.value, None)
                        continue
                if (
                    isinstance(fun, Native)
                    and fun.name.resolve(code) == "alloc_bytes"
                    and len(call_arg_regs) == 1
                    and reg_value.get(call_arg_regs[0], "").isdigit()
                ):
                    bytes_builds[dst.value] = (int(reg_value[call_arg_regs[0]]), {})
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
                    continue
                if (
                    fname_parts is not None
                    and fname_parts[0] == "hl.types.ArrayBase"
                    and fname_parts[1] in IRArrayPatternOptimizer._ALLOC_SHIFTS
                    and len(call_arg_regs) == 2
                    and call_arg_regs[0] in bytes_builds
                ):
                    size, stores = bytes_builds.pop(call_arg_regs[0])
                    kind = fname_parts[1][len("alloc") :]
                    width = 1 << IRArrayPatternOptimizer._ALLOC_SHIFTS[fname_parts[1]]
                    length_text = reg_value.get(call_arg_regs[1], "")
                    length = int(length_text) if length_text.isdigit() else -1
                    if (
                        length >= 0
                        and size == length * width
                        and len(stores) == length
                        and all(i * width in stores and stores[i * width][0] == kind for i in range(length))
                    ):
                        reg_value[dst.value] = (
                            "[" + ", ".join(stores[i * width][1] for i in range(length)) + "]"
                        )
                        refs: Set[str] = set()
                        for i in range(length):
                            refs |= stores[i * width][2]
                        reg_refs[dst.value] = refs
                    else:
                        reg_value[dst.value] = STATIC_INIT_UNRECOVERABLE
                        reg_refs.pop(dst.value, None)
                    continue
                # `[]` literal lowers to native alloc_array(type, 0) then a synthetic
                # wrapper call turning the raw array into an Array<T>; the wrapper has
                # no resolvable name, so match on the alloc_array(.., 0) shape instead
                if (
                    isinstance(fun, Native)
                    and fun.name.resolve(code) == "alloc_array"
                    and len(call_arg_regs) == 2
                    and reg_value.get(call_arg_regs[1]) == "0"
                ):
                    empty_array_regs.add(dst.value)
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
                # non-empty array literal: alloc_array(type, N) followed by N
                # SetArray element writes, then the same synthetic wrap call
                elif (
                    isinstance(fun, Native)
                    and fun.name.resolve(code) == "alloc_array"
                    and len(call_arg_regs) == 2
                    and reg_value.get(call_arg_regs[1], "").isdigit()
                    and int(reg_value[call_arg_regs[1]]) > 0
                ):
                    array_builds[dst.value] = (int(reg_value[call_arg_regs[1]]), {})
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
                elif op.op == "Call1" and call_arg_regs[0] in empty_array_regs:
                    reg_value[dst.value] = "[]"
                    reg_refs.pop(dst.value, None)
                elif op.op == "Call1" and call_arg_regs[0] in array_builds:
                    length, elems = array_builds.pop(call_arg_regs[0])
                    if len(elems) == length and all(i in elems for i in range(length)):
                        reg_value[dst.value] = "[" + ", ".join(elems[i][0] for i in range(length)) + "]"
                        refs: Set[str] = set()
                        for i in range(length):
                            refs |= elems[i][1]
                        reg_refs[dst.value] = refs
                    else:
                        reg_value[dst.value] = STATIC_INIT_UNRECOVERABLE
                        reg_refs.pop(dst.value, None)
                # constructors are compiled as direct calls to the `new` findex, obj as arg0,
                # not dispatched through the vtable, so catch them here too
                elif (
                    fname_parts is not None
                    and fname_parts[1] in ("new", "__constructor__")
                    and call_arg_regs
                    and call_arg_regs[0] in pending_new
                ):
                    obj_reg = call_arg_regs[0]
                    cname = pending_new.pop(obj_reg)
                    ctor_args = call_arg_regs[1:]
                    if all(a in reg_value for a in ctor_args):
                        reg_value[obj_reg] = f"new {cname}({', '.join(reg_value[a] for a in ctor_args)})"
                        reg_refs[obj_reg] = {cname}
                        for a in ctor_args:
                            reg_refs[obj_reg] |= reg_refs.get(a, set())
                    else:
                        reg_value[obj_reg] = STATIC_INIT_UNRECOVERABLE
                        reg_refs.pop(obj_reg, None)
                    if dst is not None:
                        reg_value.pop(dst.value, None)
                        reg_refs.pop(dst.value, None)
                elif fname_parts is not None and all(a in reg_value for a in call_arg_regs):
                    cname, mname = fname_parts
                    reg_value[dst.value] = (
                        f"{cname}.{mname}({', '.join(reg_value[a] for a in call_arg_regs)})"
                    )
                    reg_refs[dst.value] = {cname}
                    for a in call_arg_regs:
                        reg_refs[dst.value] |= reg_refs.get(a, set())
                else:
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
            elif op.op == "CallClosure":
                fun_reg = op.df["fun"].value
                arg_regs = [arg.value for arg in op.df["args"].value]
                # Complex initializers are compiled into anonymous functions and
                # invoked through StaticClosure/CallClosure. Keep the invocation,
                # not just the closure value, so the normal helper emitter can
                # recover the body without evaluating it during decompilation.
                if all(
                    reg in reg_value and reg_value[reg] != STATIC_INIT_UNRECOVERABLE
                    for reg in [fun_reg, *arg_regs]
                ):
                    value = f"({reg_value[fun_reg]})({', '.join(reg_value[arg] for arg in arg_regs)})"
                    refs = set(reg_refs.get(fun_reg, set()))
                    for arg in arg_regs:
                        refs.update(reg_refs.get(arg, set()))
                    reg_value[dst.value] = value
                    reg_refs[dst.value] = refs
                else:
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
            elif op.op == "StaticClosure":
                try:
                    fun = op.df["fun"].resolve(code)
                    parts = _static_call_name_parts(fun, code) if isinstance(fun, Function) else None
                    if parts:
                        cname, mname = parts
                        reg_value[dst.value] = f"{cname}.{mname}"
                        reg_refs[dst.value] = {cname}
                    else:
                        # anonymous closure: rendered by pseudo.py as a private
                        # static helper named __anon_<findex>
                        reg_value[dst.value] = f"__anon_{fun.findex.value}"
                        reg_refs.pop(dst.value, None)
                except Exception:
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
            elif op.op in ("SetMem", "SetI16", "SetI8"):
                bytes_reg = op.df["bytes"].value
                if bytes_reg in bytes_builds:
                    src_reg = op.df["src"].value
                    offset_text = reg_value.get(op.df["index"].value, "")
                    kind = (
                        _bytes_mem_kind(code, entry.regs[src_reg])
                        if op.op == "SetMem"
                        else "UI16"
                        if op.op == "SetI16"
                        else None
                    )
                    width = {"I32": 4, "F32": 4, "F64": 8, "UI16": 2}.get(kind)
                    size, stores = bytes_builds[bytes_reg]
                    if (
                        kind is not None
                        and width is not None
                        and offset_text.isdigit()
                        and int(offset_text) % width == 0
                        and int(offset_text) + width <= size
                        and src_reg in reg_value
                        and reg_value[src_reg] != STATIC_INIT_UNRECOVERABLE
                    ):
                        stores[int(offset_text)] = (kind, reg_value[src_reg], reg_refs.get(src_reg, set()))
                    else:
                        bytes_builds.pop(bytes_reg)
            elif op.op == "SetArray":
                array_reg = op.df["array"].value
                if array_reg in array_builds:
                    idx_reg = op.df["index"].value
                    src_reg = op.df["src"].value
                    length, elems = array_builds[array_reg]
                    idx_str = reg_value.get(idx_reg)
                    if idx_str is not None and idx_str.isdigit() and src_reg in reg_value:
                        idx = int(idx_str)
                        if 0 <= idx < length:
                            elems[idx] = (reg_value[src_reg], reg_refs.get(src_reg, set()))
            elif op.op == "GetGlobal":
                gi = op.df["global"].value
                if gi in const_strings:
                    reg_value[dst.value] = const_strings[gi]
                    reg_refs.pop(dst.value, None)
                else:
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
                reg_global[dst.value] = gi
            elif op.op == "Field":
                obj_reg = op.df["obj"].value
                gi = reg_global.get(obj_reg)
                if gi is not None:
                    try:
                        defn = code.global_types[gi].resolve(code).definition
                        if isinstance(defn, Obj):
                            field_core = op.df["field"].resolve_obj(code, defn)
                            fname = field_core.name.resolve(code)
                            field_dict = result.get(id(defn), {})
                            if fname in field_dict:
                                known = field_dict[fname]
                                if known != STATIC_INIT_UNRECOVERABLE:
                                    # reference the field itself rather than inlining its init
                                    # expression: inlining would re-run any side effects (e.g. a
                                    # call) that already ran once when that field was initialized
                                    owner_name = destaticify(defn.name.resolve(code))
                                    reg_value[dst.value] = f"{owner_name}.{fname}"
                                    reg_refs[dst.value] = {owner_name} | field_refs.get(id(defn), {}).get(
                                        fname, set()
                                    )
                                else:
                                    reg_value.pop(dst.value, None)
                                    reg_refs.pop(dst.value, None)
                            else:
                                # field not yet assigned in scan order (forward reference, same
                                # or later class): reads the type's zero/default value at runtime
                                reg_value[dst.value] = _static_default_value(code, field_core.type)
                                reg_refs.pop(dst.value, None)
                    except Exception:
                        reg_value.pop(dst.value, None)
                        reg_refs.pop(dst.value, None)
                else:
                    reg_value.pop(dst.value, None)
                    reg_refs.pop(dst.value, None)
            elif op.op == "SetField":
                obj_reg = op.df["obj"].value
                src_reg = op.df["src"].value
                gi = reg_global.get(obj_reg)
                if gi is not None:
                    try:
                        defn = code.global_types[gi].resolve(code).definition
                        if isinstance(defn, Obj):
                            field_core = op.df["field"].resolve_obj(code, defn)
                            fname = field_core.name.resolve(code)
                            value = reg_value.get(src_reg, STATIC_INIT_UNRECOVERABLE)
                            result.setdefault(id(defn), {})[fname] = value
                            field_refs.setdefault(id(defn), {})[fname] = reg_refs.get(src_reg, set())
                    except Exception:
                        pass
            elif dst is not None:
                reg_value.pop(dst.value, None)
                reg_refs.pop(dst.value, None)
                reg_global.pop(dst.value, None)
    except Exception:
        pass
    code._static_field_inits_cache = result
    code._static_field_init_refs_cache = field_refs
    return result


class IRClass:
    """
    Intermediate representation of a class.
    """

    def __init__(self, code: Bytecode, obj: Obj, capture_layers: bool = False) -> None:
        self.code = code
        self.capture_layers = capture_layers
        self.dynamic: Optional[Obj] = None
        self.static: Optional[Obj] = None
        if obj.is_static:
            self.static = obj
            try:
                self.dynamic = obj.dynamic
            except (ValueError, AttributeError):
                self.dynamic = None
        else:
            self.dynamic = obj
            try:
                self.static = obj.static
            except (ValueError, AttributeError):
                self.static = None
        self.methods: List[IRFunction] = []
        self.static_methods: List[IRFunction] = []
        self.fields: List[Tuple[str, Type]] = []
        self.static_fields: List[Tuple[str, Type]] = []
        self.field_elem_types: Dict[str, Type] = {}
        self.static_field_inits: Dict[str, str] = {}
        self.static_field_init_refs: Dict[str, Set[str]] = {}
        if self.dynamic is None and self.static is None:
            raise ValueError(
                "IRClass needs at least one valid Obj that has been preprocessed by `Bytecode.map_statics`!"
            )

        if self.dynamic:
            self.methods += self.gather_methods(self.dynamic)
            self.fields += self.gather_fields(self.dynamic)
        if self.static:
            self.static_methods += self.gather_methods(self.static)
            self.static_fields += self.gather_fields(self.static)
            try:
                self.static_field_inits = _collect_static_field_inits(self.code).get(id(self.static), {})
                self.static_field_init_refs = getattr(self.code, "_static_field_init_refs_cache", {}).get(
                    id(self.static), {}
                )
            except Exception:
                pass

        # Recover erased Array<T> element types from usage now that all
        # methods are lifted and optimized. Must run before pseudo rendering.
        from .opt.arraytypes import recover_array_element_types

        recover_array_element_types(self)

    def gather_methods(self, obj: Obj) -> List[IRFunction]:
        """
        Gathers all methods from an instance of Obj.
        """
        res: List[IRFunction] = []
        for proto in obj.protos:
            fn = proto.findex.resolve(self.code)
            assert isinstance(fn, Function), (
                "Native protos aren't supported! Not even sure if this is possible tbh"
            )
            res.append(IRFunction(self.code, fn, capture_layers=self.capture_layers))
        for binding in obj.bindings:
            fn = binding.findex.resolve(self.code)
            assert isinstance(fn, Function), (
                "Native bindings aren't supported! Not even sure if this is possible tbh"
            )
            # Avoid adding duplicates if a proto is also bound
            if fn not in [r.func for r in res]:
                res.append(IRFunction(self.code, fn, capture_layers=self.capture_layers))
        return res

    def gather_fields(self, obj: Obj) -> List[Tuple[str, Type]]:
        res: List[Tuple[str, Type]] = []
        binding_names: List[str] = []
        for binding in obj.bindings:
            binding_names.append(binding.field.resolve_obj(self.code, obj).name.resolve(self.code))
        # Own fields sit at the end of resolve_fields() (parent fields first),
        # so this offset keeps the synthesized fallback name aligned with the
        # index Field/SetField ops actually resolve against.
        own_start = len(obj.resolve_fields(self.code)) - len(obj.fields)
        for i, field in enumerate(obj.fields):
            name = _obj_field_name(field, own_start + i, self.code)
            if field.name.resolve(self.code) not in binding_names:
                res.append((name, field.type.resolve(self.code)))
        return res

    def pseudo(self, max_classes: Optional[int] = None) -> str:
        """
        Generates Haxe pseudocode for the entire class.

        `max_classes` caps how many transitively-referenced classes are pulled
        in alongside this one; see `pseudo.class_pseudo`. `None` is unbounded.
        """
        from .. import pseudo

        return pseudo.class_pseudo(self, max_classes=max_classes)

    def print(self) -> None:
        """
        Prints the Haxe pseudocode for the entire class to the console.
        """
        print(self.pseudo())
